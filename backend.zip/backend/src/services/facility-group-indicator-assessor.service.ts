import FacilityGroupIndicatorAssessor, {
  FacilityGroupIndicatorAssessorInput,
} from 'models/FacilityGroupIndicatorAssessor';

import { AssessmentIndicators } from 'models';

// creates a new indicator if unique key-pairs are added
export const update = async (groupID: number, indicatorAssessor: any) => {
  await deleteByGroupID(groupID);

  // filter for numeric values and non-null values
  const indicatorIdList = Object.keys(indicatorAssessor)
    .map((id) => parseInt(id))
    .filter((id) => !Number.isNaN(id))
    .filter((id) => indicatorAssessor[id]);

  // retrieve the region codes per indicator
  const indicatorRegionCode: any = {};
  for (let i = 0; i < indicatorIdList.length; i++) {
    indicatorRegionCode[indicatorIdList[i]] = (await AssessmentIndicators.findByPk(indicatorIdList[i]))?.region_code;
  }

  // format the facility group for bulk create
  const facilityGroupIndicatorAssessor: FacilityGroupIndicatorAssessorInput[] = indicatorIdList.map((indicatorId) => ({
    indicator_id: indicatorId,
    assessor_id: indicatorAssessor[indicatorId],
    region_code: indicatorRegionCode[indicatorId] ? indicatorRegionCode[indicatorId] : '',
    group_id: groupID,
  }));

  return await FacilityGroupIndicatorAssessor.bulkCreate(facilityGroupIndicatorAssessor);
};

export const deleteOne = async (id: number) => {
  const facilityGroupIndicatorAssessor = await FacilityGroupIndicatorAssessor.findByPk(id);
  await FacilityGroupIndicatorAssessor.destroy({ where: { id } });

  return facilityGroupIndicatorAssessor;
};

export const deleteByGroupID = async (groupID: number) => {
  return await FacilityGroupIndicatorAssessor.destroy({ where: { group_id: groupID } });
};

export const getAssessorsByGroupID = async (groupID: number) => {
  return await FacilityGroupIndicatorAssessor.findAll({ where: { group_id: groupID } });
};
