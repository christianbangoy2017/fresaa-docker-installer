import {
  AssessmentBatchFacility,
  AssessmentIndicators,
  Facility,
  FacilityAssessment,
  FacilityGroupAssignment,
  FacilityType,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
} from 'models';
import { getAssessmentResponses, getLimitAndOffset, makeCsvSafe, safeIntParse } from 'utils';

import { ApiQuery } from 'interfaces';
import { AssessmentBatchFacilityInput } from 'models/AssessmentBatchFacility';
import { Op } from 'sequelize';
import { getUserByToken } from './user.service';
import { includeFacility } from 'models/Facility';

// creates multiple assessment batch facility for facility
export const createMultiple = async (batch_id: number, created_by: number, facility_ids: number[]) => {
  const bulkData: AssessmentBatchFacilityInput[] = facility_ids.map((facility_id) => {
    return { batch_id, created_by, facility_id };
  });
  return await AssessmentBatchFacility.bulkCreate(bulkData);
};

// creates assessment batch for all the facilities that are not in asssessment batch
export const createAll = async (batch_id: number, token: string) => {
  const current_user = await getUserByToken(token);
  const facilitiesInBatch = (await getFacilityIDsInBatchAssessment(batch_id)) as number[];
  const facilitiesNotInBatch = await Facility.findAll({
    where: { id: { [Op.notIn]: facilitiesInBatch }, region_code: current_user.region_code },
    raw: true,
  });

  const facilityToAdd = facilitiesNotInBatch.map((facility) => {
    return { facility_id: facility.id, batch_id, created_by: current_user.id };
  });
  return await AssessmentBatchFacility.bulkCreate(facilityToAdd);
};

// deletes one or many assesment batch facility
export const deleteMultiple = async (ids: number[]) => {
  return await AssessmentBatchFacility.destroy({
    where: { id: ids },
  });
};

export const deleteAll = async (batch_id: number) => {
  return await AssessmentBatchFacility.destroy({
    where: { batch_id },
  });
};

// deletes assessment batch by batch_id
export const deleteManyByBatchId = async (batch_id: number) => {
  return await AssessmentBatchFacility.destroy({
    where: { batch_id },
  });
};

// retrieves the assessment batch and facility information
export const getOne = async (id: number) => {
  return await AssessmentBatchFacility.findOne({
    include: {
      model: Facility,
      as: 'facility',
      include: [
        {
          model: FacilityType,
          as: 'facility_type',
          attributes: ['type'],
        },
        {
          model: LocationRegion,
          as: 'region',
          attributes: ['region_name'],
        },
        {
          model: LocationProvince,
          as: 'province',
          attributes: ['province_name'],
        },
        {
          model: LocationMunicipality,
          as: 'municipality',
          attributes: ['municipality_name'],
        },
      ],
    },
    where: { id },
  });
};

// retreieves the assessment batch facilities by batch id
export const getManyByBatchId = async (batch_id: number, token: string, query?: ApiQuery) => {
  const [limit, offset] = getLimitAndOffset(query);
  const current_user = await getUserByToken(token);
  const search = query?.search || '';

  let facilityWhereClause: any = {};

  if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: current_user.province_code,
    };
  }

  if (search) {
    facilityWhereClause = {
      ...facilityWhereClause,
      facility_name: { [Op.like]: `%${search}%` },
    };
  }

  return await AssessmentBatchFacility.findAndCountAll({
    include: {
      model: Facility,
      as: 'facility',
      required: true,
      include: [
        {
          model: FacilityType,
          as: 'facility_type',
          attributes: ['type'],
        },
        {
          model: LocationRegion,
          as: 'region',
          attributes: ['region_name'],
        },
        {
          model: LocationProvince,
          as: 'province',
          attributes: ['province_name'],
        },
        {
          model: LocationMunicipality,
          as: 'municipality',
          attributes: ['municipality_name'],
        },
      ],
      where: facilityWhereClause,
    },
    where: { batch_id },
    limit,
    offset,
  });
};

// retrieves all the facility details not in AssessmentBatchFacility
export const getFacilityNotInBatchAssessment = async (batch_id: number, token: string, query?: ApiQuery) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  const facilityIDs: number[] = await getFacilityIDsInBatchAssessment(batch_id);
  const search = query?.search || '';

  const facilityQuery: any = {};
  query?.facility_type && Number.isInteger(safeIntParse(query.facility_type))
    ? (facilityQuery['facility_type_id'] = safeIntParse(query.facility_type))
    : null;
  query?.municipality_code && query.municipality_code != ''
    ? (facilityQuery['municipality_code'] = query.municipality_code)
    : null;
  query?.province_code && query.province_code != '' ? (facilityQuery['province_code'] = query.province_code) : null;
  facilityQuery['region_code'] = current_user.region_code;

  if (search) facilityQuery['facility_name'] = { [Op.like]: `%${search}%` };

  let groupClause: any;
  if (query?.facility_group) {
    groupClause = {
      group_id: { [Op.in]: query?.facility_group },
    };
  }

  if (facilityIDs.length === 0)
    return await Facility.findAndCountAll({
      include: [
        {
          model: FacilityType,
          as: 'facility_type',
          attributes: ['type'],
        },
        {
          model: LocationRegion,
          as: 'region',
          attributes: ['region_name'],
        },
        {
          model: LocationProvince,
          as: 'province',
          attributes: ['province_name'],
        },
        {
          model: LocationMunicipality,
          as: 'municipality',
          attributes: ['municipality_name'],
        },
        {
          model: FacilityGroupAssignment,
          as: 'facility_group',
          where: groupClause,
        },
      ],
      where: facilityQuery,
      limit,
      offset,
    });

  facilityQuery['id'] = { [Op.notIn]: facilityIDs };
  return await Facility.findAndCountAll({
    include: [
      {
        model: FacilityType,
        as: 'facility_type',
        attributes: ['type'],
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
      {
        model: FacilityGroupAssignment,
        as: 'facility_group',
        where: groupClause,
      },
    ],
    where: facilityQuery,
    limit,
    offset,
  });
};

export const getFacilityAssessment = async (
  batch_id: number,
  indicator_id: number,
  token: string,
  facility_id?: number,
  for_dashboard?: boolean
) => {
  let whereClause: any = for_dashboard
    ? { batch_id, status: 'completed' }
    : { batch_id, indicator_id, status: 'completed' };
  if (facility_id) whereClause = { ...whereClause, facility_id };
  const current_user = await getUserByToken(token);

  let facilityWhereClause: any = {};
  if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      province_code: current_user.province_code,
    };
  }
  const facilityAssessmentRow = await FacilityAssessment.findAndCountAll({
    where: whereClause,
    include: [
      includeFacility(facilityWhereClause),
      {
        model: AssessmentIndicators,
        as: 'assessment_indicator',
        attributes: ['id', 'name'],
        required: true,
      },
    ],
    raw: true,
  });

  if (facilityAssessmentRow.count == 0) return for_dashboard ? [] : facilityAssessmentRow;

  const rows = facilityAssessmentRow.rows;
  const flatResponse = getAssessmentResponses(JSON.parse(rows[0].responses));

  if (for_dashboard) {
    return rows.map((assessment: any) => {
      const flatResponse = getAssessmentResponses(JSON.parse(assessment.responses));
      const row: any = {
        'Indicator Name': assessment['assessment_indicator.name'],
        'Facility ID': assessment['facility.id'],
        'Facility Code': assessment['facility.facility_code'],
        'Facility Name': assessment['facility.facility_name'],
        'Facility Type': assessment['facility.facility_type.type'],
        'With SBF': assessment['facility.with_sbf'] === 1 ? 1 : 0,
        Region: assessment['facility.region.region_name'],
        'Region Code': assessment['facility.region.region_code'],
        Province: assessment['facility.province.province_name'],
        'Province Code': assessment['facility.province.province_code'],
        Municipality: assessment['facility.municipality.municipality_name'],
        'Municipality Code': assessment['facility.municipality.municipality_code'],
      };
      flatResponse.forEach((response) => {
        row[response.field_code] = response.response;
      });
      return row;
    });
  } else {
    const csvHeaders = flatResponse.map((response) => {
      return makeCsvSafe(`${response.field_code} - ${response.field_name}`);
    });

    const csvFormatted =
      'Facility Code,Facility Name,Facility Type,With SBF,Region,Region Code,Province,Province Code,Municipality,Municipality Code,Projected Population,' +
      csvHeaders.join(',') +
      '\n' +
      rows
        .map((assessment: any) => {
          const flatResponse = getAssessmentResponses(JSON.parse(assessment.responses));
          const responses = flatResponse.map((response) =>
            response.response + '' ? makeCsvSafe(response.response + '') : ''
          );
          return (
            `${makeCsvSafe(assessment['facility.facility_code'])},` +
            `${makeCsvSafe(assessment['facility.facility_name'])},` +
            `${makeCsvSafe(assessment['facility.facility_type.type'])},` +
            `${assessment['facility.with_sbf'] === 1 ? 1 : 0},` +
            `${makeCsvSafe(assessment['facility.region.region_name'])},` +
            `${makeCsvSafe(assessment['facility.region.region_code'])},` +
            `${makeCsvSafe(assessment['facility.province.province_name'])},` +
            `${makeCsvSafe(assessment['facility.province.province_code'])},` +
            `${makeCsvSafe(assessment['facility.municipality.municipality_name'])},` +
            `${makeCsvSafe(assessment['facility.municipality.municipality_code'])},` +
            `${makeCsvSafe(assessment['facility.projected_population'])},` +
            responses.join(',')
          );
        })
        .join('\n');

    return {
      rows: rows,
      count: rows.length,
      csvFormatted,
    };
  }
};

export const getIndividualFacilityAssessment = async (
  batch_id: number,
  indicator_id: number,
  token: string,
  facility_id: number
) => {
  return getFacilityAssessment(batch_id, indicator_id, token, facility_id);
};

// retrieves all the facility ids not in AssessmentBatchFacility
export const getFacilityIDsInBatchAssessment = async (batch_id: number) => {
  const addedFacilities = await AssessmentBatchFacility.findAll({
    where: { batch_id },
    raw: true,
  });

  return addedFacilities.map((facility) => facility.facility_id) as number[];
};
