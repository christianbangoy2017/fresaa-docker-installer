import * as facilityReportEntryService from 'services/facility-report-entry.service';

import { FacilityReportEntry, Report, ReportEntry } from 'models';
import { ReportEntryInput, ReportEntryOuput } from 'models/ReportEntry';

import { ApiQuery } from 'interfaces';
import { Op } from 'sequelize';
import { Response } from 'express';
import { createBulkEntry } from './facility-report-entry.service';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

// get specific report entry by id
export const get = async (id: number) => {
  return ReportEntry.findByPk(id) as unknown as ReportEntryOuput;
};

// retrieves multiple report entries based on reportid
export const getReportEntriesByReportId = async (reportid: number, query: ApiQuery) => {
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';
  const whereClause = query.status ? { status: query.status } : {};
  return ReportEntry.findAndCountAll({
    include: {
      model: Report,
      as: 'report',
      attributes: ['name', 'dashboard_code'],
    },
    where: {
      report_id: reportid,
      [Op.or]: {
        month: { [Op.like]: `%${search}%` },
        '$report.name$': {
          [Op.like]: `%${search}%`,
        },
      },
      ...whereClause,
    },
    order: ['created_at'],
    limit,
    offset,
  });
};

export const getAllReportEntries = async (query: ApiQuery, token: string) => {
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';
  const whereClause = query.status ? { status: query.status } : {};
  const current_user = await getUserByToken(token);

  return ReportEntry.findAndCountAll({
    include: [
      {
        model: Report,
        as: 'report',
        attributes: ['name', 'dashboard_code'],
        where: { region_code: current_user.region_code },
        required: true,
      },
    ],
    where: {
      [Op.or]: {
        month: { [Op.like]: `%${search}%` },
        '$report.name$': {
          [Op.like]: `%${search}%`,
        },
      },
      ...whereClause,
    },
    order: [['report', 'name'], 'deadline'],
    limit,
    offset,
  });
};

export const getSummary = async (id: number) => {
  return ReportEntry.findOne({
    where: { id },
    attributes: ['deadline', 'month'],
    include: [
      {
        model: Report,
        as: 'report',
        attributes: ['name'],
      },
    ],
  });
};

export const getActiveReportEntries = async (query: ApiQuery, token: string) => {
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';

  return ReportEntry.findAndCountAll({
    include: {
      model: Report,
      as: 'report',
      attributes: ['name'],
    },
    where: {
      status: 'active',
      [Op.or]: {
        month: { [Op.like]: `%${search}%` },
        '$report.name$': {
          [Op.like]: `%${search}%`,
        },
      },
    },
    order: ['created_at'],
    limit,
    offset,
  });
};

export const create = async (request: ReportEntryInput) => {
  return ReportEntry.create(request).then((f) => get(f!.id));
};

export const update = async (id: number, request: any) => {
  return ReportEntry.update(request, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number | number[]) => {
  console.log('deleting report entry');
  /** Delete all facility report entries associated to report entry and so on */
  await facilityReportEntryService.deleteAllFacilityReportEntries(id);

  return ReportEntry.destroy({ where: { id }, force: true });
};

export const duplicateItem = async (request: ReportEntryInput) => {
  const facilityReportEntry = await FacilityReportEntry.findAll({
    where: { report_entry_id: request.id },
    raw: true,
  });

  const facilityIdList = facilityReportEntry.map((facility) => facility.facility_id);
  const newReportEntry = await ReportEntry.create({
    month: request.month,
    deadline: request.deadline,
    report_id: request.report_id,
    status: 'open',
  });

  return createBulkEntry(newReportEntry.id, facilityIdList);
};
