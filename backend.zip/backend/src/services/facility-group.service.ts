import {
  Facility,
  FacilityGroupIndicatorAssessor,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
  User,
  UserGroup,
} from 'models';
import { FacilityAssessment, FacilityGroup, FacilityGroupAssignment, FacilityType } from 'models';
import { Op, literal, or } from 'sequelize';
import { UserAttributesArray, UserOutput } from 'models/User';

import { ApiQuery } from 'interfaces';
import { FacilityGroupOuput } from 'models/FacilityGroup';
import { STATUS } from './assessment.service';
import { UserFilter } from 'interfaces/user.interface';
import { createActivityLog } from './activity-log.service';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return FacilityGroup.findByPk(id) as unknown as FacilityGroupOuput;
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  const search = query.search || '';

  let location_filter: any = { region_code: current_user.region_code };
  if (current_user.user_group.level === 'Provincial') {
    location_filter = {
      ...location_filter,
      province_code: current_user.province_code,
    };
  }

  let group_ids = [];
  if (search) {
    group_ids = (
      await FacilityGroupAssignment.findAll({
        include: {
          model: Facility,
          as: 'facility',
          attributes: ['id'],
          where: {
            [Op.or]: {
              facility_name: {
                [Op.like]: `%${search}%`,
              },
              facility_code: {
                [Op.like]: `%${search}%`,
              },
            },
          },
          required: true,
        },
      })
    ).map((facility: any) => facility.group_id);
  }

  return FacilityGroup.findAndCountAll({
    limit,
    offset,
    distinct: true,
    where: {
      [Op.or]: {
        group_name: {
          [Op.like]: `%${search}%`,
        },
        id: group_ids,
      },
      ...location_filter,
    },
    include: [
      {
        model: User,
        as: 'assessor',
        attributes: [[literal('CONCAT(first_name, " ", last_name)'), 'assessor_name'], 'username'],
      },
      {
        model: FacilityGroupAssignment,
        as: 'facilities',
        attributes: ['facility_id', 'group_id'],
        required: false,
        include: [
          {
            model: Facility,
            as: 'facility',
            attributes: ['facility_name'],
          },
        ],
      },
      {
        model: FacilityGroupIndicatorAssessor,
        as: 'facility_group_indicator_assessor',
      },
    ],
  });
};

export const getListAssessor = async (token: string) => {
  const current_user = await getUserByToken(token);

  return User.findAndCountAll({
    where: { region_code: current_user.region_code, user_group_id: 5 },
    include: [
      {
        model: UserGroup,
        as: 'user_group',
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
    ],

    attributes: UserAttributesArray,
  });
};

// change the type
export const create = async (request: any, token: string) => {
  const current_user = await getUserByToken(token);

  request.region_code = current_user.region_code;
  if (current_user.user_group.level === 'Provincial') {
    request.province_code = current_user.province_code;
  }

  return FacilityGroup.create(request).then((f) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Create facility group: [' + request.group_name + ']',
      model: 'facility-group',
      model_id: f.id,
    };
    createActivityLog(payload);

    return get(f!.id);
  });
};

// change the type
export const update = async (id: number, request: any) => {
  const assessor_id = request.assessor_id;

  const result = await FacilityGroupAssignment.findAll({
    where: { group_id: id },
  });

  const facilityIds = result.map((record) => record.dataValues.facility_id);

  // Auto-update assessor
  // await FacilityAssessment.update(
  //   { assessor_id: assessor_id, status: STATUS.ASSIGNED },
  //   {
  //     where: {
  //       facility_id: facilityIds,
  //       status: [STATUS.OPEN, STATUS.ASSIGNED],
  //     },
  //   }
  // );

  return FacilityGroup.update(request, { where: { id } }).then(() => {
    const payload = {
      user_id: request.updated_by,
      activity: 'Update facility group: [' + request.group_name + ']',
      model: 'facility-group',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const updateDeletedBy = async (id: number, user_id: number) => {
  return await FacilityGroup.update({ deleted_by: user_id }, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number, current_user: UserOutput) => {
  const group = await get(id);
  return FacilityGroup.destroy({ where: { id } }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete facility group: [' + group?.group_name + ']',
      model: 'facility',
      model_id: id,
    };

    createActivityLog(payload);
    return u;
  });
};

export const deleteGroupWithFacilityAssigned = async (id: number, currentUserId: number) => {
  const transaction = await FacilityGroup.sequelize!.transaction();
  const group = await get(id);

  try {
    await FacilityGroup.destroy({ where: { id }, transaction });
    await FacilityGroupIndicatorAssessor.destroy({ where: { group_id: id } });
    await FacilityGroupAssignment.destroy({
      where: { group_id: id },
      transaction,
    });
    await transaction.commit().then((u) => {
      const payload = {
        user_id: currentUserId,
        activity: 'Delete facility group:  [' + group?.group_name + ']',
        model: 'facility-group',
        model_id: id,
      };

      createActivityLog(payload);

      return u;
    });
    return { success: true };
  } catch (error) {
    await transaction.rollback();
    throw error;
  }
};

export const getFacilitesInGroup = async (query: ApiQuery, token: string, id: number) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  const search = query.search || '';
  let whereClause: any = {};
  if (query.municipality_code) {
    whereClause = {
      municipality_code: query.municipality_code,
    };
  }

  if (query.facility_type) {
    whereClause = {
      ...whereClause,
      facility_type_id: query.facility_type,
    };
  }

  const result = await FacilityGroupAssignment.findAndCountAll({
    limit,
    offset,
    where: {
      group_id: id,
    },
    include: [
      {
        model: Facility,
        as: 'facility',
        include: [
          {
            model: LocationProvince,
            as: 'province',
            attributes: ['province_name'],
          },
          {
            model: LocationMunicipality,
            as: 'municipality',
            attributes: ['municipality_name'],
          },
          {
            model: FacilityType,
            as: 'facility_type',
            attributes: ['type'],
          },
        ],
        order: [['province', 'province_code', 'asc'], ['municipality', 'municipality_name', 'asc'], 'facility_name'],
        where: {
          [Op.or]: {
            facility_code: { [Op.like]: `%${search}%` },
            facility_name: { [Op.like]: `%${search}%` },
          },
          ...whereClause,
        },
      },
    ],
  });
  const facilities = result.rows.map((row: any) => ({
    id: row.id,
    facility_name: row.facility.facility_name,
    facility_code: row.facility.facility_code,
    gis_code: row.facility.gis_code,
    facility_type_id: row.facility.facility_type_id,
    region_code: row.facility.region_code,
    province_code: row.facility.province_code,
    assignment_id: row.id,
    group_id: row.group_id,
    managing_authority: row.facility.managing_authority,
    province: row.facility.province.province_name,
    municipality: row.facility.municipality.municipality_name,
    facility_type: row.facility.facility_type.type,
    barangay_name: row.facility.barangay_name,
  }));

  return {
    count: result.count,
    rows: facilities,
  };
};
