import { ApiQuery } from 'interfaces';
import { ReportTemplate } from 'models';
import { ReportTemplateInput } from 'models/ReportTemplate';
import { ReportTemplateEntryOutput } from 'models/ReportTemplateEntry';
import { Op } from 'sequelize';
import { getLimitAndOffset } from 'utils';

export const get = async (id: number) => {
  return ReportTemplate.findByPk(id) as unknown as ReportTemplateEntryOutput;
};

export const getAll = async (query: ApiQuery) => {
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';

  return ReportTemplate.findAndCountAll({
    where: {
      [Op.or]: {
        template_name: { [Op.like]: `%${search}%` },
        template_code: { [Op.like]: `%${search}%` },
        region_code: { [Op.like]: `%${search}%` },
      },
    },
    limit,
    offset,
  });
};

export const create = async (request: ReportTemplateInput) => {
  return ReportTemplate.create(request);
};

export const update = async (id: number, data: ReportTemplateInput) => {
  return ReportTemplate.update(data, { where: { id } }).then(() => get(id));
};

export const deleteOne = async (id: number) => {
  return ReportTemplate.destroy({
    where: { id },
  });
};
