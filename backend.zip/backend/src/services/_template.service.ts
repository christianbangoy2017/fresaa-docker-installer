import { ApiQuery } from 'interfaces';
import { Facility } from 'models';
import { FacilityOuput } from 'models/Facility';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return Facility.findByPk(id) as unknown as FacilityOuput;
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  return Facility.findAndCountAll({
    where: { region_code: current_user.region_code },
    order: ['province_code', 'facility_name'],
    limit,
    offset,
  }) as unknown as FacilityOuput;
};

// change the type
export const create = async (request: any, token: string) => {
  const current_user = await getUserByToken(token);
  request.region_code = request.region_code ? request.region_code : current_user.region_code;
  request.province_code = request.province_code ? request.province_code : current_user.province_code;
  return Facility.create(request).then((f) => get(f!.id));
};

// change the type
export const update = async (id: number, request: any) => {
  return Facility.update(request, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number) => {
  return Facility.destroy({ where: { id } });
};
