import { AssessmentResponse, Facility } from 'models';

import { FacilityOuput } from 'models/Facility';
import { groupArrayIntoSubarrays } from 'utils';

export const get = async (id: number) => {
  return Facility.findByPk(id) as unknown as FacilityOuput;
};

export const saveResponses = async (assessment_id: number, data: any) => {
  await AssessmentResponse.destroy({ where: { assessment_id } });
  const subarrays = groupArrayIntoSubarrays(data, 100);
  subarrays.map(async (subarray) => {
    await delay(500);
    await AssessmentResponse.bulkCreate(subarray);
  });
  return data.length;
};

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));
