import { AssessmentComment, Facility, FacilityAssessment, User } from 'models';

import { createActivityLog } from './activity-log.service';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return AssessmentComment.findByPk(id);
};

export const getAll = async () => {
  return AssessmentComment.findAndCountAll({
    include: [
      {
        model: User,
        as: 'user',
        attributes: ['username', 'first_name', 'last_name'],
        required: true,
      },
    ],
    order: ['field_code'],
  });
};

export const getMultiple = async (assessment_id: number) => {
  return AssessmentComment.findAndCountAll({
    where: {
      assessment_id,
    },
    include: [
      {
        model: User,
        as: 'user',
        attributes: ['username', 'first_name', 'last_name'],
        required: true,
      },
    ],
    order: ['field_code'],
  });
};

export const create = async (request: AssessmentComment, token: string) => {
  const current_user = await getUserByToken(token);
  request.user_id = current_user.id;

  const assessment = await FacilityAssessment.findOne({
    where: {
      id: request.assessment_id,
    },
    include: [
      {
        model: Facility,
        as: 'facility',
        attributes: ['facility_name'],
      },
    ],
  });

  return AssessmentComment.create(request).then((f) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Create assessment comment in: ' + request.field_code + ' [' + assessment?.facility.facility_name + ']',
      model: 'assessment-comment',
      model_id: f.id,
    };
    createActivityLog(payload);

    return get(f!.id);
  });
};

export const update = async (id: number, user_id: number, request: AssessmentComment) => {
  return AssessmentComment.update(request, { where: { id, user_id } }).then(() => get(id));
};

export const updateStatus = async (request: any, id: number, status: string, token: string) => {
  const current_user = await getUserByToken(token);
  const comment = await get(id);

  const assessment = await FacilityAssessment.findOne({
    where: {
      id: comment?.assessment_id,
    },
    include: [
      {
        model: Facility,
        as: 'facility',
        attributes: ['facility_name'],
      },
    ],
  });

  return AssessmentComment.update({ status }, { where: { id } }).then((f) => {
    const payload = {
      user_id: current_user.id,
      activity:
        'Update assessment comment status in: ' + comment?.field_code + ' [' + assessment?.facility.facility_name + ']',
      model: 'assessment-comment',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const updateAllStatus = async (assessment_id: number, field_code: string, token: string) => {
  const current_user = await getUserByToken(token);

  const assessment = await FacilityAssessment.findOne({
    where: {
      id: assessment_id,
    },
    include: [
      {
        model: Facility,
        as: 'facility',
        attributes: ['facility_name'],
      },
    ],
  });

  return AssessmentComment.update({ status: 'resolved' }, { where: { assessment_id, field_code } }).then(() => {
    const payload = {
      user_id: current_user.id,
      activity: 'Resolve all comments in: ' + field_code + ' [' + assessment?.facility.facility_name + ']',
      model: 'assessment-comment',
    };

    createActivityLog(payload);

    return getMultiple(assessment_id);
  });
};

export const deleteItem = async (id: number, user_id: number) => {
  return AssessmentComment.destroy({ where: { id, user_id } });
};
