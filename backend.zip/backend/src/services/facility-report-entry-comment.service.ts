import { FacilityReportEntryComment, FacilityReportEntry, Facility, User } from 'models';
import { FacilityReportEntryCommentInput } from 'models/FacilityReportEntryComment';
import { createActivityLog } from './activity-log.service';
import { getUserByToken } from './user.service';

export const getOneComment = async (id: number) => {
  return FacilityReportEntryComment.findByPk(id);
};

export const getAll = async () => {
  return FacilityReportEntryComment.findAndCountAll({
    order: ['field_code'],
  });
};

export const getCommentsByFacilityReportEntryId = async (facility_report_entry_id: number | number[]) => {
  return FacilityReportEntryComment.findAndCountAll({
    where: { facility_report_entry_id },
    include: [
      {
        model: User,
        as: 'user',
        attributes: ['username', 'first_name', 'last_name'],
        required: true,
      },
    ],
    order: ['field_code'],
  });
};

export const create = async (token: string, commentDetails: FacilityReportEntryCommentInput) => {
  const userDetails = await getUserByToken(token);
  commentDetails.user_id = userDetails.id;
  commentDetails.status  = 'open';

  const commentData = await FacilityReportEntryComment.create(commentDetails)

  const date = new Date();
  const time = `${date.getHours()}:${date.getMinutes()}`;
  createActivityLog({
    user_id: userDetails.id,
    activity: `[FacilityReportEntry Comment created (${time})] User: ${userDetails.first_name}, ${userDetails.last_name}`,
    model: 'facility-report-entry-comment',
    model_id: commentData.id,
  });

  return getOneComment(commentData.id);
};

export const deleteComment = async (id: number, token: string) => {
  const userDetails = await getUserByToken(token);
  const removedComment = await FacilityReportEntryComment.destroy({ where: { id }, force: true });

  if (removedComment) {
    const date = new Date();
    const time = `${date.getHours()}:${date.getMinutes()}`;
    createActivityLog({
      user_id: userDetails.id,
      activity: `[FacilityReportEntry Comment updated (${time})] User: ${userDetails.first_name}, ${userDetails.last_name}`,
      model: 'facility-report-entry-comment',
      model_id: id,
    });

    return removedComment;
  }

  return null;
};

export const deleteCommentsOnFacilityReportEntry = async (facilityReportEntryIds: number[]) => {
  const removedComments = await FacilityReportEntryComment.destroy({
    where: { facility_report_entry_id: facilityReportEntryIds },
    force: true,
  });
  return removedComments;
};

export const updateComment = async (id: number, token: string, commentUpdate: string) => {
  const userDetails = await getUserByToken(token);
  const commentData = await FacilityReportEntryComment.update({ comment: commentUpdate }, { where: {id} });

  if (commentData) {
    const date = new Date();
    const time = `${date.getHours()}:${date.getMinutes()}`;
    createActivityLog({
      user_id: userDetails.id,
      activity: `[FacilityReportEntry Comment updated (${time})] User: ${userDetails.first_name}, ${userDetails.last_name}`,
      model: 'facility-report-entry-comment',
      model_id: id,
    });

    return getOneComment(id);
  }

  return null;
};

export const updateStatus = async (id: number, token: string, status: string) => {
  const userDetails = await getUserByToken(token);
  const update = await FacilityReportEntryComment.update({status}, {where: { id }});

  if (update) {
    const date = new Date();
    const time = `${date.getHours()}:${date.getMinutes()}`;
    createActivityLog({
      user_id: userDetails.id,
      activity: `[FacilityReportEntry Comment status updated (${time})] User: ${userDetails.first_name}, ${userDetails.last_name}`,
      model: 'facility-report-entry-comment',
      model_id: id,
    });

    return getOneComment(id);
  }

  return null;
};

export const updateAllStatus = async (facility_report_entry_id: number, field_code: string, token: string) => {
  const current_user = await getUserByToken(token);
  const facilityReportEntryDetails: any = await FacilityReportEntry.findOne({
    where: { id: facility_report_entry_id },
    include: [{
        model: Facility,
        as: 'facility',
        attributes: ['facility_name']
    }]
  });

  return FacilityReportEntryComment.update({ status: 'resolved' }, { where: { facility_report_entry_id }}).then(() => {
    const payload = {
      user_id: current_user.id,
      activity: 'Resolve all comments in: ' + field_code + ' [' + facilityReportEntryDetails?.facility.facility_name + ']',
      model: 'facility-repoty-entry-comment',
    };

    createActivityLog(payload);
    return getCommentsByFacilityReportEntryId(facility_report_entry_id);
  });
};
