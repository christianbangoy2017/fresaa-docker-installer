require('dotenv').config();

import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';

import {
  BlacklistedToken,
  FailedLoginAttempt,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
  RefreshToken,
  User,
  UserGroup,
} from 'models';
import { UserAttributesArray, UserCredential } from 'models/User';

import { QueryTypes } from 'sequelize';
import { Response } from 'express';
import { UserAuthorityModel } from 'interfaces/user.interface';
import { getUserById } from './user.service';
import sequelizeConnection from 'db/config';

const jwtSecret = process.env.JWT_SECRET as string;
const jwtAccessTokenExp = parseInt(process.env.JWT_ACCESS_TOKEN_EXP as string);
const jwtRefreshTokenExp = parseInt(process.env.JWT_REFRESH_TOKEN_EXP as string);
const { v4: uuidv4 } = require('uuid');

const MAX_ATTEMPTS = 5;
const BASE_LOCKOUT_TIME = 30000; // 30 sec in milliseconds

export const login = ({ username, password }: UserCredential) => {
  return User.findOne({
    include: [
      {
        model: UserGroup,
        as: 'user_group',
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
    ],
    where: { username },
    attributes: [...UserAttributesArray, 'password'],
  }).then(async (u) => {
    if (u) {
      const { id, username, user_group_id } = u!;
      const failedAttempt = await getFailedAttempts(username);
      const lockoutTime = calculateLockoutTime(failedAttempt.attempts);
      const timeSinceLastAttempt = new Date().getTime() - new Date(failedAttempt.last_attempt).getTime();

      if (lockoutTime > 0 && timeSinceLastAttempt < lockoutTime) {
        return {
          error: `Too many failed attempts. Please try again in ${(lockoutTime / 1000).toFixed(0)} seconds.`,
        };
      }

      const matched = await bcrypt.compare(password, u!.password);
      if (!matched) {
        await incrementFailedAttempts(username);
        const nextLockout = calculateLockoutTime(failedAttempt.attempts + 1);
        return {
          error: `Invalid credentials. Please try again${
            nextLockout > 0 ? ` in ${(nextLockout / 1000).toFixed(0)} seconds.` : '.'
          }`,
        };
      }

      const auths: UserAuthorityModel[] = await sequelizeConnection.query(
        `
        SELECT ua.authority FROM user_authorities AS ua 
        LEFT JOIN user_group_authorities AS uga ON uga.user_authority_id = ua.id 
        WHERE uga.user_group_id = ?;
      `,
        {
          replacements: [user_group_id],
          type: QueryTypes.SELECT,
        }
      );

      await resetFailedAttempts(username); // Reset on successful login
      const refreshToken = await createRefreshToken(u as User);

      u.password = '';
      return {
        accessToken: jwt.sign({ id, username }, jwtSecret, {
          expiresIn: jwtAccessTokenExp, // 1 min
        }),
        authorities: auths.map((a) => a.authority),
        refreshToken: refreshToken.token,
        user: u,
      };
    }
    return;
  });
};

export const createRefreshToken = async (user: User) => {
  let expiredAt = new Date();

  expiredAt.setSeconds(expiredAt.getSeconds() + jwtRefreshTokenExp);

  let _token = uuidv4();

  let refreshToken = await RefreshToken.create({
    token: _token,
    user_id: user.id,
    expiry_date: expiredAt,
  });

  return refreshToken;
};

export const verifyExpiration = (token: RefreshToken) => {
  return token.expiry_date.getTime() < new Date().getTime();
};

export const refreshToken = async (token: string) => {
  const refreshToken = await RefreshToken.findOne({
    where: { token },
  });

  if (!refreshToken) {
    throw new Error('Refresh token not found.');
  }

  if (verifyExpiration(refreshToken)) {
    RefreshToken.destroy({ where: { id: refreshToken.id } });
    throw new Error('Refresh token was expired. Please make a new signin request.');
  }

  const user = await getUserById(refreshToken.user_id);
  let newAccessToken = jwt.sign({ id: user.id, username: user.username }, jwtSecret, { expiresIn: jwtAccessTokenExp });

  return {
    accessToken: newAccessToken,
    refreshToken: refreshToken.token,
  };
};

const getFailedAttempts = async (username: string) => {
  const record = await FailedLoginAttempt.findOne({ where: { username } });
  return record ? record : { attempts: 0, last_attempt: new Date(0) };
};

const incrementFailedAttempts = async (username: string) => {
  const record = await FailedLoginAttempt.findOne({ where: { username } });
  console.log(username, record);
  if (record) {
    record.attempts += 1;
    record.last_attempt = new Date();
    await record.save();
  } else {
    await FailedLoginAttempt.create({ username, attempts: 1, last_attempt: new Date() });
  }
};

const resetFailedAttempts = async (username: string) => {
  await FailedLoginAttempt.destroy({ where: { username } });
};

const calculateLockoutTime = (attempts: number): number => {
  return attempts >= MAX_ATTEMPTS ? Math.pow(2, attempts - MAX_ATTEMPTS) * BASE_LOCKOUT_TIME : 0;
};

export const logout = async (token: string, res: Response) => {
  if (!token) return res.status(400).json({ message: 'No token provided' });

  const tomorrow = new Date();
  tomorrow.setHours(tomorrow.getHours() + 24);
  await BlacklistedToken.create({ token, expires_at: tomorrow });
  await RefreshToken.destroy({ where: { token } });
  return { message: 'user logged out' };
};
