import { UserGroupAuthority } from 'models';
import { UserGroupAuthorityOuput } from 'models/UserGroupAuthority';

export const get = async (id: number) => {
  return UserGroupAuthority.findByPk(id) as unknown as UserGroupAuthorityOuput;
};

export const createUserGroupAuthority = async (payload: any) => {
  const userGroupAuthPayload = {
    user_group_id: payload.user_group_id,
    user_authority_id: payload.user_authority_id,
  };
  return UserGroupAuthority.create(userGroupAuthPayload).then((f) => get(f!.user_group_id));
};

export const deleteItem = async (user_group_id: number) => {
  return UserGroupAuthority.destroy({ where: { user_group_id: user_group_id } }).then((u) => {
    return u;
  });
};
