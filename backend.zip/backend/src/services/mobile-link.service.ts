import { MobileLink } from 'models';
import { getUserByToken } from './user.service';

export const getLinkAvailable = async (token: string) => {
  const current_user = await getUserByToken(token);
  return await MobileLink.findOne({
    where: { active: true, region_code: current_user.region_code },
  });
};
