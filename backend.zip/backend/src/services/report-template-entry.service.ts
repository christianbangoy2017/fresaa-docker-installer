import { ApiQuery } from 'interfaces';
import { ReportTemplateEntry } from 'models';
import { ReportTemplateEntryInput } from 'models/ReportTemplateEntry';
import { Op } from 'sequelize';
import { getLimitAndOffset } from 'utils';

export const getOne = async (id: number) => {
  return ReportTemplateEntry.findByPk(id);
};

export const getEntriesByReportTemplateId = async (reportTemplateId: number, query: ApiQuery) => {
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';

  return ReportTemplateEntry.findAndCountAll({
    where: {
      template_id: reportTemplateId,
      [Op.or]: {
        full_name: { [Op.like]: `%${search}%` },
        first_name: { [Op.like]: `%${search}%` },
        last_name: { [Op.like]: `%${search}%` },
        middle_name: { [Op.like]: `%${search}%` },
        address: { [Op.like]: `%${search}%` },
        responses: { [Op.like]: `%${search}%` },
      },
    },
    limit,
    offset,
    order: ['created_at'],
  });
};

export const createReportTemplateEntry = async (payload: ReportTemplateEntryInput) => {
  return ReportTemplateEntry.create(payload);
};

export const updateReportTemplateEntry = async (id: number, payload: ReportTemplateEntryInput) => {
  return ReportTemplateEntry.update(payload, {
    where: { id },
  }).then(() => getOne(id));
};

export const deleteReportTemplateEntry = async (id: number) => {
  return ReportTemplateEntry.destroy({
    where: { id },
  });
};
