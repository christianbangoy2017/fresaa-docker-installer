import {
  AssessmentBatch,
  Facility,
  FacilityAssessment,
  FacilityType,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
  User,
} from 'models';
import { Op, QueryTypes } from 'sequelize';
import { getFresaaFile, getLimitAndOffset, getResponses } from 'utils';

import { ApiQuery } from 'interfaces';
import AssessmentIndicators from 'models/AssessmentIndicator';
import { FacilityAssessmentOuput } from 'models/FacilityAssessment';
import { Response } from 'express';
import { UserShortAttributesArray } from 'models/User';
import { createActivityLog } from './activity-log.service';
import { get as getAssessmentIndicator } from './assessment-indicator.service';
import { get as getBatch } from './assessment-batch.service';
import { getUserByToken } from './user.service';
import { get as getValidationWorkflow } from './form-validation-workflow.service';
import { includeFacility } from 'models/Facility';
import { saveResponses } from './assessment-response.service';
import sequelizeConnection from 'db/config';

export const STATUS = {
  OPEN: 'open',
  ASSIGNED: 'assigned',
  STARTED: 'started',
  SUBMITTED: 'submitted',
  REVIEWED: 'reviewed',
  PHO_APPROVED: 'pho-approved',
  COMPLETED: 'completed',
};

export const get = async (id: number, token?: string) => {
  let facilityWhereClause: any = {};
  let assessmentWhereClause: any = {
    id,
  };

  if (token) {
    const current_user = await getUserByToken(token);
    if (current_user.user_group.group_name === 'FA') {
      assessmentWhereClause = {
        ...assessmentWhereClause,
        assessor_id: current_user.id,
      };
    } else if (current_user.user_group.level === 'Municipal') {
      facilityWhereClause = {
        municipality_code: current_user.municipality_code,
      };
    } else if (current_user.user_group.level === 'Provincial') {
      facilityWhereClause = {
        province_code: current_user.province_code,
      };
    } else if (current_user.user_group.level === 'Facility') {
      assessmentWhereClause = {
        ...assessmentWhereClause,
        facility_id: current_user.facility_id,
      };
    }
  }

  return FacilityAssessment.findOne({
    where: assessmentWhereClause,
    include: [
      includeFacility(facilityWhereClause),
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
      {
        model: User,
        as: 'approver',
        attributes: UserShortAttributesArray,
      },
      {
        model: AssessmentBatch,
        as: 'assessment_batch',
        attributes: ['dashboard_code'],
      },
    ],
  }) as unknown as FacilityAssessmentOuput;
};

export const getList = async (query: ApiQuery, token: string, batch_id?: number) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search || '';

  let facilityWhereClause: any = {};

  const searchfilter = {
    [Op.or]: {
      '$facility.facility_name$': {
        [Op.like]: `%${search}%`,
      },
      '$assessment_batch.batch_name$': {
        [Op.like]: `%${search}%`,
      },
      '$assessment_indicator.name$': {
        [Op.like]: `%${search}%`,
      },
    },
  };

  if (query.facility_type) {
    facilityWhereClause = {
      ...facilityWhereClause,
      facility_type_id: query.facility_type,
    };
  }

  if (query.region_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      region_code: query.region_code,
    };
  }

  if (query.province_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: query.province_code,
    };
  }

  if (query.municipality_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: query.municipality_code,
    };
  }

  if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: current_user.province_code,
    };
  } else if (current_user.user_group.level === 'Municipal') {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: current_user.municipality_code,
    };
  } else {
    facilityWhereClause = {
      ...facilityWhereClause,
      region_code: current_user.region_code,
    };
  }

  let whereClause = {};
  if (batch_id) {
    whereClause = { batch_id };
  }

  if (query.status) {
    whereClause = {
      ...whereClause,
      status: query.status,
    };
  }

  if (query.facility_id) {
    whereClause = {
      ...whereClause,
      facility_id: query.facility_id,
    };
  }

  if (current_user.user_group.group_name === 'FA') {
    whereClause = { ...whereClause, assessor_id: current_user.id };
  }

  return FacilityAssessment.findAndCountAll({
    include: [
      {
        model: AssessmentBatch,
        as: 'assessment_batch',
        attributes: ['batch_name', 'year'],
        required: true,
      },
      {
        model: AssessmentIndicators,
        as: 'assessment_indicator',
        attributes: ['id', 'name'],
        required: true,
      },
      {
        model: Facility,
        as: 'facility',
        include: [
          {
            model: FacilityType,
            as: 'facility_type',
            attributes: ['type'],
          },
          {
            model: LocationRegion,
            as: 'region',
            attributes: ['region_name'],
          },
          {
            model: LocationProvince,
            as: 'province',
            attributes: ['province_name'],
          },
          {
            model: LocationMunicipality,
            as: 'municipality',
            attributes: ['municipality_name'],
          },
        ],
        where: facilityWhereClause,
      },
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
    ],
    attributes: {
      exclude: ['signature'],
    },
    where: { ...whereClause, ...searchfilter },
    order: [['facility', 'facility_name', 'asc']],
    limit,
    offset,
  });
};

export const getAllApproved = async (batch_id?: number) => {
  return FacilityAssessment.findAll({
    attributes: ['id', 'batch_id', 'responses'],
    include: [
      {
        model: Facility,
        as: 'facility',
      },
    ],
    where: {
      batch_id,
      status: STATUS.PHO_APPROVED,
    },
    order: [['facility', 'facility_name', 'asc']],
  });
};

export const getActiveList = async (query: ApiQuery, token: string) => {
  const search = query.search || '';
  const [limit, offset] = getLimitAndOffset(query);
  const current_user = await getUserByToken(token);

  const activeBatches = (
    await AssessmentBatch.findAll({
      where: { status: 'active', region_code: current_user.region_code },
      attributes: ['id'],
    })
  ).map((batch) => batch.id);

  if (!activeBatches.length) {
    return [];
  }

  let filter: any = {};

  let whereClause: any = {
    batch_id: activeBatches,
  };

  if (query.status) {
    whereClause = { ...whereClause, status: query.status };
  }

  if (query.for_approval) {
    whereClause = { ...whereClause, current_step: current_user.user_group.group_name };
  }

  let facilityWhereClause: any = {
    region_code: current_user.region_code,
  };

  if (search) {
    filter = {
      ...filter,
      [Op.or]: {
        '$facility.facility_name$': {
          [Op.like]: `%${search}%`,
        },
        '$assessor.first_name$': {
          [Op.like]: `%${search}%`,
        },
        '$assessor.last_name$': {
          [Op.like]: `%${search}%`,
        },
        '$assessment_batch.batch_name$': {
          [Op.like]: `%${search}%`,
        },
        '$assessment_indicator.name$': {
          [Op.like]: `%${search}%`,
        },
      },
    };
  }

  if (query.facility_type) {
    facilityWhereClause = {
      ...facilityWhereClause,
      facility_type_id: query.facility_type,
    };
  }

  if (query.province_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: query.province_code,
    };
  }

  if (query.municipality_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: query.municipality_code.split(','),
    };
  }

  if (current_user.user_group.group_name === 'FA') {
    whereClause = {
      ...whereClause,
      assessor_id: current_user.id,
    };
  } else if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: current_user.province_code,
    };
  } else if (current_user.user_group.level === 'Municipal') {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: current_user.municipality_code,
    };
  }

  return [
    activeBatches,
    FacilityAssessment.findAndCountAll({
      include: [
        {
          model: Facility,
          as: 'facility',
          include: [
            {
              model: FacilityType,
              as: 'facility_type',
              attributes: ['type'],
            },
            {
              model: LocationRegion,
              as: 'region',
              attributes: ['region_name'],
            },
            {
              model: LocationProvince,
              as: 'province',
              attributes: ['province_name'],
            },
            {
              model: LocationMunicipality,
              as: 'municipality',
              attributes: ['municipality_name'],
            },
          ],
          where: facilityWhereClause,
        },
        {
          model: User,
          as: 'assessor',
          attributes: UserShortAttributesArray,
        },
        {
          model: User,
          as: 'reviewer',
          attributes: UserShortAttributesArray,
        },
        {
          model: User,
          as: 'approver',
          attributes: UserShortAttributesArray,
        },
        {
          model: User,
          as: 'dmo_approver',
          attributes: UserShortAttributesArray,
        },
        {
          model: AssessmentBatch,
          as: 'assessment_batch',
          attributes: ['id', 'batch_name'],
        },
        {
          model: AssessmentIndicators,
          as: 'assessment_indicator',
          attributes: ['id', 'name'],
        },
      ],
      where: {
        ...filter,
        ...whereClause,
      },
      order: [['facility', 'facility_name', 'asc']],
      attributes: {
        exclude: ['responses', 'signature', 'draft_responses'],
      },
      limit,
      offset,
    }),
  ];
};

export const getActiveFromStatus = async (token: string, status: string, query?: ApiQuery) => {
  const current_user = await getUserByToken(token);
  const user_group = current_user.user_group.group_name;

  const activeBatches = (
    await AssessmentBatch.findAll({
      where: { status: 'active', region_code: current_user.region_code },
    })
  ).map((batch) => batch.id);

  if (!activeBatches.length) {
    return 0;
  }

  let facilityWhereClause: any = { region_code: current_user.region_code };

  // for location filter
  if (query?.facility_type) {
    facilityWhereClause = {
      ...facilityWhereClause,
      facility_type_id: query.facility_type,
    };
  }
  if (query?.province_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: query.province_code,
    };
  }
  if (query?.municipality_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: query.municipality_code,
    };
  }

  let whereClause: any = {};

  if (query?.status) {
    //for location filter
    whereClause = {
      status: query.status,
      batch_id: activeBatches,
    };
  } else {
    whereClause = {
      status: status,
      batch_id: activeBatches,
    };
  }

  if (user_group === 'FA') {
    whereClause = {
      ...whereClause,
      assessor_id: current_user.id,
    };
  } else if (user_group === 'MHO/PHN') {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: current_user.municipality_code,
    };
  } else if (user_group === 'PHO') {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: current_user.province_code,
    };
  }

  if (query?.for_approval) {
    whereClause = { ...whereClause, current_step: current_user.user_group.group_name };
  }

  if (query?.status && query?.status != status) {
    //for location filter to only focus on status given by LocationFilter if available
    return 0;
  } else {
    return await FacilityAssessment.count({
      include: [
        {
          model: Facility,
          as: 'facility',
          where: facilityWhereClause,
        },
      ],
      where: whereClause,
    });
  }
};

// NOT USED
export const create = async (request: any, batch_id: number, token: string, res: Response) => {
  const current_user = await getUserByToken(token);

  const batch = await getBatch(batch_id);
  if (!batch) {
    res.status(400).send({
      message: 'Unable to find batch. Make sure the assessment batch is active.',
    });
    return;
  }

  const indicators: any = await AssessmentBatch.findOne({
    where: { id: batch_id },
    include: [
      {
        model: AssessmentIndicators,
        as: 'indicator',
        attributes: ['indicators'],
      },
    ],
  });

  if (!indicators) {
    res.status(400).send({
      message: 'Unable to create assessment.',
    });
    return;
  }

  let facilities: any = [];
  if (request.facilities === 'all') {
    const included = (
      await FacilityAssessment.findAll({
        where: { batch_id },
      })
    ).map((assessment) => assessment.facility_id);

    facilities = await sequelizeConnection.query(
      `
        SELECT f.*, fg.assessor_id, ft.type, lm.municipality_name, lp.province_name, lr.region_name
        FROM facilities AS f
        LEFT JOIN facility_group_assignment AS fga ON fga.facility_id = f.id
        LEFT JOIN facility_group_indicator_assessors AS fgia ON fgia.group_id = fga.group_id  AND fgia.indicator_id = ?
        LEFT JOIN facility_groups AS fg ON fg.id = fga.group_id
        LEFT JOIN facility_types AS ft ON ft.id = f.facility_type_id
        LEFT JOIN location_municipalities AS lm ON lm.municipality_code = f.municipality_code
        LEFT JOIN location_provinces AS lp ON lp.province_code = f.province_code
        LEFT JOIN location_regions AS lr ON lr.region_code = f.region_code
        WHERE f.region_code = ? ${included.length ? 'AND f.id NOT IN (?)' : ''} AND f.deleted_at IS NULL
    `,
      {
        replacements: [indicators.indicator_id, current_user.region_code, included],
        type: QueryTypes.SELECT,
      }
    );
  } else {
    facilities = await sequelizeConnection.query(
      `
        SELECT f.*, fg.assessor_id, ft.type, lm.municipality_name, lp.province_name, lr.region_name 
        FROM facilities AS f
        LEFT JOIN facility_group_assignment AS fga ON fga.facility_id = f.id
        LEFT JOIN facility_group_indicator_assessors AS fgia ON fgia.group_id = fga.group_id  AND fgia.indicator_id = ?
        LEFT JOIN facility_groups AS fg ON fg.id = fga.group_id
        LEFT JOIN facility_types AS ft ON ft.id = f.facility_type_id
        LEFT JOIN location_municipalities AS lm ON lm.municipality_code = f.municipality_code
        LEFT JOIN location_provinces AS lp ON lp.province_code = f.province_code
        LEFT JOIN location_regions AS lr ON lr.region_code = f.region_code
        WHERE f.id IN (?) AND f.deleted_at IS NULL
    `,
      {
        replacements: [indicators.indicator_id, request.facilities],
        type: QueryTypes.SELECT,
      }
    );
  }
  const data = facilities.map((facility: any) => {
    return {
      facility_id: facility.id,
      batch_id: batch_id,
      assessor_id: facility.assessor_id,
      status: facility.assessor_id ? STATUS.ASSIGNED : STATUS.OPEN,
      responses: JSON.stringify(getFresaaFile(JSON.parse(indicators.indicator.indicators), facility)),
      created_by: current_user.id,
    };
  }) as FacilityAssessment[];
  return FacilityAssessment.bulkCreate(data).then(() => {
    const payload = {
      user_id: current_user.id,
      activity:
        'Add facility to batch - [' + batch?.batch_name + ']: ' + facilities.map((facility: any) => facility.id),
      model: 'facility-assessment',
    };
    createActivityLog(payload);
  });
};

export const updateAssessor = async (id: number, assessor_id: number) => {
  return FacilityAssessment.update({ assessor_id, status: STATUS.ASSIGNED }, { where: { id } }).then(() => get(id));
};

export const updateDeletedBy = async (id: number, user_id: number) => {
  return await FacilityAssessment.update({ deleted_by: user_id }, { where: { id } }).then(() => get(id));
};

export const startAssessment = async (id: number, token: string) => {
  const current_user = await getUserByToken(token);

  const assessment = await FacilityAssessment.findByPk(id);
  const facility = await Facility.findByPk(assessment?.facility_id);

  return FacilityAssessment.update(
    { status: STATUS.STARTED, started_at: new Date() },
    { where: { id, assessor_id: current_user.id } }
  ).then(() => {
    const payload = {
      user_id: current_user.id,
      activity: 'Start assessment: ' + facility?.facility_name,
      model: 'facility-assessment',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const deleteItem = async (id: number, token: string) => {
  const current_user = await getUserByToken(token);
  const facilities: any = await sequelizeConnection.query(
    `
      SELECT fa.id FROM facilities AS f
      LEFT JOIN facility_assessments AS fa ON fa.facility_id = f.id
      WHERE f.region_code = ? AND fa.id IN (?) AND f.deleted_at IS NULL
  `,
    {
      replacements: [current_user.region_code, [id]],
      type: QueryTypes.SELECT,
    }
  );
  const ids = facilities.map((facility: any) => facility.id);
  return await FacilityAssessment.destroy({
    where: { id: ids, status: [STATUS.OPEN, STATUS.ASSIGNED, STATUS.STARTED] },
  });
};

export const getStepsFromAssessmentIndicator = async (id: number): Promise<string[] | undefined> => {
  const assessmentIndicator = await getAssessmentIndicator(id);
  if (assessmentIndicator) {
    const validationWorkflow = await getValidationWorkflow(assessmentIndicator?.validation_workflow_id);
    return JSON.parse(validationWorkflow.steps);
  }
};

export const submitAssessment = async (id: number, data: any, token: string) => {
  const current_user = await getUserByToken(token);
  let current_step = data.current_step;
  let status = data.status;
  let approved_at;

  let assessment = await get(id);

  const steps = await getStepsFromAssessmentIndicator(assessment.indicator_id);

  current_step = steps ? steps[1] : null;
  status = current_step === 'Complete' ? STATUS.COMPLETED : STATUS.SUBMITTED;

  if (status === STATUS.COMPLETED) {
    approved_at = new Date();
  }
  await FacilityAssessment.update(
    {
      ...data,
      status,
      submitted_at: new Date(),
      updated_by: current_user.id,
      current_step,
      approved_at,
    },
    {
      where: {
        id,
        status: [STATUS.STARTED],
        assessor_id: current_user.id,
      },
    }
  );

  assessment = await get(id);
  const facility = await Facility.findByPk(assessment?.facility_id);
  const flatResponse = getResponses(assessment, current_user);
  await saveResponses(id, flatResponse);

  const payload = {
    user_id: current_user.id,
    activity: 'Submit assessment: ' + facility?.facility_name,
    model: 'facility-assessment',
    model_id: id,
  };
  createActivityLog(payload);

  return assessment;
};

export const saveDraftAssessment = async (id: number, data: any, token: string) => {
  const current_user = await getUserByToken(token);
  await FacilityAssessment.update(
    { ...data },
    {
      where: {
        id,
        assessor_id: current_user.id,
      },
    }
  );

  const assessment = await get(id);
  return assessment;
};

export const approveAssessment = async (id: number, token: string, res: Response) => {
  const current_user = await getUserByToken(token);
  const assessment = await FacilityAssessment.findByPk(id);
  const facility = await Facility.findByPk(assessment?.facility_id);

  if (assessment?.current_step !== current_user.user_group.group_name) {
    res.status(400).send({
      message: 'You are not authorized to perform this action.',
    });
    return;
  }

  let current_step = assessment?.current_step;
  let approved_at;
  let status = assessment?.status;
  if (assessment && current_step) {
    const steps = await getStepsFromAssessmentIndicator(assessment.indicator_id);
    const currentStepIndex = steps?.indexOf(current_step);
    if (steps && currentStepIndex !== undefined) {
      if (steps && currentStepIndex !== undefined) {
        if (currentStepIndex < 0) current_step = steps[1];
        else current_step = steps[currentStepIndex + 1];
      }
    }
    status = current_step === 'Complete' ? STATUS.COMPLETED : 'ongoing-approval';
    if (status === STATUS.COMPLETED) {
      approved_at = new Date();
    }
  }

  return FacilityAssessment.update(
    {
      status,
      current_step,
      approver_id: current_user.id,
      approved_at,
    },
    { where: { id } }
  ).then(() => {
    const payload = {
      user_id: current_user.id,
      activity: 'Review assessment: ' + facility?.facility_name,
      model: 'facility-assessment',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const returnAssessment = async (token: string, id: number, request: any) => {
  const current_user = await getUserByToken(token);
  const data: any = {};

  if (current_user.user_group.group_name === 'MHO/PHN') {
    data.mho_notes = request.note;
  } else if (current_user.user_group.group_name === 'PHO') {
    data.pho_notes = request.note;
  } else if (current_user.user_group.group_name === 'DMO') {
    data.dmo_notes = request.note;
  }

  if (request.return_to_fa) {
    data.status = STATUS.STARTED;
    data.current_step = '';
  }

  return FacilityAssessment.update(data, { where: { id } }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: request.return_to_fa ? 'Return assessment to assessor' : 'Add Remarks',
      model: 'facility-assessment',
    };

    createActivityLog(payload);
    return u;
  });
};

export const removeFacilityFromGroup = async (request: any, token: string) => {
  const facilities_arr = JSON.parse(request.facilities);
  const current_user = await getUserByToken(token);

  const assessment = await FacilityAssessment.findOne({
    where: { id: facilities_arr[0] },
  });

  const batch = assessment && (await getBatch(assessment.batch_id));
  // ANDRES { facilities: '16' }

  const facilities: any = await sequelizeConnection.query(
    `
      SELECT fa.id, fa.facility_id FROM facilities AS f
      LEFT JOIN facility_assessments AS fa ON fa.facility_id = f.id
      WHERE f.region_code = ? AND fa.id IN (?) AND f.deleted_at IS NULL
  `,
    {
      replacements: [current_user.region_code, facilities_arr],
      type: QueryTypes.SELECT,
    }
  );
  const ids = facilities.map((facility: any) => facility.id);
  const facility_id = facilities.map((facility: any) => facility.facility_id);

  return await FacilityAssessment.destroy({
    where: { id: ids, status: [STATUS.OPEN, STATUS.ASSIGNED] },
  }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Remove facility from batch - [' + batch?.batch_name + ']: ' + facility_id,
      model: 'facility-assessment',
    };

    createActivityLog(payload);
    return u;
  });
};

export const getAllByFacilityId = async (token: string, query?: ApiQuery) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  const search = query?.search?.trim() ?? '';

  let filter: any = {};
  if (query?.status) {
    filter = {
      status: query.status,
    };
  }

  return FacilityAssessment.findAndCountAll({
    include: [
      {
        model: AssessmentBatch,
        as: 'assessment_batch',
        attributes: ['batch_name', 'year'],
      },
      {
        model: AssessmentIndicators,
        as: 'assessment_indicator',
        attributes: ['id', 'name'],
      },
      {
        model: Facility,
        as: 'facility',
        include: [
          {
            model: FacilityType,
            as: 'facility_type',
            attributes: ['type'],
          },
          {
            model: LocationRegion,
            as: 'region',
            attributes: ['region_name'],
          },
          {
            model: LocationProvince,
            as: 'province',
            attributes: ['province_name'],
          },
          {
            model: LocationMunicipality,
            as: 'municipality',
            attributes: ['municipality_name'],
          },
        ],
      },
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
    ],
    attributes: {
      exclude: ['responses', 'signature'],
    },
    where: {
      facility_id: current_user.facility_id,
      ...filter,
      [Op.or]: {
        '$assessment_batch.batch_name$': {
          [Op.like]: `%${search}%`,
        },
        '$assessment_indicator.name$': {
          [Op.like]: `%${search}%`,
        },
      },
    },
    order: [['facility', 'facility_name', 'asc']],
    limit,
    offset,
  });
};
