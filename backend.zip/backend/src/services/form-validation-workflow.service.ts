import FormValidationWorkflow, { FormValidationWorkflowOuput } from 'models/FormValidationWorkflow';

import { ApiQuery } from 'interfaces';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return FormValidationWorkflow.findByPk(id) as unknown as FormValidationWorkflowOuput;
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  return FormValidationWorkflow.findAndCountAll({
    where: { region_code: current_user.region_code },
    limit,
    offset,
  });
};

export const create = async (request: any) => {
  return FormValidationWorkflow.create(request).then((f) => get(f!.id));
};

export const update = async (id: number, request: any) => {
  return FormValidationWorkflow.update(request, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number) => {
  return FormValidationWorkflow.destroy({ where: { id } });
};
