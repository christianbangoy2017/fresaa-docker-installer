require('dotenv').config();

import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';

import { ApiQuery, PasswordParam, UserDropdownQuery } from 'interfaces';
import { Facility, LocationMunicipality, LocationProvince, LocationRegion, User, UserGroup } from 'models';
import { Op, QueryTypes } from 'sequelize';
import { UserAttributesArray, UserInput, UserOutput } from 'models/User';
import { UserAuthorityModel, UserFilter } from 'interfaces/user.interface';
import { getLimitAndOffset, removeBlankProperty } from 'utils';

import { createActivityLog } from './activity-log.service';
import { getUserGroupId } from './user-group.service';
import sequelizeConnection from 'db/config';

const jwtSecret = process.env.JWT_SECRET as string;
const saltRounds = parseInt(process.env.SALT_ROUNDS as string);

export const register = async (user: UserInput, token: string) => {
  const current_user = await getUserByToken(token);
  const user_group = await getUserGroupId(user.user_group_name);
  user.created_by = current_user.id;
  user.user_group_id = user_group.id;
  user.region_code = user.region_code ? user.region_code : current_user.region_code;
  user.province_code = user.province_code ? user.province_code : current_user.province_code;
  return bcrypt.hash(user.password, saltRounds).then((hash) => {
    user.password = hash;
    return User.create(user).then((u) => {
      // create activity log
      const payload = {
        user_id: current_user.id,
        activity: 'Create user: ' + user.username,
        model: 'user',
        model_id: u.id,
      };
      createActivityLog(payload);
      return getUserById(u!.id);
    });
  });
};

export const update = async (user_id: number, updater_id: number, user: UserInput) => {
  const userLogInstance = await User.findOne({
    where: {
      id: user_id,
    },
  });
  const updated = removeBlankProperty(user, ['email', 'middle_name', 'title', 'mobile_number']);
  const user_group = await getUserGroupId(user.user_group_name);
  updated.user_group_id = user_group.id;
  updated.updated_by = updater_id;
  if (updated.password) {
    return bcrypt.hash(updated.password, saltRounds).then((hash) => {
      updated.password = hash;
      return User.update(updated, { where: { id: user_id } }).then((u) => {
        const payload = {
          user_id: updater_id,
          activity: 'Update user: ' + userLogInstance?.username,
          model: 'user',
          model_id: user_id,
        };
        createActivityLog(payload);
        return getUserById(user_id);
      });
    });
  } else {
    return User.update(updated, { where: { id: user_id } }).then((u) => {
      const payload = {
        user_id: updater_id,
        activity: 'Update user: ' + userLogInstance?.username,
        model: 'user',
        model_id: user_id,
      };
      createActivityLog(payload);
      return getUserById(user_id);
    });
  }
};

export const updateDeletedBy = async (id: number, user_id: number) => {
  return await User.update({ deleted_by: user_id }, { where: { id } });
};

export const deleteItem = async (id: number, current_user: UserOutput) => {
  const user = await User.findOne({
    where: {
      id,
    },
  });

  return User.destroy({ where: { id, region_code: current_user.region_code } }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete user: ' + user?.username,
      model: 'user',
      model_id: id,
    };

    createActivityLog(payload);
    return u;
  });
};

export const changePassword = async (passwords: PasswordParam, token: string) => {
  const decoded = (await jwt.verify(token, jwtSecret)) as any;
  const user_id = decoded.id;

  return User.findByPk(user_id).then(async (user) => {
    const matched = await bcrypt.compare(passwords.old_password, user!.password);

    if (!matched) {
      throw new Error('Invalid password');
    } else {
      return bcrypt.hash(passwords.new_password, saltRounds).then(async (hash) => {
        await User.update({ password: hash }, { where: { id: user_id } });
        return {
          message: 'Password updated',
        };
      });
    }
  });
};

export const getUserList = async (query: ApiQuery, token: string, scope: 'R' | 'P' | 'A') => {
  const user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  let filter: any = {};
  const search = query.search?.trim() || '';

  if (query.region_code) {
    filter = {
      ...filter,
      region_code: query.region_code,
    };
  }

  if (query.province_code) {
    filter = {
      ...filter,
      province_code: query.province_code,
    };
  }

  if (query.municipality_code) {
    filter = {
      ...filter,
      municipality_code: query.municipality_code,
    };
  }

  if (query.facility_id) {
    filter = {
      ...filter,
      facility_id: query.facility_id,
    };
  }

  if (scope === 'R') {
    filter = {
      ...filter,
      region_code: user?.region_code,
    };
  } else if (scope === 'P') {
    filter = {
      ...filter,
      province_code: user?.province_code,
    };
  }

  return User.findAndCountAll({
    where: {
      ...filter,
      [Op.or]: {
        username: {
          [Op.like]: `%${search}%`,
        },
        first_name: {
          [Op.like]: `%${search}%`,
        },
        middle_name: {
          [Op.like]: `%${search}%`,
        },
        last_name: {
          [Op.like]: `%${search}%`,
        },
        '$province.province_name$': {
          [Op.like]: `%${search}%`,
        },
        '$region.region_name$': {
          [Op.like]: `%${search}%`,
        },
        '$municipality.municipality_name$': {
          [Op.like]: `%${search}%`,
        },
      },
    },
    include: [
      {
        model: UserGroup,
        as: 'user_group',
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
      {
        model: Facility,
        as: 'facility',
        attributes: ['id', 'facility_name', 'facility_code'],
      },
    ],
    order: ['user_group_id', 'first_name'],
    limit,
    offset,
    attributes: UserAttributesArray,
  });
};

export const getUserListDropdown = async (token: string, query: UserDropdownQuery) => {
  const user = await getUserByToken(token);
  let usergroup = JSON.parse(query.type!);
  let province_code: string = user?.province_code;

  if (query.facility_id) {
    const facility = await Facility.findByPk(query.facility_id);
    if (facility) province_code = facility.province_code;
  }

  return User.findAll({
    where: { province_code },
    include: [
      {
        model: UserGroup,
        as: 'user_group',
        where: {
          group_name: usergroup,
        },
      },
    ],
    order: ['first_name'],
    attributes: ['id', 'first_name', 'middle_name', 'last_name', 'title', 'username'],
  });
};

// UTILS
export const getUserById = (id: number) => {
  return User.findByPk(id, {
    attributes: UserAttributesArray,
    include: [
      {
        model: UserGroup,
        as: 'user_group',
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
    ],
  }) as unknown as UserOutput;
};

export const getUserByToken = async (token: string) => {
  const decoded = (await jwt.verify(token, jwtSecret)) as any;
  return User.findByPk(decoded.id, {
    attributes: UserAttributesArray,
    include: [
      {
        model: UserGroup,
        as: 'user_group',
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name', 'region_logo', 'region_logo_dark'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
      {
        model: Facility,
        as: 'facility',
        attributes: ['id', 'facility_name', 'facility_code'],
      },
    ],
  }) as unknown as UserOutput;
};

export const getUserAuthorities = async (id: number) => {
  const auths: UserAuthorityModel[] = await sequelizeConnection.query(
    `
    SELECT ua.authority FROM user_authorities AS ua 
    LEFT JOIN user_group_authorities AS uga ON uga.user_authority_id = ua.id 
    LEFT JOIN users ON users.user_group_id = uga.user_group_id 
    WHERE users.id = ?;
  `,
    {
      replacements: [id],
      type: QueryTypes.SELECT,
    }
  );

  return auths.map((a) => a.authority);
};

export const getUserRegion = async (id: number) => {
  let user = await User.findOne({
    where: {
      id,
    },
    attributes: ['region_code'],
  });
  return user?.region_code;
};
