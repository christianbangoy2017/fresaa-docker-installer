import {
  Facility,
  FacilityAssessment,
  FacilityGroupAssignment,
  FacilityType,
  LocationMunicipality,
  LocationProvince,
  User,
} from 'models';
import { getLimitAndOffset, groupArrayIntoSubarrays } from 'utils';

import { ApiQuery } from 'interfaces';
import { FacilityOuput } from 'models/Facility';
import { Op } from 'sequelize';
import { STATUS } from './assessment.service';
import { UserOutput } from 'models/User';
import { createActivityLog } from './activity-log.service';
import csv from 'csv-parser';
import { get as fgGet } from './facility-group.service';
import { getUserByToken } from './user.service';
import xlsx from 'xlsx';

// import parse from 'csv-parse';

export const get = async (id: number) => {
  return Facility.findByPk(id) as unknown as FacilityOuput;
};

export const getList = async (query: ApiQuery, token: string, batch_id?: number) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search || '';

  let facilityWhereClause: any = {};

  if (query.facility_type) {
    facilityWhereClause = {
      ...facilityWhereClause,
      facility_type_id: query.facility_type,
    };
  }

  if (query.region_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      region_code: query.region_code,
    };
  }

  if (query.province_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: query.province_code,
    };
  }

  if (query.municipality_code) {
    facilityWhereClause = {
      ...facilityWhereClause,
      municipality_code: query.municipality_code,
    };
  }

  if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: current_user.province_code,
    };
  }

  facilityWhereClause = {
    ...facilityWhereClause,
    region_code: current_user.region_code,
    [Op.or]: {
      facility_name: { [Op.like]: `%${search}%` },
      facility_code: { [Op.like]: `%${search}%` },
    },
  };

  if (batch_id) {
    const included = (await FacilityAssessment.findAll({ where: { batch_id } })).map(
      (assessment) => assessment.facility_id
    );

    facilityWhereClause = {
      ...facilityWhereClause,
      id: { [Op.notIn]: included },
    };
  }

  Facility.hasMany(User, {
    foreignKey: 'facility_id',
  });

  let result = await Facility.findAndCountAll({
    where: facilityWhereClause,

    include: [
      {
        model: FacilityType,
        as: 'facility_type',
        attributes: ['type'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
      {
        model: User,
        attributes: ['id', 'first_name', 'middle_name', 'last_name', 'title'],
      },
    ],
    order: [['province', 'province_code', 'asc'], ['municipality', 'municipality_name', 'asc'], 'facility_name'],
    limit,
    offset,
  });

  return result;
};

export const listAllFacilities = async (token: string) => {
  const current_user = await getUserByToken(token);

  let facilityWhereClause: any = {
    region_code: current_user.region_code,
  };

  if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      ...facilityWhereClause,
      province_code: current_user.province_code,
    };
  }

  let result = await Facility.findAndCountAll({
    where: facilityWhereClause,
  });

  return result;
};

export const getAvailableList = async (batch_id: number, token: string) => {
  const current_user = await getUserByToken(token);

  const included = (await FacilityAssessment.findAll({ where: { batch_id } })).map(
    (assessment) => assessment.facility_id
  );

  return Facility.findAll({
    attributes: ['id', 'facility_name', 'facility_code'],
    where: {
      region_code: current_user.region_code,
      id: { [Op.notIn]: included },
    },
    include: [
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
    ],
    order: [['province', 'province_code', 'asc'], ['municipality', 'municipality_name', 'asc'], 'facility_name'],
  });
};

export const create = async (request: any, token: string) => {
  const current_user = await getUserByToken(token);
  request.created_by = current_user.id;
  request.region_code = request.region_code ? request.region_code : current_user.region_code;
  request.province_code = request.province_code ? request.province_code : current_user.province_code;
  return Facility.create(request).then((f) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Create facility: [' + request.facility_name + ']',
      model: 'facility',
      model_id: f.id,
    };
    createActivityLog(payload);
    return get(f!.id);
  });
};

export const update = async (id: number, request: any, currentUserId?: number) => {
  return Facility.update(request, { where: { id } }).then(() => {
    if (currentUserId) {
      //to make sure to log update activity only from update() calls of actual updates and not from deletes
      const payload = {
        user_id: currentUserId,
        activity: 'Update facility: [' + request.facility_name + ']',
        model: 'facility',
        model_id: id,
      };

      createActivityLog(payload);
    }

    return get(id);
  });
};

export const deleteItem = async (id: number, current_user: UserOutput) => {
  const facility = await get(id);
  return Facility.destroy({
    where: { id, region_code: current_user.region_code },
  }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete facility: [' + facility.facility_name + ']',
      model: 'facility',
      model_id: id,
    };

    createActivityLog(payload);
    return u;
  });
};

export const getAvailableListNotSelected = async (query: ApiQuery, token: string, group_id: number) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  const search = query.search || '';

  const included = (await FacilityGroupAssignment.findAll()).map((facility) => facility.facility_id);

  const fg = await fgGet(group_id);
  let whereClause: any = {};

  if (query.municipality_code) {
    whereClause = {
      municipality_code: query.municipality_code,
    };
  }

  if (query.facility_type) {
    whereClause = {
      ...whereClause,
      facility_type_id: query.facility_type,
    };
  }

  return Facility.findAndCountAll({
    // attributes: ['id', 'facility_name', 'facility_code'],
    where: {
      region_code: current_user.region_code,
      province_code: fg.province_code,
      id: { [Op.notIn]: included },
      [Op.or]: {
        facility_code: {
          [Op.like]: `%${search}%`,
        },
        facility_name: {
          [Op.like]: `%${search}%`,
        },
      },
      ...whereClause,
    },
    include: [
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
      {
        model: FacilityType,
        as: 'facility_type',
        attributes: ['type'],
      },
    ],
    order: [['province', 'province_code', 'asc'], ['municipality', 'municipality_name', 'asc'], 'facility_name'],
    limit,
    offset,
  });
};

export const createFacilitiesCSV = async (fileBuffer: Buffer, currentUser: UserOutput) => {
  let records: any = [];

  let isCSV = false;

  // Determine if the file is XLSX or CSV
  if (fileBuffer.slice(0, 4).toString() === 'PK\x03\x04') {
    // The file is an XLSX file
    const workbook = xlsx.read(fileBuffer, { type: 'buffer' });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    records = xlsx.utils.sheet_to_json(worksheet, { header: 1, raw: false });
  } else {
    // The file is a CSV file
    const parser = csv({ headers: true });
    parser.write(fileBuffer);
    parser.on('data', (data: any) => records.push(data));
    parser.end();
    isCSV = true;
  }

  const facility_types: any[] = await FacilityType.findAll();
  const provinces: any[] = await LocationProvince.findAll({
    where: { region_code: currentUser.region_code },
    attributes: ['province_code'],
  });
  const municipalities: any[] = await LocationMunicipality.findAll({
    where: { region_code: currentUser.region_code },
    attributes: ['municipality_code'],
  });
  const facilities: any[] = await Facility.findAll({
    where: { region_code: currentUser.region_code },
    attributes: ['facility_code'],
  });
  const province_codes = provinces.map((prov) => prov.province_code);
  const municipality_codes = municipalities.map((mun) => mun.municipality_code);
  const facility_codes = facilities.map((mun) => mun.facility_code);

  const idToTypeMap = facility_types.reduce((acc: any, faci: any) => {
    acc[faci.type] = faci.id;
    return acc;
  }, {});

  records.shift();

  let rowNum = 0;

  // Create a new Facility record for each row of data in the file
  const newRecords = records.map(async (record: any, index: number) => {
    if (index === 0) {
      return; // Skip the first record
    }
    rowNum++;
    // Check if a record with the same facility_code already exists
    if (!isCSV) {
      // Map the file data to the Facility model fields
      const facilityData = {
        facility_code: record[0],
        facility_name: record[2],
        region_code: record[10],
        province_code: record[12],
        municipality_code: record[14],
        facility_type_id: idToTypeMap[record[4] === 'Birthing Home' ? 'Safe Birthing Facility' : record[4]],
        managing_authority: record[6],
        barangay_name: record[15],
        barangay_code: record[16],
        street_name: record[7],
        building_name: record[8],
        zip_code: record[17],
        created_by: currentUser.id,
      };
      return facilityData;
    } else {
      // Map the CSV data to the Facility model fields

      const facilityData = {
        facility_code: record._0,
        facility_name: record._2,
        region_code: record._10,
        province_code: record._12,
        municipality_code: record._14,
        facility_type_id: idToTypeMap[record._4 === 'Birthing Home' ? 'Safe Birthing Facility' : record._4],
        managing_authority: record._6,
        barangay_name: record._15,
        barangay_code: record._16,
        street_name: record._7,
        building_name: record._8,
        zip_code: record._17,
        created_by: currentUser.id,
      };

      return facilityData;
    }

    // Return a new record with the data from the file
  });

  let createdRecords = await Promise.all(newRecords);
  createdRecords = createdRecords.filter((record) => record !== undefined);

  let errors: any = [];
  let validRecords: any = [];

  let row = 2;

  for (const record of createdRecords) {
    row++;
    let error = [];

    if (record.province_code?.length < 10) {
      error.push('Province code length is invalid.');
    }

    if (record.region_code?.length < 10) {
      error.push('Region code length is invalid.');
    }

    if (record.municipality_code?.length < 10) {
      error.push('Municipality code length is invalid.');
    }

    if (record.barangay_code?.length < 10) {
      error.push('Barangay code length is invalid.');
    }

    if (!record.facility_type_id) {
      error.push('Facility type is invalid.');
    }

    //Required
    if (!record.facility_code) {
      error.push('Facility code required.');
    }

    if (!record.facility_name) {
      error.push('Facility name is required.');
    }

    if (!record.barangay_code) {
      error.push('Barangay code is required.');
    }

    if (!record.municipality_code) {
      error.push('Municipality code is required.');
    }

    if (!record.region_code) {
      error.push('Region code is required.');
    }

    if (!record.province_code) {
      error.push('Province code is required.');
    }

    if (!record.barangay_name) {
      error.push('Barangay name is required.');
    }

    // valid region province and municipality code
    const validRegion = currentUser.region_code === record.region_code;
    if (!validRegion) {
      error.push('Region code is invalid.');
    }

    const validProvince = province_codes.includes(record.province_code);
    if (!validProvince) {
      error.push('Province code is invalid.');
    }

    const validMunicipality = municipality_codes.includes(record.municipality_code);
    if (!validMunicipality) {
      error.push('Municipality code is invalid.');
    }

    const existingFacilityCode = facility_codes.includes(record.facility_code);
    if (!existingFacilityCode && !error.length) {
      validRecords.push(record);
    }

    let errorString = error.join(' ');

    errorString = 'Row ' + row + ' - ' + errorString;

    if (error.length > 0) {
      errors.push(errorString);
    }
  }

  // Bulk create the new records
  if (errors.length > 0) {
    return { error: errors };
  } else {
    const data = await Promise.all(validRecords);
    const subarrays = groupArrayIntoSubarrays(data, 100);
    subarrays.map(async (subarray) => {
      await delay(500);
      await Facility.bulkCreate(subarray);
    });
    return data.length;
  }
};

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));
