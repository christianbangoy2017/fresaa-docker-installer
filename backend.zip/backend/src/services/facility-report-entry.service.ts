import * as commentService from 'services/facility-report-entry-comment.service';

import {
  AssessmentIndicators,
  Facility,
  FacilityReportEntry,
  FacilityReportEntryComment,
  FacilityType,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
  Report,
  ReportEntry,
  User,
} from 'models';
import { STATUS, getStepsFromAssessmentIndicator } from './assessment.service';
import { flattenResponses, getLimitAndOffset, makeCsvSafe, safeIntParse } from 'utils';

import { ApiQuery } from 'interfaces';
import { FacilityReportEntryInput } from 'models/FacilityReportEntry';
import { Op } from 'sequelize';
import { Response } from 'express';
import { UserShortAttributesArray } from 'models/User';
import { createActivityLog } from './activity-log.service';
import { get as getReports } from './report.service';
import { getUserByToken } from './user.service';
import { includeFacility } from 'models/Facility';

// gets facility report entry by id
export const get = async (id: number) => {
  return await FacilityReportEntry.findOne({
    where: { id },
    include: [
      {
        model: ReportEntry,
        as: 'report_entry',
        attributes: ['month', 'deadline', 'status'],
        include: [
          {
            model: Report,
            as: 'report',
            attributes: ['name'],
          },
        ],
      },
      includeFacility(),
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
      {
        model: User,
        as: 'approver',
        attributes: UserShortAttributesArray,
      },
    ],
  });
};

// gets facility report entries by report entry id
export const getReportEntryById = async (query: ApiQuery = {}, token: string, id: number, idSource: string) => {
  const [limit, offset] = getLimitAndOffset(query);
  const facilityQuery: any = {};
  const reportEntryQuery: any = idSource === 'report_entry' ? { report_entry_id: id } : { report_id: id };
  if (query.facility_id && Number.isInteger(safeIntParse(query.facility_id))) {
    reportEntryQuery['facility_id'] = safeIntParse(query.facility_id);
  }
  if (query.status) {
    reportEntryQuery['status'] = query.status;
  }

  if (query.province_code) {
    facilityQuery['province_code'] = query.province_code;
  }
  if (query.municipality_code) {
    facilityQuery['municipality_code'] = query.municipality_code;
  }

  if (query.facility_type && Number.isInteger(safeIntParse(query.facility_type))) {
    facilityQuery['facility_type_id'] = safeIntParse(query.facility_type);
  }

  let filter: any = {};
  const search = query.search?.trim() || '';

  if (query.facility_type) {
    filter = {
      ...filter,
      '$facility.facility_type_id$': query.facility_type,
    };
  }

  if (search) {
    filter = {
      ...filter,
      [Op.or]: {
        '$facility.facility_name$': {
          [Op.like]: `%${search}%`,
        },
        '$report_entry.report.name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.province.province_name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.municipality.municipality_name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.barangay_name$': {
          [Op.like]: `%${search}%`,
        },
      },
    };
  }

  const current_user = await getUserByToken(token);
  let whereClause: any = {};

  if (
    current_user.user_group.validator &&
    !['MHO/PHN', 'DMO', 'PHO', 'CHD'].includes(current_user.user_group.group_name)
  ) {
    whereClause = {
      current_step: current_user.user_group.group_name,
    };
  } else if (current_user.user_group.group_name === 'FHS') {
    whereClause = {
      facility_id: current_user.facility_id,
    };
  }

  return FacilityReportEntry.findAndCountAll({
    include: [
      includeFacility(facilityQuery),
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
      {
        model: User,
        as: 'approver',
        attributes: UserShortAttributesArray,
      },
      {
        model: ReportEntry,
        as: 'report_entry',
        attributes: ['month', 'deadline', 'status'],
        include: [
          {
            model: Report,
            as: 'report',
            attributes: ['name'],
          },
        ],
      },
    ],
    where: {
      ...reportEntryQuery,
      ...filter,
      ...whereClause,
    },
    order: [['facility', 'facility_name', 'asc']],
    attributes: {
      exclude: ['responses'],
    },
    limit,
    offset,
  });
};

export const getReportEntryByFacilityId = async (facilityId: number, query: ApiQuery, token: string, res: Response) => {
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';
  const current_user = await getUserByToken(token);

  if (current_user.user_group.group_name === 'FHS' && current_user.facility_id !== facilityId) {
    res.status(400).send({
      message: 'You are not authorized to perform this action.',
    });
    return;
  }

  let filter: any = {};
  if (query.status && query.status !== 'completed') {
    filter = {
      status: query.status,
    };
  }

  return FacilityReportEntry.findAndCountAll({
    include: [
      {
        model: Facility,
        as: 'facility',
        include: [
          {
            model: FacilityType,
            as: 'facility_type',
            attributes: ['type'],
          },
          {
            model: LocationRegion,
            as: 'region',
            attributes: ['region_name'],
          },
          {
            model: LocationProvince,
            as: 'province',
            attributes: ['province_name'],
          },
          {
            model: LocationMunicipality,
            as: 'municipality',
            attributes: ['municipality_name'],
          },
        ],
      },
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
      {
        model: User,
        as: 'approver',
        attributes: UserShortAttributesArray,
      },
      {
        model: ReportEntry,
        as: 'report_entry',
        attributes: ['month', 'deadline', 'status'],
        where: { status: 'active' },
        include: [
          {
            model: Report,
            as: 'report',
            attributes: ['name'],
          },
        ],
      },
    ],
    where: {
      facility_id: facilityId,
      status: { [Op.not]: 'completed' },
      ...filter,
      [Op.or]: {
        '$report_entry.report.name$': {
          [Op.like]: `%${search}%`,
        },
      },
    },
    order: [['facility', 'facility_name', 'asc']],
    attributes: {
      exclude: ['responses'],
    },
    limit,
    offset,
  });
};

export const getFacilitiesNotInReportEntry = async (reportEntryId: number) => {
  return await FacilityReportEntry.findAll({
    where: { report_entry_id: { [Op.not]: reportEntryId } },
  });
};

// gets all the available facilities and return its ids
export const getAvailableFacilityIDs = async (report_entry_id: number, token: string, query: ApiQuery = {}) => {
  const facilityQuery: any = {};
  const current_user = await getUserByToken(token);

  // append the query for the other search conditions
  if (query.municipality_code) {
    facilityQuery['municipality_code'] = query.municipality_code;
  }

  if (query.province_code) {
    facilityQuery['province_code'] = query.province_code;
  }

  if (query.facility_id && Number.isInteger(safeIntParse(query.facility_id))) {
    facilityQuery['facility_id'] = safeIntParse(query.facility_id);
  }

  if (query.facility_type && Number.isInteger(safeIntParse(query.facility_type))) {
    facilityQuery['facility_type_id'] = safeIntParse(query.facility_type);
  }

  facilityQuery['region_code'] = current_user.region_code;

  const facilityIDs = await Facility.findAll({
    where: facilityQuery,
    attributes: ['id'],
    raw: true,
  });

  const facilityReportEntryIds = await FacilityReportEntry.findAll({
    attributes: ['facility_id'],
    where: { report_entry_id: report_entry_id },
    raw: true,
  });

  const mappedFacilityIDs = facilityIDs.map((f) => f.id);
  const mappedFacilityReportEntryIds = facilityReportEntryIds.map((f) => f.facility_id);

  if (facilityReportEntryIds.length === 0) return mappedFacilityIDs;

  // find all offices that are not yet assigned to FacilityReportEntry
  const unassignedFacilities = mappedFacilityIDs.filter((id) => {
    return !mappedFacilityReportEntryIds.includes(id);
  });

  return unassignedFacilities;
};

// gets all the available facilities (does not have FacilityReportEntry for the specific month)
export const getAvailableFacilities = async (report_entry_id: number, query: ApiQuery = {}, token: string) => {
  const unassignedFacilities = await getAvailableFacilityIDs(report_entry_id, token, query);
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() || '';

  let whereClause: any = { id: unassignedFacilities };
  if (search) {
    whereClause = {
      id: unassignedFacilities,
      [Op.or]: {
        facility_name: {
          [Op.like]: `%${search}%`,
        },
        '$province.province_name$': {
          [Op.like]: `%${search}%`,
        },
        '$municipality.municipality_name$': {
          [Op.like]: `%${search}%`,
        },
        $barangay_name$: {
          [Op.like]: `%${search}%`,
        },
      },
    };
  }

  return Facility.findAndCountAll({
    include: [
      {
        model: FacilityType,
        as: 'facility_type',
        attributes: ['type'],
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
    ],
    where: whereClause,
    limit,
    offset,
  });
};

// bulk creation of facility report entries
export const createBulkEntry = async (reportEntryId: number, facilityId: number[]) => {
  const reportEntry = await ReportEntry.findOne({
    where: { id: reportEntryId },
  });

  if (!reportEntry) throw 'Report Entry Does not exist';

  const report = await Report.findOne({
    where: { id: reportEntry.report_id },
  });

  if (!report) throw 'Report does not exist';

  const assessment = await AssessmentIndicators.findOne({
    where: { id: report.indicator_id },
  });

  if (!assessment) throw 'Assessment indicator does not exist';

  const facilityReportEntryPayload: FacilityReportEntryInput[] = facilityId.map((id) => {
    return {
      report_id: reportEntry.report_id,
      report_entry_id: reportEntryId,
      facility_id: id,
      responses: assessment.indicators,
      status: 'open',
    };
  });

  return (await FacilityReportEntry.bulkCreate(facilityReportEntryPayload)).map((c) => c.id);
};

// bulk create for all facilities not included
export const createEntryForAllNotIncluded = async (reportEntryId: number, token: string) => {
  const availableFacilityIds = await getAvailableFacilityIDs(reportEntryId, token);
  return createBulkEntry(reportEntryId, availableFacilityIds);
};

// marks the facility report entry as submitted
export const markAsSubmitted = async (id: number, assessor_id: number, responses: string) => {
  const facilityReportEntry = await get(id);
  let current_step = facilityReportEntry?.current_step;
  if (facilityReportEntry) {
    const reports = await getReports(facilityReportEntry.report_id);
    if (reports) {
      const steps = await getStepsFromAssessmentIndicator(reports.indicator_id);
      current_step = steps ? steps[1] : undefined;
    }
  }

  return await FacilityReportEntry.update(
    {
      submitted_at: new Date(),
      status: 'submitted',
      assessor_id,
      responses,
      current_step,
    },
    { where: { id } }
  );
};

// marks the facility report entry as approved
export const approve = async (id: number, token: string, res: Response) => {
  const facilityReportEntry = await get(id);
  let current_step = facilityReportEntry?.current_step;
  const current_user = await getUserByToken(token);
  const approver_id = current_user.id;
  if (current_step !== current_user.user_group.group_name) {
    res.status(400).send({
      message: 'You are not authorized to perform this action.',
    });
    return;
  }
  let approved_at;
  let status = facilityReportEntry?.status;

  if (facilityReportEntry && current_step) {
    const reports = await getReports(facilityReportEntry.report_id);
    const steps = await getStepsFromAssessmentIndicator(reports.indicator_id);
    const currentStepIndex = steps?.indexOf(current_step);
    if (steps && currentStepIndex !== undefined) {
      if (currentStepIndex < 0) current_step = steps[1];
      else current_step = steps[currentStepIndex + 1];
    }
    status = current_step === 'Complete' ? STATUS.COMPLETED : 'ongoing-approval';
    if (status === STATUS.COMPLETED) {
      approved_at = new Date();
    }
  }

  return await FacilityReportEntry.update(
    {
      current_step,
      approved_at,
      status,
      approver_id,
    },
    { where: { id } }
  );
};

// delete all the facility report entries based on ID
export const deleteFacilityReportEntries = async (facilityReportEntryIds: number[]) => {
  /** Check if there are comments associated facility report entries */
  const comments = await commentService.getCommentsByFacilityReportEntryId(facilityReportEntryIds);
  if (comments.rows.length > 0) {
    /** Delete comments associated facility report entries */
    await commentService.deleteCommentsOnFacilityReportEntry(facilityReportEntryIds);
  }

  return await FacilityReportEntry.destroy({
    where: {
      id: facilityReportEntryIds,
    },
    force: true,
  });
};

// deletes all the facility report entries based on report entry ID
export const deleteAllFacilityReportEntries = async (reportEntryId: number | number[]) => {
  /** Get all associated facility report entries for report entry */
  const facilityReportEntries = await FacilityReportEntry.findAndCountAll({
    where: { report_entry_id: reportEntryId },
  });
  console.log(facilityReportEntries);
  const facilityReportEntryIds = facilityReportEntries.rows.map((item) => item.id);
  if (facilityReportEntryIds.length > 0) {
    /** Check if there are comments associated facility report entries */
    const comments = await commentService.getCommentsByFacilityReportEntryId(facilityReportEntryIds);
    if (comments.rows.length > 0) {
      /** Delete comments associated facility report entries */
      await commentService.deleteCommentsOnFacilityReportEntry(facilityReportEntryIds);
    }
    return await FacilityReportEntry.destroy({
      where: { report_entry_id: reportEntryId },
      force: true,
    });
  }

  return null;
};

// updates the facility report entry responses
export const updateFaciltyReportEntryResponse = async (id: number, responses: string) => {
  return await FacilityReportEntry.update({ responses, status: STATUS.STARTED }, { where: { id } });
};

// get all approved report facility entries
export const getApprovedReportFacilityEntries = async (query: ApiQuery) => {
  const [limit, offset] = getLimitAndOffset(query);

  let filter: any = {};
  const search = query.search?.trim() || '';

  if (query.status) {
    filter = {
      ...filter,
      status: query.status,
    };
  }

  if (query.facility_type) {
    filter = {
      ...filter,
      '$facility.facility_type_id$': query.facility_type,
    };
  }

  if (query.province_code) {
    filter = {
      ...filter,
      '$facility.province_code$': query.province_code,
    };
  }

  if (query.municipality_code) {
    filter = {
      ...filter,
      '$facility.municipality_code$': query.municipality_code,
    };
  }

  return FacilityReportEntry.findAndCountAll({
    include: [
      {
        model: ReportEntry,
        as: 'report_entry',
        attributes: ['month', 'deadline', 'status'],
        include: [
          {
            model: Report,
            as: 'report',
            attributes: ['name'],
          },
        ],
      },
      includeFacility(),
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
    ],
    where: {
      ...filter,
      [Op.or]: {
        '$facility.facility_name$': {
          [Op.like]: `%${search}%`,
        },
        '$report_entry.report.name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.province.province_name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.municipality.municipality_name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.barangay_name$': {
          [Op.like]: `%${search}%`,
        },
      },
      status: 'completed',
    },
    limit,
    offset,
  });
};

// get all report facility entries from active report enrties
export const getActiveReportEntryFacilityEntries = async (query: ApiQuery, token: string) => {
  const [limit, offset] = getLimitAndOffset(query);
  const current_user = await getUserByToken(token);

  let filter: any = {};
  const search = query.search?.trim() || '';

  if (query.status) {
    filter = {
      ...filter,
      status: query.status,
    };
  }

  if (query.facility_type) {
    filter = {
      ...filter,
      '$facility.facility_type_id$': query.facility_type,
    };
  }

  if (query.province_code) {
    filter = {
      ...filter,
      '$facility.province_code$': query.province_code,
    };
  }

  if (query.municipality_code) {
    filter = {
      ...filter,
      '$facility.municipality_code$': query.municipality_code,
    };
  }

  if (query.for_approval) {
    filter = { ...filter, current_step: current_user.user_group.group_name };
  }

  filter = {
    ...filter,
    '$facility.region_code$': current_user.region_code,
  };

  return FacilityReportEntry.findAndCountAll({
    include: [
      {
        model: ReportEntry,
        as: 'report_entry',
        attributes: ['month', 'deadline', 'status'],
        include: [
          {
            model: Report,
            as: 'report',
            attributes: ['name'],
          },
        ],
        where: {
          status: 'active',
        },
      },
      includeFacility(),
      {
        model: User,
        as: 'assessor',
        attributes: UserShortAttributesArray,
      },
    ],
    where: {
      ...filter,
      [Op.or]: {
        '$facility.facility_name$': {
          [Op.like]: `%${search}%`,
        },
        '$report_entry.report.name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.province.province_name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.municipality.municipality_name$': {
          [Op.like]: `%${search}%`,
        },
        '$facility.barangay_name$': {
          [Op.like]: `%${search}%`,
        },
      },
    },
    limit,
    offset,
  });
};

export const getAssessmentResponses = (sections: any[]) => {
  return sections.flatMap((section) => {
    return section.section_body.flatMap((body: any) => {
      return flattenResponses(body);
    });
  });
};

export const getReportEntryIndicators = async (
  token: string,
  report_entry_id?: number,
  facility_report_entry_id?: number,
  for_dashboard?: boolean
) => {
  let whereClause: any = {};

  if (facility_report_entry_id) {
    whereClause = { id: facility_report_entry_id };
  } else {
    whereClause = { report_entry_id, status: STATUS.COMPLETED };
  }
  const current_user = await getUserByToken(token);

  let facilityWhereClause: any = {};
  if (current_user.user_group.level === 'Provincial') {
    facilityWhereClause = {
      province_code: current_user.province_code,
    };
  }
  const facilityAssessmentRow = await FacilityReportEntry.findAndCountAll({
    where: whereClause,
    include: [includeFacility(facilityWhereClause)],
    raw: true,
  });

  if (facilityAssessmentRow.count == 0) return for_dashboard ? [] : facilityAssessmentRow;
  const rows = facilityAssessmentRow.rows;
  const flatResponse = getAssessmentResponses(JSON.parse(rows[0].responses));

  if (for_dashboard) {
    return rows.map((assessment: any) => {
      const flatResponse = getAssessmentResponses(JSON.parse(assessment.responses));
      const row: any = {
        'Facility ID': assessment['facility.id'],
        'Facility Code': assessment['facility.facility_code'],
        'Facility Name': assessment['facility.facility_name'],
        'Facility Type': assessment['facility.facility_type.type'],
        'With SBF': assessment['facility.with_sbf'] === 1 ? 1 : 0,
        Region: assessment['facility.region.region_name'],
        'Region Code': assessment['facility.region.region_code'],
        Province: assessment['facility.province.province_name'],
        'Province Code': assessment['facility.province.province_code'],
        Municipality: assessment['facility.municipality.municipality_name'],
        'Municipality Code': assessment['facility.municipality.municipality_code'],
      };
      flatResponse.forEach((response) => {
        row[response.field_code] = response.response;
      });
      return row;
    });
  }

  const csvHeaders = flatResponse.map((response) => {
    return makeCsvSafe(`${response.field_code} - ${response.field_name}`);
  });

  const csvFormatted =
    'Facility Code,Facility Name,Facility Type,Region,Province,Municipality,' +
    csvHeaders.join(',') +
    '\n' +
    rows
      .map((facilityReportEntry: any) => {
        const flatResponse = getAssessmentResponses(JSON.parse(facilityReportEntry.responses));
        const responses = flatResponse.map((response) =>
          response.response + '' ? makeCsvSafe(response.response + '') : ''
        );
        return (
          `${makeCsvSafe(facilityReportEntry['facility.facility_code'])},${makeCsvSafe(
            facilityReportEntry['facility.facility_name']
          )},${makeCsvSafe(facilityReportEntry['facility.facility_type.type'])},${makeCsvSafe(
            facilityReportEntry['facility.region.region_name']
          )},${makeCsvSafe(facilityReportEntry['facility.province.province_name'])},${makeCsvSafe(
            facilityReportEntry['facility.municipality.municipality_name']
          )},` + responses.join(',')
        );
      })
      .join('\n');

  return {
    rows: rows,
    count: rows.length,
    csvFormatted,
  };
};

export const returnReport = async (token: string, id: number, request: any) => {
  const current_user = await getUserByToken(token);
  const data: any = { status: STATUS.STARTED, current_step: '' };

  return FacilityReportEntry.update(data, { where: { id } }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Return facility report',
      model: 'facility-report-entries',
    };

    createActivityLog(payload);
    return u;
  });
};
