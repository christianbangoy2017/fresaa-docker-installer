import { Op } from 'sequelize';
import { UserGroup } from 'models';
import { UserGroupOuput } from 'models/UserGroup';
import { getUserByToken } from './user.service';

export const getUserGroupId = async (group_name: string) => {
  return UserGroup.findOne({
    where: { group_name },
  }) as unknown as UserGroupOuput;
};

export const getAll = async (token: string, validator: boolean) => {
  const filter = validator ? { validator: true } : {};
  const current_user = await getUserByToken(token);
  return UserGroup.findAndCountAll({
    where: { group_name: { [Op.not]: 'SA' }, region_code: { [Op.or]: [null, current_user.region_code] }, ...filter },
  });
};
