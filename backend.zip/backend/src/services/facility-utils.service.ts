import {
  Facility,
  FacilityAssessment,
  FacilityGroup,
  FacilityGroupAssignment,
  FacilityType,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
  User,
  UserGroup,
} from 'models';

import { Op } from 'sequelize';
import { STATUS } from './assessment.service';
import { createActivityLog } from './activity-log.service';
import { getUserByToken } from './user.service';

export const getAvailableRegion = async (token: string) => {
  try {
    const regions = await LocationRegion.findAll({
      order: ['region_code'],
    });
    return regions;
  } catch (error) {
    return [];
  }
};

export const getAvailableProvince = async (region_code: string) => {
  try {
    let where = {};
    if (region_code) {
      where = { region_code };
    }
    const province = await LocationProvince.findAll({
      where: where,
      order: ['province_code'],
    });
    return province;
  } catch (error) {
    return [];
  }
};

export const getAvailableMunicipality = async (province_code: string, region_code: string) => {
  try {
    if (province_code) {
      return await LocationMunicipality.findAll({
        where: { province_code },
        order: ['municipality_code'],
      });
    } else if (region_code) {
      return await LocationMunicipality.findAll({
        where: { region_code },
        order: ['municipality_code'],
      });
    }

    return [];
  } catch (error) {
    return [];
  }
};

export const getFieldAssessors = async (token: string, province_code: string) => {
  const user = await getUserByToken(token);

  return User.findAll({
    where: { province_code },
    include: [
      {
        model: UserGroup,
        as: 'user_group',
        where: {
          group_name: 'FA',
        },
      },
    ],
    order: ['first_name'],
    attributes: ['id', 'first_name', 'middle_name', 'last_name', 'title', "username"],
  });
};

export const assignFacilityToGroup = async (request: any, group_id: number, token: string) => {
  const current_user = await getUserByToken(token);
  const facilities_arr = JSON.parse(request.facilities);
  const assessor_id = JSON.parse(request.assessorId);

  const group = await FacilityGroup.findOne({
    where: {
      id: group_id,
    },
  });
  const included = (
    await FacilityGroupAssignment.findAll({
      attributes: ['facility_id'],
    })
  ).map((facility_group) => facility_group.facility_id);

  const facilities = await Facility.findAll({
    where: {
      region_code: current_user.region_code,
      [Op.and]: [{ id: { [Op.notIn]: included } }, { id: { [Op.in]: facilities_arr } }],
    },
  });

  await FacilityAssessment.update(
    { assessor_id: assessor_id, status: STATUS.ASSIGNED },
    {
      where: {
        facility_id: facilities_arr,
        status: [STATUS.OPEN, STATUS.ASSIGNED],
      },
    }
  );

  const data = facilities.map((facility) => {
    return {
      facility_id: facility.id,
      group_id,
    };
  }) as FacilityGroupAssignment[];
  return FacilityGroupAssignment.bulkCreate(data).then((u) => {
    const modelId = facilities.length == 1 ? u[0].group_id : null;
    const payload = {
      user_id: current_user.id,
      activity: 'Add facility to group - [' + group?.group_name + ']: ' + facilities_arr.join(', '),
      model: 'facility-group',
      model_id: modelId,
    };

    createActivityLog(payload);

    return u;
  });
};

export const deleteFacilityToGroup = async (request: any, token: string) => {
  const facilities_arr = JSON.parse(request.facilities);
  const current_user = await getUserByToken(token);

  const included = (
    await FacilityGroupAssignment.findAll({
      attributes: ['facility_id'],
      where: { id: facilities_arr },
    })
  ).map((facility_group) => facility_group.facility_id);

  return await FacilityGroupAssignment.destroy({
    where: {
      id: facilities_arr,
    },
  }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Remove facility from group: ' + included.join(', '),
      model: 'facility-group-assignment',
    };

    createActivityLog(payload);
    return u;
  });
};

export const getFacilityTypes = async () => {
  return FacilityType.findAll();
};
