import ActivityLog from 'models/ActivityLog';
import { ApiQuery } from 'interfaces';
import { FacilityOuput } from 'models/Facility';
import { User } from 'models';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return ActivityLog.findByPk(id) as unknown as FacilityOuput;
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  let whereClause: any = {
    region_code: current_user.region_code,
    // id: current_user.id,
  };

  if (current_user.user_group.level === 'Provincial') {
    whereClause = {
      ...whereClause,
      province_code: current_user.province_code,
    };
  }

  return await ActivityLog.findAndCountAll({
    include: [
      {
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'first_name', 'last_name', 'middle_name'],
        where: whereClause,
      },
    ],
    order: [['created_at', 'desc']],
    limit,
    offset,
  });
};

// change the type
export const createActivityLog = async (payload: any) => {
  payload.activity = payload.activity.substring(0, 1000);
  return ActivityLog.create(payload).then((f) => get(f!.id));
};
