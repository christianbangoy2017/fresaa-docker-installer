import * as reportEntryService from 'services/report-entry.service';

import { AssessmentIndicators, FacilityReportEntry, Report, ReportEntry } from 'models';
import { ReportInput, ReportOuput } from 'models/Report';

import { ApiQuery } from 'interfaces';
import { Op } from 'sequelize';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return Report.findByPk(id) as unknown as ReportOuput;
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search?.trim() ?? '';

  return Report.findAndCountAll({
    include: {
      model: AssessmentIndicators,
      required: true,
      as: 'indicator',
      attributes: ['name'],
    },
    where: {
      region_code: current_user.region_code,
      [Op.or]: {
        name: { [Op.like]: `%${search}%` },
      },
    },
    order: ['created_at'],
    limit,
    offset,
  });
};

export const getReportsByFacility = async (facilityId: number, query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  Report.hasMany(FacilityReportEntry, {
    foreignKey: 'report_id',
  });
  return Report.findAndCountAll({
    include: {
      model: FacilityReportEntry,
      attributes: ['status'],
      where: { facility_id: facilityId },
    },
    where: { region_code: current_user.region_code },
    order: ['created_at'],
    limit,
    offset,
  });
};

export const create = async (request: ReportInput, token: string) => {
  const current_user = await getUserByToken(token);
  request.region_code = request.region_code ? request.region_code : current_user.region_code;
  return Report.create(request).then((f) => get(f!.id));
};

// change the type
export const update = async (id: number, request: any) => {
  return Report.update(request, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number) => {
  /** Delete all report entries associated to report and so on*/
  const reportEntries = await reportEntryService.getReportEntriesByReportId(id, {});
  const reportEntriesIds = reportEntries.rows.map((item) => item.id);
  console.log(reportEntries);
  if (reportEntriesIds.length > 0) {
    await reportEntryService.deleteItem(reportEntriesIds);
  }

  return Report.destroy({ where: { id }, force: true });
};
