import { getFresaaFile, getLimitAndOffset } from 'utils';

import { ApiQuery } from 'interfaces';
import AssessmentIndicators from 'models/AssessmentIndicator';
import { FormValidationWorkflow } from 'models';
import { Op } from 'sequelize';
import { createActivityLog } from './activity-log.service';
import { getUserByToken } from './user.service';
import { UserOutput } from 'models/User';

export const get = async (id: number, raw?: boolean) => {
  return AssessmentIndicators.findByPk(id, { raw });
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search || '';

  return AssessmentIndicators.findAndCountAll({
    where: {
      region_code: current_user.region_code,
      name: {
        [Op.like]: `%${search}%`,
      },
    },
    include: [
      {
        model: FormValidationWorkflow,
        as: 'form_validation_workflow',
        attributes: ['name', 'steps'],
      },
    ],
    limit,
    offset,
  });
};

export const create = async (request: any) => {
  return AssessmentIndicators.create(request).then((f) => {
    const payload = {
      user_id: request.updated_by,
      activity: 'Create assessment indicator',
      model: 'assessment-indicator',
      model_id: f.id,
    };
    createActivityLog(payload);
    return get(f!.id);
  });
};

export const update = async (id: number, request: any) => {
  request.indicators = JSON.stringify(getFresaaFile(JSON.parse(request.indicators)));
  return AssessmentIndicators.update(request, { where: { id } }).then(() => {
    const payload = {
      user_id: request.updated_by,
      activity: 'Update assessment indicator',
      model: 'assessment-indicator',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const edit = async (id: number, request: any) => {
  return AssessmentIndicators.update(request, { where: { id } }).then(() => {
    const payload = {
      user_id: request.updated_by,
      activity: 'Updated assessment indicator name and validation workflow',
      model: 'assessment-indicator',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const deleteItem = async (id: number, current_user: UserOutput) => {
  const assessmentIndicator = await get(id);
  return AssessmentIndicators.destroy({
    where: { id, region_code: current_user.region_code },
  }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete assessment indicator: [' + assessmentIndicator?.name + ']',
      model: 'assessment-indicator',
      model_id: id,
    };

    createActivityLog(payload);
    return u;
  });
};
