import { ApiQuery } from 'interfaces';
import { Op } from 'sequelize';
import { UserGroup } from 'models';
import { createActivityLog } from './activity-log.service';
import { createUserGroupAuthority } from './user-group-authority.service';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return UserGroup.findByPk(id);
};

export const getAll = async (query: ApiQuery, token: string) => {
  const [limit, offset] = getLimitAndOffset(query);
  const current_user = await getUserByToken(token);
  const search = query.search?.trim() ?? '';

  return UserGroup.findAndCountAll({
    where: {
      validator: true,
      region_code: { [Op.or]: [null, current_user.region_code] },
      [Op.or]: [
        {
          group_name: { [Op.like]: `%${search}%` },
        },
        {
          description: { [Op.like]: `%${search}%` },
        },
      ],
    },
    limit,
    offset,
  });
};

export const create = async (request: any, token: string) => {
  const current_user = await getUserByToken(token);
  return UserGroup.create(request).then((f) => {
    const userGroupAuthPayload = {
      user_group_id: f.id,
      user_authority_id: 10, // REVIEW_FRESAA_QUESTIONNAIRE
    };
    createUserGroupAuthority(userGroupAuthPayload);
    const payload = {
      user_id: current_user.id,
      activity: 'Create user group validator',
      model: 'user-group',
      model_id: f.id,
    };
    createActivityLog(payload);
    return get(f!.id);
  });
};

export const update = async (id: number, request: any) => {
  return UserGroup.update(request, { where: { id } }).then(() => {
    const payload = {
      user_id: request.updated_by,
      activity: 'Update user group validator: [' + request.group_name + ']',
      model: 'user-group',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const deleteItem = async (id: number, token: string) => {
  const group = await get(id);
  const current_user = await getUserByToken(token);
  return UserGroup.destroy({ where: { id } }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete user group validator: [' + group?.group_name + ']',
      model: 'user-group',
      model_id: id,
    };

    createActivityLog(payload);
    return u;
  });
};
