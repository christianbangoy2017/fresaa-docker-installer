import { Widget, WidgetGroup } from 'models';

export const get = async (id: number) => {
  return WidgetGroup.findByPk(id);
};

export const getList = async (indicator_id: number) => {
  return WidgetGroup.findAll({
    where: { indicator_id },
    include: [
      {
        model: Widget,
        as: 'widgets',
      },
    ],
    order: ['order'],
  });
};

export const create = async (request: WidgetGroup, token: string) => {
  request.layout = JSON.stringify(
    Array(Math.abs(request.column_type.split('-').length))
      .fill(1)
      .map(() => {
        return [];
      })
  );
  const count = await WidgetGroup.count({ where: { indicator_id: request.indicator_id } });
  request.order = count;
  return WidgetGroup.create(request).then((f) => get(f!.id));
};

export const reorder = async (indicator_id: number, order: { from: number[]; to: number[] }) => {
  order.to.map(async (group_id, index) => {
    if (index !== order.from.indexOf(group_id)) {
      await WidgetGroup.update({ order: index }, { where: { id: group_id, indicator_id } });
    }
  });
};

export const reorderWidgets = async (group_id: number, layout: string) => {
  await WidgetGroup.update({ layout }, { where: { id: group_id } });
};

export const deleteItem = async (id: number) => {
  await Widget.destroy({ where: { group_id: id } });
  return WidgetGroup.destroy({ where: { id } });
};
