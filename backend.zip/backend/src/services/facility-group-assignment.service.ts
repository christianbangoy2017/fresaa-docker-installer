import { FacilityGroupAssignment } from 'models';

export const deleteItemByFacilityId = async (id: number) => {
  return FacilityGroupAssignment.destroy({ where: { facility_id: id } });
};
