import {
  AssessmentBatch,
  AssessmentBatchFacility,
  AssessmentBatchForm,
  AssessmentComment,
  AssessmentResponse,
  FacilityAssessment,
  FacilityGroupIndicatorAssessor,
} from 'models';
import { Op, QueryTypes } from 'sequelize';
import { getFresaaFile, getLimitAndOffset, groupArrayIntoSubarrays } from 'utils';

import { ApiQuery } from 'interfaces';
import { AssessmentBatchInput } from 'models/AssessmentBatch';
import AssessmentIndicators from 'models/AssessmentIndicator';
import { Response } from 'express';
import { STATUS } from './assessment.service';
import { UserOutput } from 'models/User';
import { createActivityLog } from './activity-log.service';
import { deleteManyByBatchId } from './assessment-batch-facility.service';
import { getFormsByBatchId } from './assessment-batch-form.service';
import { getUserByToken } from './user.service';
import sequelizeConnection from 'db/config';

export const get = async (id: number) => {
  return AssessmentBatch.findByPk(id);
};

export const getList = async (query: ApiQuery, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);
  const search = query.search || '';

  let whereClause: any = {
    region_code: current_user.region_code,
  };

  if (search) {
    whereClause = {
      ...whereClause,
      batch_name: {
        [Op.like]: `%${search}%`,
      },
    };
  }

  if (query.status) {
    whereClause = {
      ...whereClause,
      status: query.status,
    };
  }

  return AssessmentBatch.findAndCountAll({
    include: {
      model: AssessmentIndicators,
      required: true,
      as: 'indicator',
      attributes: ['name'],
    },
    where: whereClause,
    order: ['batch_name'],
    limit,
    offset,
  });
};

// change the type
export const create = async (request: AssessmentBatchInput, token: string, res: Response) => {
  const current_user = await getUserByToken(token);
  request.region_code = current_user.region_code;

  return AssessmentBatch.create(request).then(async (f) => {
    await AssessmentBatchForm.create({
      batch_id: f.id,
      indicator_id: f.indicator_id,
    });

    const payload = {
      user_id: current_user.id,
      activity: 'Create assessment batch: [' + request.batch_name + ']',
      model: 'assessment-batch',
      model_id: f.id,
    };
    createActivityLog(payload);

    return get(f!.id);
  });
};

// change the type
export const update = async (id: number, request: any) => {
  return AssessmentBatch.update(request, { where: { id } }).then(() => {
    const payload = {
      user_id: request.updated_by,
      activity: 'Update assessment batch: [' + request.batch_name + ']',
      model: 'assessment-batch',
      model_id: id,
    };

    createActivityLog(payload);

    return get(id);
  });
};

export const updateStatus = async (id: number, status: string, res: Response, token: string) => {
  const current_user = await getUserByToken(token);
  const batch = await get(id);

  if (status === 'open') {
    forceDeleteByBatchId(id);
  }

  return AssessmentBatch.update({ status, updated_by: current_user.id }, { where: { id } }).then(async () => {
    const activityType =
      status === 'active' ? 'Activate' : status === 'open' ? 'Open' : status === 'closed' ? 'Close' : 'Update';
    const payload = {
      user_id: current_user.id,
      activity: activityType + ' assessment batch: [' + batch?.batch_name + ']',
      model: 'assessment-batch',
      model_id: id,
    };

    createActivityLog(payload);
    if (status === 'active') {
      await createFacilityAssessment(id, current_user);
    }
    return get(id);
  });
};

const forceDeleteByBatchId = async (id: number) => {
  let assessments: any[] = await FacilityAssessment.findAll({
    attributes: ['id'],
    where: { batch_id: id, status: ['open', 'assigned'] },
    paranoid: false,
  });
  assessments = assessments.map((data) => data.id);
  await AssessmentResponse.destroy({
    where: { assessment_id: assessments },
    force: true,
  });

  await AssessmentComment.destroy({
    where: { assessment_id: assessments },
    force: true,
  });

  return await FacilityAssessment.destroy({
    where: { batch_id: id, status: ['open', 'assigned'] },
    force: true,
  });
};

export const updateDeletedBy = async (id: number, user_id: number) => {
  return await AssessmentBatch.update({ deleted_by: user_id }, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number, res: Response, current_user: UserOutput) => {
  const batch = await AssessmentBatch.findByPk(id);
  let message;
  if (batch?.region_code !== current_user.region_code) {
    message = 'You have no access to this assessment batch.';
  }
  if (batch?.status === 'active') {
    message = 'Cannot delete active batch.';
  }
  if (message) {
    res.status(400).json({ message });
    return;
  }

  return AssessmentBatch.destroy({ where: { id } }).then(async (u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete assessment batch: [' + batch?.batch_name + ']',
      model: 'assessment-batch',
      model_id: id,
    };

    createActivityLog(payload);

    await AssessmentBatchForm.destroy({ where: { batch_id: id } });
    await AssessmentBatchFacility.destroy({ where: { batch_id: id } });

    return u;
  });
};

const createFacilityAssessment = async (batch_id: number, current_user: UserOutput) => {
  const indicator_ids: any = await getFormsByBatchId(batch_id);
  const indicators = await AssessmentIndicators.findAll({
    where: { id: indicator_ids },
    attributes: ['indicators', 'id'],
  });

  let facility_ids = (await AssessmentBatchFacility.findAll({ where: { batch_id } })).map(
    (facility) => facility.facility_id
  );
  const included = (
    await FacilityAssessment.findAll({
      where: { batch_id, indicator_id: indicator_ids },
    })
  ).map((assessment) => assessment.facility_id);

  let difference = facility_ids.filter((x) => !included.includes(x));
  if (!difference.length) {
    return;
  }

  const facilities = await sequelizeConnection.query(
    `
      SELECT fga.group_id, f.*, ft.type, lm.municipality_name, lp.province_name, lr.region_name
      FROM facilities AS f
      LEFT JOIN facility_group_assignment AS fga ON fga.facility_id = f.id
      LEFT JOIN facility_types AS ft ON ft.id = f.facility_type_id
      LEFT JOIN location_municipalities AS lm ON lm.municipality_code = f.municipality_code
      LEFT JOIN location_provinces AS lp ON lp.province_code = f.province_code
      LEFT JOIN location_regions AS lr ON lr.region_code = f.region_code
      WHERE f.region_code = ? AND f.id IN (?) AND f.deleted_at IS NULL
      ORDER BY ft.type, f.with_sbf, fga.group_id
  `,
    {
      replacements: [current_user.region_code, difference],
      type: QueryTypes.SELECT,
    }
  );

  const assessors = await FacilityGroupIndicatorAssessor.findAll({ where: { indicator_id: indicator_ids } });
  const data = indicators.flatMap((indicator) => {
    let prevKey = '';
    let responses = '';

    const assessor_map = assessors.reduce((result: any, assessor: any) => {
      return { ...result, [assessor.group_id + '-' + assessor.indicator_id]: assessor.assessor_id };
    }, {});

    return facilities.map((facility: any) => {
      const currKey = facility.type + facility.with_sbf;
      if (prevKey !== currKey) {
        responses = JSON.stringify(getFresaaFile(JSON.parse(indicator.indicators), facility));
        prevKey = currKey;
      }

      const assessor = assessor_map[facility.group_id + '-' + indicator.id];

      return {
        facility_id: facility.id,
        batch_id: batch_id,
        indicator_id: indicator.id,
        assessor_id: assessor,
        status: assessor ? STATUS.ASSIGNED : STATUS.OPEN,
        responses: responses,
        created_by: current_user.id,
      };
    }) as FacilityAssessment[];
  });

  const subarrays = groupArrayIntoSubarrays(data, 100);
  subarrays.map(async (subarray) => {
    await delay(500);
    await FacilityAssessment.bulkCreate(subarray);
  });
};

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));
