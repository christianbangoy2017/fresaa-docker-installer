require('dotenv').config();

import { LocationRegion } from 'models';
import { getUserRegion } from './user.service';

export const uploadLogo = async (id: number, logos: any) => {
  try {
    const user_region_code = await getUserRegion(id);
    return LocationRegion.update(logos, {
      where: {
        region_code: user_region_code,
      },
    });
  } catch (err) {
    console.error(err);
    return Promise.reject(err);
  }
};
