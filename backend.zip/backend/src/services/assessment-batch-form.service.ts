import { AssessmentBatch, AssessmentBatchForm, FacilityAssessment } from 'models';

import { ApiQuery } from 'interfaces';
import { AssessmentBatchFormInput } from 'models/AssessmentBatchForm';
import AssessmentIndicators from 'models/AssessmentIndicator';
import { Op } from 'sequelize';
import { Response } from 'express';
import { UserOutput } from 'models/User';
import { createActivityLog } from './activity-log.service';
import { getLimitAndOffset } from 'utils';
import { getUserByToken } from './user.service';

export const get = async (id: number) => {
  return AssessmentBatchForm.findByPk(id);
};

export const getFormsByBatchId = async (batch_id: number) => {
  return (await AssessmentBatchForm.findAll({ where: { batch_id } })).map((form) => form.indicator_id);
};

export const getList = async (query: ApiQuery, batch_id: number, token: string) => {
  const current_user = await getUserByToken(token);
  const [limit, offset] = getLimitAndOffset(query);

  return AssessmentBatchForm.findAndCountAll({
    include: [
      {
        model: AssessmentIndicators,
        required: true,
        as: 'indicator',
        attributes: ['id', 'name'],
      },
    ],
    where: { batch_id },
    limit,
    offset,
  });
};

export const getAvailableForms = async (batch_id: number, token: string) => {
  const current_user = await getUserByToken(token);

  const included = (
    await AssessmentBatchForm.findAll({
      where: {
        batch_id,
      },
    })
  ).map((form) => form.indicator_id);

  return AssessmentIndicators.findAll({
    where: {
      id: { [Op.notIn]: included },
      region_code: current_user.region_code,
    },
    attributes: ['id', 'name'],
  });
};

export const create = async (request: AssessmentBatchFormInput, token: string, res: Response) => {
  const current_user = await getUserByToken(token);

  return AssessmentBatchForm.create(request).then((f) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Create assessment batch form',
      model: 'assessment-batch-form',
      model_id: f.id,
    };
    createActivityLog(payload);

    return get(f!.id);
  });
};

export const deleteItem = async (id: number, res: Response, current_user: UserOutput) => {
  return AssessmentBatchForm.destroy({ where: { id } }).then((u) => {
    const payload = {
      user_id: current_user.id,
      activity: 'Delete assessment batch form',
      model: 'assessment-batch-form',
      model_id: id,
    };

    createActivityLog(payload);

    return u;
  });
};
