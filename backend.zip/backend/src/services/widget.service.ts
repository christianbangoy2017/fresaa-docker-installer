import { Widget, WidgetGroup } from 'models';

export const get = async (id: number) => {
  return Widget.findByPk(id);
};

export const create = async (request: Widget, token: string) => {
  request.configuration = JSON.stringify(request.configuration);
  return Widget.create(request).then((f) => get(f!.id));
};

// change the type
export const update = async (id: number, request: Widget) => {
  request.configuration = JSON.stringify(request.configuration);
  return Widget.update(request, { where: { id } }).then(() => get(id));
};

export const deleteItem = async (id: number) => {
  return Widget.destroy({ where: { id } });
};
