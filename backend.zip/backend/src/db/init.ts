require('dotenv').config();

import {
  ActivityLog,
  AssessmentBatch,
  AssessmentBatchFacility,
  AssessmentBatchForm,
  AssessmentComment,
  AssessmentIndicators,
  AssessmentResponse,
  BlacklistedToken,
  Facility,
  FacilityAssessment,
  FacilityGroup,
  FacilityGroupAssignment,
  FacilityGroupIndicatorAssessor,
  FacilityReportEntry,
  FacilityReportEntryComment,
  FacilityType,
  FailedLoginAttempt,
  FormValidationWorkflow,
  LocationMunicipality,
  LocationProvince,
  LocationRegion,
  MobileLink,
  RefreshToken,
  Report,
  ReportEntry,
  ReportTemplate,
  ReportTemplateEntry,
  User,
  UserAuthority,
  UserGroup,
  UserGroupAuthority,
} from 'models';

const isDev = process.env.NODE_ENV === 'development';

const dbInit = async () => {
  await LocationRegion.sync({ alter: isDev });
  await LocationProvince.sync({ alter: isDev });
  await LocationMunicipality.sync({ alter: isDev });
  await UserGroup.sync({ alter: isDev });
  await UserAuthority.sync({ alter: isDev });
  await UserGroupAuthority.sync({ alter: isDev });
  await User.sync({ alter: isDev });
  await FacilityType.sync({ alter: isDev });
  await Facility.sync({ alter: isDev });
  await FacilityGroup.sync({ alter: isDev });
  await FacilityGroupAssignment.sync({ alter: isDev });
  await FormValidationWorkflow.sync({ alter: isDev });
  await AssessmentIndicators.sync({ alter: isDev });
  await AssessmentBatch.sync({ alter: isDev });
  await FacilityAssessment.sync({ alter: isDev });
  await AssessmentResponse.sync({ alter: isDev });
  await RefreshToken.sync({ alter: isDev });
  await ActivityLog.sync({ alter: isDev });
  await AssessmentComment.sync({ alter: isDev });
  await Report.sync({ alter: isDev });
  await ReportEntry.sync({ alter: isDev });
  await ReportTemplate.sync({ alter: isDev });
  await ReportTemplateEntry.sync({ alter: isDev });
  await FacilityReportEntry.sync({ alter: isDev });
  await AssessmentBatchForm.sync({ alter: isDev });
  await AssessmentBatchFacility.sync({ alter: isDev });
  await FacilityReportEntryComment.sync({ alter: isDev });
  await MobileLink.sync({ alter: isDev });
  await FacilityGroupIndicatorAssessor.sync({ alter: isDev });
  await BlacklistedToken.sync({ alter: isDev });
  await FailedLoginAttempt.sync({ alter: isDev });

  ActivityLog.belongsTo(User, {
    as: 'user',
    foreignKey: 'user_id',
  });

  AssessmentBatch.belongsTo(AssessmentIndicators, {
    as: 'indicator',
    foreignKey: 'indicator_id',
  });

  AssessmentBatchFacility.hasOne(AssessmentBatch, {
    as: 'assessment_batch',
    foreignKey: 'id',
    sourceKey: 'batch_id',
  });

  AssessmentBatchFacility.hasOne(Facility, {
    as: 'facility',
    foreignKey: 'id',
    sourceKey: 'facility_id',
  });

  AssessmentBatchForm.belongsTo(AssessmentIndicators, {
    as: 'indicator',
    foreignKey: 'indicator_id',
  });

  AssessmentComment.belongsTo(User, {
    as: 'user',
    foreignKey: 'user_id',
  });

  AssessmentComment.belongsTo(FacilityAssessment, {
    as: 'facility_assessments',
    foreignKey: 'assessment_id',
  });

  AssessmentIndicators.belongsTo(LocationRegion, {
    as: 'location_region',
    foreignKey: 'region_code',
  });

  AssessmentIndicators.belongsTo(FormValidationWorkflow, {
    as: 'form_validation_workflow',
    foreignKey: 'validation_workflow_id',
  });

  AssessmentResponse.hasOne(Facility, {
    as: 'facility',
    foreignKey: 'id',
    sourceKey: 'facility_id',
  });

  AssessmentResponse.hasOne(FacilityAssessment, {
    as: 'facility_assessment',
    foreignKey: 'id',
    sourceKey: 'assessment_id',
  });

  Facility.hasOne(FacilityType, {
    as: 'facility_type',
    foreignKey: 'id',
    sourceKey: 'facility_type_id',
  });

  Facility.hasOne(LocationRegion, {
    as: 'region',
    foreignKey: 'region_code',
    sourceKey: 'region_code',
  });

  Facility.hasOne(LocationProvince, {
    as: 'province',
    foreignKey: 'province_code',
    sourceKey: 'province_code',
  });

  Facility.hasOne(LocationMunicipality, {
    as: 'municipality',
    foreignKey: 'municipality_code',
    sourceKey: 'municipality_code',
  });

  FacilityAssessment.hasOne(AssessmentBatch, {
    as: 'assessment_batch',
    foreignKey: 'id',
    sourceKey: 'batch_id',
  });

  FacilityAssessment.hasOne(AssessmentIndicators, {
    as: 'assessment_indicator',
    foreignKey: 'id',
    sourceKey: 'indicator_id',
  });

  FacilityAssessment.hasOne(Facility, {
    as: 'facility',
    foreignKey: 'id',
    sourceKey: 'facility_id',
  });

  FacilityAssessment.hasOne(User, {
    as: 'assessor',
    foreignKey: 'id',
    sourceKey: 'assessor_id',
  });

  FacilityAssessment.hasOne(User, {
    as: 'reviewer',
    foreignKey: 'id',
    sourceKey: 'reviewer_id',
  });

  FacilityAssessment.hasOne(User, {
    as: 'approver',
    foreignKey: 'id',
    sourceKey: 'approver_id',
  });

  FacilityAssessment.hasOne(User, {
    as: 'dmo_approver',
    foreignKey: 'id',
    sourceKey: 'dmo_approver_id',
  });

  FacilityGroup.hasMany(FacilityGroupAssignment, {
    foreignKey: 'group_id',
    as: 'facilities',
  });
  FacilityGroup.belongsTo(User, { foreignKey: 'assessor_id', as: 'assessor' });

  FacilityGroup.hasMany(FacilityGroupIndicatorAssessor, {
    as: 'facility_group_indicator_assessor',
    foreignKey: 'group_id',
  });

  User.hasMany(FacilityGroup, { foreignKey: 'assessor_id' });

  FacilityGroupAssignment.belongsTo(Facility, {
    foreignKey: 'facility_id',
    as: 'facility',
  });

  Facility.hasOne(FacilityGroupAssignment, {
    as: 'facility_group',
    foreignKey: 'facility_id',
    sourceKey: 'id',
  });

  FacilityReportEntry.hasOne(ReportEntry, {
    as: 'report_entry',
    foreignKey: 'id',
    sourceKey: 'report_entry_id',
  });

  FacilityReportEntry.hasOne(Facility, {
    as: 'facility',
    foreignKey: 'id',
    sourceKey: 'facility_id',
  });

  FacilityReportEntry.hasOne(User, {
    as: 'assessor',
    foreignKey: 'id',
    sourceKey: 'assessor_id',
  });

  FacilityReportEntry.hasOne(User, {
    as: 'approver',
    foreignKey: 'id',
    sourceKey: 'approver_id',
  });

  FacilityReportEntryComment.belongsTo(User, {
    as: 'user',
    foreignKey: 'user_id',
  });

  FacilityReportEntryComment.belongsTo(FacilityReportEntry, {
    as: 'facility_report_entry',
    foreignKey: 'facility_report_entry_id',
  });

  Report.belongsTo(AssessmentIndicators, {
    as: 'indicator',
    foreignKey: 'indicator_id',
  });

  ReportEntry.belongsTo(Report, {
    as: 'report',
    foreignKey: 'report_id',
  });

  User.hasOne(UserGroup, {
    as: 'user_group',
    foreignKey: 'id',
    sourceKey: 'user_group_id',
  });

  User.hasOne(LocationRegion, {
    as: 'region',
    foreignKey: 'region_code',
    sourceKey: 'region_code',
  });

  User.hasOne(LocationProvince, {
    as: 'province',
    foreignKey: 'province_code',
    sourceKey: 'province_code',
  });

  User.hasOne(LocationMunicipality, {
    as: 'municipality',
    foreignKey: 'municipality_code',
    sourceKey: 'municipality_code',
  });

  User.hasOne(Facility, {
    as: 'facility',
    foreignKey: 'id',
    sourceKey: 'facility_id',
  });
};

export default dbInit;
