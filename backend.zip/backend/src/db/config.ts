import { Dialect, Sequelize } from 'sequelize';

require('dotenv').config();

const dbName = process.env.DB_NAME as string;
const dbUser = process.env.DB_USER as string;
const dbHost = process.env.DB_HOST;
const dbDriver = process.env.DB_DRIVER as Dialect;
const dbPassword = process.env.DB_PASSWORD;
const dbPort = process.env.DB_PORT as unknown as number;
const dbTimezone = process.env.DB_TIMEZONE;
const isDev = process.env.NODE_ENV === 'development';

const sequelizeConnection = new Sequelize(dbName, dbUser, dbPassword, {
  host: dbHost,
  dialect: dbDriver,
  port: dbPort,
  timezone: dbTimezone,
  logging: isDev,
});

export default sequelizeConnection;
