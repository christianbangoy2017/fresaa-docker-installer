require('dotenv').config();

import * as jwt from 'jsonwebtoken';

import { ApiQuery } from 'interfaces';
import { FacilityAssessmentOuput } from 'models/FacilityAssessment';
import { Response } from 'express';
import { UserModel } from 'interfaces/user.interface';
import { getUserAuthorities } from 'services/user.service';

const jwtSecret = process.env.JWT_SECRET as string;

export const checkUserAuthority = async (
  token: string,
  required_auth: string[], //OR operator
  res: Response
) => {
  const decoded = (await jwt.verify(token, jwtSecret)) as any;
  const auths = await getUserAuthorities(decoded.id);
  const verified_auths = required_auth.filter((r) => auths.includes(r));

  if (!verified_auths.length) {
    res.status(403).json({ message: 'User is not authorized to do the action.' });
  }

  return verified_auths;
};

export const useridByToken = async (token: string) => {
  const decoded = (await jwt.verify(token, jwtSecret)) as any;
  return decoded.id;
};

export const changeBlankToNull: any = (obj: any) => {
  for (var key in obj) {
    if (obj[key] === '') {
      obj[key] = null;
    }
  }

  return obj;
};

export const removeBlankProperty: any = (obj: any, skip?: string[]) => {
  for (var key in obj) {
    if (obj[key] === '' && (!skip || !skip.includes(key))) {
      delete obj[key];
    }
  }

  return obj;
};

export const getLimitAndOffset: any = (query: ApiQuery) => {
  const page = query.page ? query.page * 1 : 1;
  const limit = query.length ? query.length * 1 : 10;
  const offset = (page - 1) * limit;
  return [limit, offset];
};

export const numberToLetters = (number: number) => {
  let letters = '';
  while (number > 0) {
    number--;
    letters = String.fromCharCode((number % 26) + 65) + letters;
    number = Math.floor(number / 26);
  }
  return letters;
};

export const addLeadingZeroes = (number: number, length: number) => {
  return String(number).padStart(length, '0');
};

export const getFresaaFile = (indicators: any, facility?: any) => {
  return processIndicator(indicators, facility);
};

const processIndicator = (indicator: any, facility?: any) => {
  const list: string[] = [];
  indicator.forEach((section: any) => updateFieldCode(section, list, undefined, facility));
  // if (facility) {
  //   const sectionZeroBody = indicator[0].section_body;
  //   sectionZeroBody[0].response = facility.facility_name;
  //   sectionZeroBody[1].response = facility.facility_code;
  //   sectionZeroBody[2].response = facility.gis_code;
  //   sectionZeroBody[3].response = `${facility.barangay_name}, ${facility.municipality_name}`;
  //   sectionZeroBody[4].response = `${facility.province_name}, ${facility.region_name}`;
  //   sectionZeroBody[6].response = facility.type;
  //   sectionZeroBody[7].response = facility.managing_authority;
  // }

  return indicator;
};

const updateFieldCode = (item: any, list: any[], parent_list?: string[], facility?: any) => {
  if (!item.type || item.type === 'section' || item.type === 'sub-section') {
    const field_items = item.type === 'sub-section' ? item.section_content : item.section_body;
    field_items.forEach((body: any) => updateFieldCode(body, list, parent_list, facility));
  }

  if (item.type === 'conditional-field') {
    updateFieldCodeConditionalField(item, list, parent_list, facility);
  } else if (item.type === 'parent' || item.type === 'table') {
    updateFieldCodeParentAndTable(item, list, facility);
  } else if (item.field_code) {
    updateFieldCodeItem(item, list, parent_list);
    checkApplicability(facility, item);
  }

  if (item.type === 'table') {
    if (item.table_type === 'simple-table') {
      item.rows.forEach((row: any) => {
        checkApplicability(facility, row);
      });
    } else {
      item.rows.forEach((row: any) => {
        let response: any = {};
        const row_applicable = checkApplicability(facility, row, true);
        item.columns.forEach((column: any) => {
          if (column.children) {
            column.children.forEach((child: any) => {
              const col_applicable = checkApplicability(facility, child, true);
              const key = column.name + ' | ' + child.name;
              response = {
                ...response,
                [key]: row_applicable && col_applicable ? undefined : 'N/A',
              };
            });
          } else {
            const col_applicable = checkApplicability(facility, column, true);
            response = {
              ...response,
              [column.name]: row_applicable && col_applicable ? undefined : 'N/A',
            };
          }
        });
        row.response = response;
      });
    }
  }
};

const updateFieldCodeConditionalField = (item: any, list: any[], parent_list?: string[], facility?: any) => {
  if (item.field_code) {
    if (parent_list) {
      parent_list.push('');
      item.field_code = `${addLeadingZeroes(list.length, 3)}${numberToLetters(parent_list.length)}`;
      item.field_id = item.field_code;
    } else {
      list.push('');
      item.field_code = `${addLeadingZeroes(list.length, 3)}`;
      item.field_id = item.field_code;
    }

    item.children.forEach((child: any) => updateFieldCode(child, list, parent_list, facility));
  }
};

const updateFieldCodeParentAndTable = (item: any, list: any[], facility?: any) => {
  const parent: string[] = [];

  if (item.field_code) {
    list.push(parent);
    item.field_code = `${addLeadingZeroes(list.length, 3)}`;
    item.field_id = item.field_code;
  }

  const field_items = item.type === 'parent' ? item.children : item.rows;
  field_items.forEach((child: any) => updateFieldCode(child, list, item.field_code ? parent : undefined, facility));
};

const updateFieldCodeItem = (item: any, list: any[], parent_list?: string[]) => {
  if (parent_list) {
    parent_list.push('');
    item.field_code = `${addLeadingZeroes(list.length, 3)}${numberToLetters(parent_list.length)}`;
    item.field_id = item.field_code;
  } else {
    list.push('');
    item.field_code = `${addLeadingZeroes(list.length, 3)}`;
    item.field_id = item.field_code;
  }
};

const checkApplicability = (facility: any, item: any, skipSetApplicability?: boolean) => {
  if (!facility) return true;
  if (item.applicable) {
    return setApplicability(
      item,
      item.applicable.includes(facility.type) ||
        (item.applicable.includes('Safe Birthing Facility') && facility.with_sbf),
      skipSetApplicability
    );
  } else if (item.not_applicable) {
    return setApplicability(item, !item.not_applicable.includes(facility.type), skipSetApplicability);
  } else {
    return setApplicability(item, true, skipSetApplicability);
  }
};

const setApplicability = (item: any, applicable: boolean, skipSetApplicability?: boolean) => {
  if (skipSetApplicability) return applicable;
  if (applicable) {
    item.indicator_not_applicable = undefined;
    item.response = item.response ?? undefined;
  } else {
    item.indicator_not_applicable = true;
    item.response = item.response ?? 'N/A';
  }
  return applicable;
};

export const getResponses = (assessment: FacilityAssessmentOuput, user?: UserModel) => {
  const section = JSON.parse(assessment.responses);
  return section.flatMap((section: any) => {
    return section.section_body.flatMap((body: any) => {
      return flatSections(body, assessment, user);
    });
  });
};

export const flatSections = (item: any, assessment: FacilityAssessmentOuput, user?: UserModel) => {
  if (item.type === 'section') {
    return item.section_body.flatMap((body: any) => flatSections(body, assessment, user));
  }
  if (item.type === 'sub-section') {
    return item.section_content.flatMap((body: any) => flatSections(body, assessment, user));
  }
  if (item.type === 'parent') {
    return item.children.flatMap((child: any) => flatSections(child, assessment, user));
  }
  if (item.type === 'conditional-field') {
    const fields = [
      {
        batch_id: assessment.batch_id,
        facility_id: assessment.facility.id,
        assessment_id: assessment.id,
        region_code: assessment.facility.region_code,
        province_code: assessment.facility.province_code,
        municipality_code: assessment.facility.municipality_code,
        item_name: item.field_name,
        item_code: item.field_code,
        item_id: item.field_id,
        item_response: item.response,
        created_by: user?.id ?? undefined,
      },
    ];

    return [...fields, ...item.children.flatMap((child: any) => flatSections(child, assessment, user))];
  }
  if (item.type === 'table') {
    if (item.table_type === 'simple-table') {
      return item.rows.flatMap((row: any) => flatSections(row, assessment, user));
    } else {
      return item.rows.flatMap((row: any) => {
        return item.columns.flatMap((col: any) => {
          if (col.type === 'parent') {
            return col.children.map((child: any) => {
              const key = col.name + ' | ' + child.name;
              return {
                batch_id: assessment.batch_id,
                facility_id: assessment.facility.id,
                assessment_id: assessment.id,
                region_code: assessment.facility.region_code,
                province_code: assessment.facility.province_code,
                municipality_code: assessment.facility.municipality_code,
                created_by: user?.id ?? undefined,
                item_code: row.field_code + '-' + child.code,
                item_id: row.field_id + '-' + child.code,
                item_name: row.field_name + ' - ' + child.name,
                item_response: row.response ? row.response[key] : '',
              };
            });
          }
          return {
            batch_id: assessment.batch_id,
            facility_id: assessment.facility.id,
            assessment_id: assessment.id,
            region_code: assessment.facility.region_code,
            province_code: assessment.facility.province_code,
            municipality_code: assessment.facility.municipality_code,
            created_by: user?.id ?? undefined,
            item_code: row.field_code + '-' + col.code,
            item_id: row.field_id + '-' + col.code,
            item_name: row.field_name + ' - ' + col.name,
            item_response: row.response ? row.response[col.name] : '',
          };
        });
      });
    }
  }

  return {
    batch_id: assessment.batch_id,
    facility_id: assessment.facility.id,
    assessment_id: assessment.id,
    region_code: assessment.facility.region_code,
    province_code: assessment.facility.province_code,
    municipality_code: assessment.facility.municipality_code,
    item_name: item.field_name,
    item_code: item.field_code,
    item_id: item.field_id,
    item_response: item.response,
    created_by: user?.id ?? undefined,
  };
};

export const groupArrayIntoSubarrays = (array: any[], size: number) => {
  const subarrays = [];
  const length = Math.ceil(array.length / size);

  for (let i = 0; i < length; i++) {
    subarrays.push(array.slice(i * size, (i + 1) * size));
  }

  return subarrays;
};

export const safeIntParse = (num: number) => {
  return parseInt(num.toString());
};

export const getAssessmentResponses = (sections: any[]) => {
  return sections.flatMap((section) => {
    return section.section_body.flatMap((body: any) => {
      return flattenResponses(body);
    });
  });
};

export const flattenResponses = (item: any) => {
  if (item.type === 'section') {
    return item.section_body.flatMap((body: any) => flattenResponses(body));
  }
  if (item.type === 'sub-section') {
    return item.section_content.flatMap((body: any) => flattenResponses(body));
  }
  if (item.type === 'parent') {
    return item.children.flatMap((child: any) => flattenResponses(child));
  }
  if (item.type === 'conditional-field') {
    const fields = [
      {
        field_code: item.field_code,
        field_name: item.field_name,
        response: item.response,
      },
    ];

    return [...fields, ...item.children.flatMap((child: any) => flattenResponses(child))];
  }
  if (item.type === 'table') {
    if (item.table_type === 'simple-table') {
      return item.rows.flatMap((row: any) => flattenResponses(row));
    } else {
      return item.rows.flatMap((row: any) => {
        return item.columns.flatMap((col: any) => {
          if (col.type === 'parent') {
            return col.children.map((child: any) => {
              const key = col.name + ' | ' + child.name;
              return {
                field_code: row.field_code + '-' + child.code,
                field_name: row.field_name + ' - ' + child.name,
                response: row.response ? row.response[key] : '',
              };
            });
          }
          return {
            field_code: row.field_code + '-' + col.code,
            field_name: row.field_name + ' - ' + col.name,
            response: row.response ? row.response[col.name] : '',
          };
        });
      });
    }
  }

  return {
    field_code: item.field_code,
    field_name: item.field_name,
    response: item.response,
  };
};

export const makeCsvSafe = (inputString: string) => {
  inputString = `${inputString}`;
  // Check if the string contains special characters or needs quoting
  if (/[",\n\r]/.test(inputString)) {
    // If the string contains double quotes, escape them by doubling them
    inputString = inputString.replace(/"/g, '""');

    // If the string contains special characters or spaces, wrap it in double quotes
    inputString = `"${inputString}"`;
  }

  return inputString?.replace('’', "'");
};
