// import { matchedData, validationResult } from 'express-validator';
import { ControllerParam } from 'interfaces';
import * as reportTemplateService from 'services/report-template.service';
// import { changeBlankToNull, removeBlankProperty } from 'utils';

const entity_name = 'Report Template';

export const getAllReportTemplate = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await reportTemplateService.getAll(req.query);
    if (!result) res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getOneReportTemplate = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await reportTemplateService.get(parseInt(req.params.id));
    if (!result) res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// export const createReportTemplate = async ({ req, res, next }: ControllerParam) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

//     const payload = changeBlankToNull(req);
//     res.json(await reportTemplateService.create(payload));
//   } catch (err) {
//     next(err);
//   }
// };

// export const updateReportTemplate = async ({ req, res, next }: ControllerParam) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

//     const payload = removeBlankProperty(matchedData(req));
//     const result = await reportTemplateService.update(parseInt(req.params.id), payload);

//     if (!result) {
//       res.status(404).json({ message: `${entity_name} not found.` });
//     }
//     res.json(result);
//   } catch (err) {
//     next(err);
//   }
// };

// export const deleteOneReportTemplate = async ({ req, res, next }: ControllerParam) => {
//   try {
//     const result = await reportTemplateService.deleteOne(parseInt(req.params.id));
//     if (!result) {
//       res.status(404).json({ message: `${entity_name} not found.` });
//     }
//     res.json({ message: `${entity_name} deleted.` });
//   } catch (err) {
//     next(err);
//   }
// };
