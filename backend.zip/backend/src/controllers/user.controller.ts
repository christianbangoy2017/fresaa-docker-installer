import * as service from 'services/user.service';

import { ControllerParam, PasswordParam } from 'interfaces';
import { changeBlankToNull, checkUserAuthority } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { UserInput } from 'models/User';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'User';

export const getCurrentUser = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const user = (await service.getUserByToken(token)) as any;
    if (user) {
      const authorities = await service.getUserAuthorities(user.id);
      res.json({ ...user.dataValues, authorities });
    } else {
      res.status(401).json({ message: 'Unauthenticated' });
    }
  } catch (err) {
    next(err);
  }
};

export const getUser = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      ['MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_CITY_PROVINCIAL_ACCOUNT', 'MANAGE_ALL_ACCOUNTS'],
      res
    );

    const result = await service.getUserById(parseInt(req.params.id));
    if (!result) {
      res.status(404).json({ message: 'User not found.' });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAll = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const verified_auths = await checkUserAuthority(
      token,
      ['MANAGE_ALL_ACCOUNTS', 'MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_CITY_PROVINCIAL_ACCOUNT'],
      res
    );

    if (verified_auths.includes('MANAGE_ALL_ACCOUNTS')) {
      res.json(await service.getUserList(req.query, token, 'A'));
    } else if (verified_auths.includes('MANAGE_NATIONAL_REGIONAL_ACCOUNT')) {
      res.json(await service.getUserList(req.query, token, 'R'));
    } else {
      res.json(await service.getUserList(req.query, token, 'P'));
    }
  } catch (err) {
    next(err);
  }
};

export const getUserDropdown = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    res.json(await service.getUserListDropdown(token, req.query));
  } catch (err) {
    next(err);
  }
};

export const registerUser = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    const payload = changeBlankToNull(matchedData(req)) as UserInput;
    const user_group = payload.user_group_id * 1;

    if ([1, 2, 7, 8].includes(user_group)) {
      await checkUserAuthority(token, ['MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_ALL_ACCOUNTS'], res);
    } else if ([3, 4, 5, 6].includes(user_group)) {
      await checkUserAuthority(
        token,
        ['MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_CITY_PROVINCIAL_ACCOUNT', 'MANAGE_ALL_ACCOUNTS'],
        res
      );
    }

    res.json(await service.register(payload, token));
  } catch (err) {
    next(err);
  }
};

export const updateUser = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const mappedErrors = errors.mapped();
      // Remove the `value` property from each error
      Object.keys(mappedErrors).forEach((key) => {
        delete mappedErrors[key].value;
      });
      return res.status(400).json(mappedErrors);
    }

    const token = getTokenFromHeaders(req.headers);
    const current_user = await service.getUserByToken(token);
    const payload = matchedData(req) as UserInput;

    const user_id = parseInt(req.params.id);
    const user_old = await service.getUserById(user_id);
    const user_group = payload.user_group_id ? payload.user_group_id * 1 : user_old.user_group_id;

    if ([1, 2, 7, 8].includes(user_group)) {
      await checkUserAuthority(token, ['MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_ALL_ACCOUNTS'], res);
    } else if ([3, 4, 5, 6].includes(user_group)) {
      await checkUserAuthority(
        token,
        ['MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_CITY_PROVINCIAL_ACCOUNT', 'MANAGE_ALL_ACCOUNTS'],
        res
      );
    }

    res.json(await service.update(user_id, current_user.id, payload));
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_ALL_ACCOUNTS', 'MANAGE_NATIONAL_REGIONAL_ACCOUNT'], res);
    const current_user = await service.getUserByToken(token);

    const update = await service.updateDeletedBy(parseInt(req.params.id), current_user.id);
    const result = await service.deleteItem(parseInt(req.params.id), current_user);

    if (!update || !result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const changePassword = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    const payload = matchedData(req) as PasswordParam;
    res.json(await service.changePassword(payload, token));
  } catch (err: any) {
    res.status(400).send({ message: err.message });
  }
};
