import * as service from 'services/user-group.service';

import { ControllerParam } from 'interfaces';
import { checkUserAuthority } from 'utils';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'User Group';

export const getAll = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      ['MANAGE_NATIONAL_REGIONAL_ACCOUNT', 'MANAGE_CITY_PROVINCIAL_ACCOUNT', 'MANAGE_ALL_ACCOUNTS'],
      res
    );

    const result = await service.getAll(token, !!req.query.validator);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};
