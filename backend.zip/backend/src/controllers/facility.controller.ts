import * as groupAssignmentService from 'services/facility-group-assignment.service';
import * as service from 'services/facility.service';
import * as utilService from 'services/facility-utils.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { Facility } from 'models';
import { Op } from 'sequelize';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Facility';

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);

    const result = await service.get(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const batch_id = parseInt(req.params.batch_id);
    const result = await service.getList(req.query, token, batch_id);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAllFacilities = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const result = await service.listAllFacilities(token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAvailable = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const batch_id = parseInt(req.params.batch_id);
    const result = await service.getAvailableList(batch_id, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAvailableNotSelected = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);

    const group_id = parseInt(req.params.group_id);
    const result = await service.getAvailableListNotSelected(req.query, token, group_id);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);

    const payload = changeBlankToNull(matchedData(req));
    const existingRecord = await Facility.findOne({
      where: { facility_code: payload.facility_code },
    });

    if (existingRecord) {
      res.status(400).json({ facility_code: { msg: 'Facility Code already exist' } });
      return;
    }
    res.json(await service.create(payload, token));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);
    const current_user = await getUserByToken(token);

    const payload = removeBlankProperty(matchedData(req), ['gis_code', 'street_name', 'building_name', 'zip_code']);
    payload.updated_by = current_user.id;
    const existingRecord = await Facility.findOne({
      where: {
        facility_code: payload.facility_code,
        id: { [Op.ne]: req.params.id },
      },
    });

    if (existingRecord) {
      return res.status(400).json({ facility_code: { msg: 'Facility Code already exist' } });
    }

    const result = await service.update(parseInt(req.params.id), payload, current_user.id);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);
    const current_user = await getUserByToken(token);
    const request = {
      deleted_by: current_user.id,
      facility_code: req.params.id,
    };

    const update = await service.update(parseInt(req.params.id), request);
    const result = await service.deleteItem(parseInt(req.params.id), current_user);

    if (!update || !result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    } else {
      groupAssignmentService.deleteItemByFacilityId(parseInt(req.params.id));
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const assignFacilityToGroup = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);

    const group_id = parseInt(req.params.group_id);
    const payload = req.body;

    res.json(await utilService.assignFacilityToGroup(payload, group_id, token));
  } catch (err) {
    next(err);
  }
};

export const getFieldAssessors = async ({ req, res, next }: ControllerParam) => {
  try {
    const provinceCode = req.params.province_code;
    const token = getTokenFromHeaders(req.headers);
    const result = await utilService.getFieldAssessors(token, provinceCode);

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteFacilityToGroup = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);

    res.json(await utilService.deleteFacilityToGroup(req.body, token));
  } catch (err) {
    next(err);
  }
};

export const createFacilitiesCSV = async ({ req, res, next }: any) => {
  try {
    if (!req.files || !req.files.file) {
      throw new Error('No file uploaded');
    }
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_PROVINCIAL_FACILITIES'], res);

    const file = req.files.file as any;
    const current_user = await getUserByToken(token);
    // Read the file buffer and create the facilities
    const result = await service.createFacilitiesCSV(file.data, current_user);

    // Return the result as JSON
    res.json(result);
  } catch (error: any) {
    // Return the error as JSON
    res.status(400).json({ error: error.message });
  }
};

export const getAvailableRegion = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const result = await utilService.getAvailableRegion(token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAvailableProvince = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await utilService.getAvailableProvince(req.query.region_code as string);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAvailableMunicipality = async ({ req, res, next }: ControllerParam) => {
  try {
    const { region_code, province_code } = req.query as any;
    const result = await utilService.getAvailableMunicipality(province_code, region_code);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getFacilityTypes = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await utilService.getFacilityTypes();

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};
