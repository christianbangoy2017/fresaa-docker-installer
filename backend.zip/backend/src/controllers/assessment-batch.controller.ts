import * as service from 'services/assessment-batch.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Assessment Batch';

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MANAGE_FRESAA_BATCHES',
        'VIEW_FRESAA_BATCHES',
        'VIEW_REGIONAL_DASHBOARD',
        'VIEW_PROVINCIAL_DASHBOARD',
        'VIEW_NATIONAL_DASHBOARD',
        'VIEW_MUNICIPAL_DASHBOARD',
      ],
      res
    );

    const result = await service.get(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MANAGE_FRESAA_BATCHES',
        'VIEW_FRESAA_BATCHES',
        'VIEW_REGIONAL_DASHBOARD',
        'VIEW_PROVINCIAL_DASHBOARD',
        'VIEW_NATIONAL_DASHBOARD',
        'VIEW_MUNICIPAL_DASHBOARD',
      ],
      res
    );

    const result = await service.getList(req.query, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const payload = changeBlankToNull(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.created_by = current_user.id;
    res.json(await service.create(payload, token, res));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const payload = removeBlankProperty(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.updated_by = current_user.id;
    const result = await service.update(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const updateStatus = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const result = await service.updateStatus(parseInt(req.params.id), req.params.status, res, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const current_user = await getUserByToken(token);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const update = await service.updateDeletedBy(parseInt(req.params.id), current_user.id);
    const result = await service.deleteItem(parseInt(req.params.id), res, current_user);

    if (!update || !result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};
