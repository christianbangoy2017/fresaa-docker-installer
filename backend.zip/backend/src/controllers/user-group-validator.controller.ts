import * as service from 'services/user-group-validator.service';
import * as userGroupAuthService from 'services/user-group-authority.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { UserGroup } from 'models';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'User Group Validator';

export const getAll = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_NATIONAL_REGIONAL_ACCOUNT'], res);

    const result = await service.getAll(req.query, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    const current_user = await getUserByToken(token);
    try {
      await checkUserAuthority(token, ['MANAGE_NATIONAL_REGIONAL_ACCOUNT'], res);
    } catch (err) {
      next(err);
    }

    const payload = changeBlankToNull(matchedData(req));
    payload.validator = true;
    payload.region_code = current_user.region_code;

    const existingRecord = await UserGroup.findOne({
      where: {
        group_name: payload.group_name,
      },
    });

    if (existingRecord) {
      return res.status(400).json({ message: 'User group already exists! User group name should be unique.' });
    }

    res.json(await service.create(payload, token));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_NATIONAL_REGIONAL_ACCOUNT'], res);

    const payload = removeBlankProperty(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.updated_by = current_user.id;
    const result = await service.update(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_NATIONAL_REGIONAL_ACCOUNT'], res);

    const deleteUserGroupAuthResult = await userGroupAuthService.deleteItem(parseInt(req.params.id));

    if (!deleteUserGroupAuthResult) {
      res.status(404).json({ message: `Error deleting User Group Authority for User Group: ${req.params.id}` });
    }
    const result = await service.deleteItem(parseInt(req.params.id), token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};
