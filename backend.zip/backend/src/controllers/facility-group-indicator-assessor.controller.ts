import * as service from 'services/facility-group-indicator-assessor.service';

import { checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Facility Group Assessment Indicator';

export const updateGroupIndicatorAssessor = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const groupId = parseInt(req.params.id);
    const result = await service.update(groupId, req.body);
    if (!result) return res.status(400).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const result = await service.deleteOne(parseInt(req.params.id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAssessorsByGroupID = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const result = await service.getAssessorsByGroupID(parseInt(req.params.id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};
