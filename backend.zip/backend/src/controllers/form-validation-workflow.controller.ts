import * as service from 'services/form-validation-workflow.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Form Validation Workflow';

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES'], res);

    const result = await service.get(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES'], res);

    const result = await service.getList(req.query, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES'], res);

    const current_user = await getUserByToken(token);
    const payload = changeBlankToNull(matchedData(req));
    payload.region_code = current_user.region_code;
    res.json(await service.create(payload));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES'], res);

    const payload = removeBlankProperty(matchedData(req));
    const result = await service.update(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await service.deleteItem(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    } else {
      res.json({ message: `${entity_name} deleted.` });
    }
  } catch (err) {
    next(err);
  }
};
