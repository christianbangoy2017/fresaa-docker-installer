import * as service from 'services/assessment-batch-facility.service';

import { changeBlankToNull, checkUserAuthority, useridByToken } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Assessment Batch Facility';

// gets the assessment batch facility details
export const getManyByBatchId = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES', 'VIEW_FRESAA_BATCHES'], res);

    const result = await service.getManyByBatchId(parseInt(req.params.batch_id), token, req.query);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

// get all facility details not in assessment batch
export const getFacilitiesNotIn = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES', 'VIEW_FRESAA_BATCHES'], res);

    const result = await service.getFacilityNotInBatchAssessment(parseInt(req.params.batch_id), token, req.query);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getFacilityAssessment = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES', 'VIEW_FRESAA_BATCHES'], res);

    const { batch_id, indicator_id, facility_id } = req.params;
    const result = await service.getFacilityAssessment(
      parseInt(batch_id),
      parseInt(indicator_id),
      token,
      facility_id ? parseInt(facility_id) : undefined
    );

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getDashboardData = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      ['VIEW_REGIONAL_DASHBOARD', 'VIEW_PROVINCIAL_DASHBOARD', 'VIEW_NATIONAL_DASHBOARD', 'VIEW_MUNICIPAL_DASHBOARD'],
      res
    );

    const { batch_id, indicator_id, facility_id } = req.params;
    const result = await service.getFacilityAssessment(
      parseInt(batch_id),
      parseInt(indicator_id),
      token,
      facility_id ? parseInt(facility_id) : undefined,
      true
    );

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

// creates assessment batch for the specified facility_ids
export const createMany = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const payload = changeBlankToNull(matchedData(req));
    const userid = await useridByToken(token);
    const result = await service.createMultiple(parseInt(req.params.batch_id), parseInt(userid), payload.facility_ids);

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// creates assessment batch for all the facilities
export const createForAll = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const result = await service.createAll(parseInt(req.params.batch_id), token);

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// delete multiple assessment batch
export const deleteMany = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const payload = changeBlankToNull(matchedData(req));
    const result = await service.deleteMultiple(payload.assessment_batch_facility_ids as number[]);

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// delete multiple assessment batch
export const deleteAllByBatch = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const result = await service.deleteAll(parseInt(req.params.batch_id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// delete all assessment batch facility in batch
export const deleteManyByBatchId = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const result = await service.deleteManyByBatchId(parseInt(req.params.batch_id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};
