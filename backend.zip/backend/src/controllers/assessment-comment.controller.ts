import * as service from 'services/assessment-comment.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Assessment Comment';

export const getAll = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MANAGE_FRESAA_BATCHES',
        'VIEW_FRESAA_BATCHES',
        'REVIEW_FRESAA_QUESTIONNAIRE',
        'ANSWER_FRESAA_QUESTIONNAIRE',
        'MANAGE_FACILITY',
      ],
      res
    );

    const result = await service.getAll();

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MANAGE_FRESAA_BATCHES',
        'VIEW_FRESAA_BATCHES',
        'REVIEW_FRESAA_QUESTIONNAIRE',
        'ANSWER_FRESAA_QUESTIONNAIRE',
        'MANAGE_FACILITY',
      ],
      res
    );

    const result = await service.getMultiple(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    try {
      await checkUserAuthority(
        token,
        ['REVIEW_FRESAA_QUESTIONNAIRE', 'ANSWER_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'],
        res
      );
    } catch (err) {
      next(err);
    }

    const payload = changeBlankToNull(matchedData(req));

    res.json(await service.create(payload, token));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      ['REVIEW_FRESAA_QUESTIONNAIRE', 'ANSWER_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'],
      res
    );
    const current_user = await getUserByToken(token);

    const payload = removeBlankProperty(matchedData(req));
    const result = await service.update(parseInt(req.params.id), current_user.id, payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const updateStatus = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);
    const status = req.body.status;

    const result = await service.updateStatus(req, parseInt(req.params.id), status, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const updateAllStatus = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.updateAllStatus(parseInt(req.body.assessment_id), req.body.field_code, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const current_user = await getUserByToken(token);
    await checkUserAuthority(
      token,
      ['REVIEW_FRESAA_QUESTIONNAIRE', 'ANSWER_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'],
      res
    );

    const result = await service.deleteItem(parseInt(req.params.id), current_user.id);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};
