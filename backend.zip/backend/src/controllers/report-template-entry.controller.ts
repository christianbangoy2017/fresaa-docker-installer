import { matchedData, validationResult } from 'express-validator';
import { ControllerParam } from 'interfaces';
import * as service from 'services/report-template-entry.service';
import { changeBlankToNull, removeBlankProperty } from 'utils';

const entity_name = 'Report Template Entry';

export const getByTemplateId = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await service.getEntriesByReportTemplateId(parseInt(req.params.id), req.query);
    if (!result) res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await service.getOne(parseInt(req.params.id));
    if (!result) res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createReportTemplateEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.createReportTemplateEntry(payload));
  } catch (err) {
    next(err);
  }
};

export const updateReportTemplateEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const payload = removeBlankProperty(matchedData(req));
    const result = await service.updateReportTemplateEntry(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteReportTemplateEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await service.deleteReportTemplateEntry(parseInt(req.params.id));
    if (!result) res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};
