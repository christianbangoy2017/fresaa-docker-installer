import * as service from 'services/region.service';

import { ControllerParam } from 'interfaces';

export const uploadLogo = async ({ req, res, next }: ControllerParam) => {
  try {
    const logos = req.body;
    res.json(await service.uploadLogo(parseInt(req.params.id), logos));
  } catch (err: any) {
    res.status(400).send({ message: err.message });
  }
};
