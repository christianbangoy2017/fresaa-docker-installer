import * as service from 'services/user-auth.service';

import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { UserInput } from 'models/User';
import { getTokenFromHeaders } from 'middlewares/token-guard';

export const refreshToken = async ({ req, res, next }: ControllerParam) => {
  const { refresh_token } = req.body;

  if (refresh_token == null) {
    return res.status(400).json({ message: 'Refresh Token is required!' });
  }

  try {
    res.json(await service.refreshToken(refresh_token));
  } catch (err: any) {
    res.status(403).send({ message: err.message });
  }
};

export const login = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(401).json(errors.array()[0]);

    const payload = matchedData(req) as UserInput;
    const data = await service.login(payload);
    if (data?.error) return res.status(401).json({ msg: data.error });

    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const logout = async ({ req, res, next }: ControllerParam) => {
  const { refresh_token } = req.body;
  const token = getTokenFromHeaders(req.headers);

  try {
    res.json(await service.logout(token, res));
  } catch (err) {
    next(err);
  }
};
