import * as service from 'services/widget-group.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Widget Group';

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_DASHBOARD'], res);
    const indicator_id = parseInt(req.params.indicator_id);
    const result = await service.getList(indicator_id);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_DASHBOARD'], res);

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.create(payload, token));
  } catch (err) {
    next(err);
  }
};

export const reorder = async ({ req, res, next }: ControllerParam) => {
  try {
    const indicator_id = parseInt(req.params.indicator_id);
    res.json(await service.reorder(indicator_id, req.body));
  } catch (err) {
    next(err);
  }
};

export const reorderWidgets = async ({ req, res, next }: ControllerParam) => {
  try {
    const id = parseInt(req.params.id);
    res.json(await service.reorderWidgets(id, JSON.stringify(req.body)));
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await service.deleteItem(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};
