import * as service from 'services/assessment-indicator.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Assessment Indicator';
const section0 = require('../../sequelize/fresaa-files/CARAGA/sections/section_0');

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES', 'VIEW_FRESAA_BATCHES', 'MANAGE_REPORTS'], res);

    const result = await service.get(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES', 'VIEW_FRESAA_BATCHES', 'MANAGE_REPORTS'], res);

    const result = await service.getList(req.query, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    let payload: any;
    if (req.params.id) {
      // DUPLICATE
      payload = await service.get(parseInt(req.params.id), true);
      delete payload.id;
      payload.name = payload.name + ' - Copy';
    } else {
      // CREATE
      const indicator = JSON.stringify([section0]);

      payload = changeBlankToNull(matchedData(req));
      payload.indicators = indicator;
    }

    const current_user = await getUserByToken(token);
    payload.updated_by = current_user.id;
    res.json(await service.create(payload));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const payload = removeBlankProperty(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.updated_by = current_user.id;
    const result = await service.update(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const edit = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const name = req.body.name;
    const current_user = await getUserByToken(token);
    const payload = {
      updated_by: current_user.id,
      name: name,
      validation_workflow_id: req.body.validation_workflow_id,
    };
    const result = await service.edit(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const current_user = await getUserByToken(token);
    await checkUserAuthority(token, ['MANAGE_FRESAA_BATCHES'], res);

    const result = await service.deleteItem(parseInt(req.params.id), current_user);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};
