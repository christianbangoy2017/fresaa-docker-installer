import * as service from 'services/facility-report-entry-comment.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Facility Report Entry Comment';

export const getCommentsByReportId = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      ['MANAGE_FACILITIES', 'MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'],
      res
    );

    const result = await service.getCommentsByFacilityReportEntryId(parseInt(req.params.id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const create = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'], res);

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.create(token, payload));
  } catch (err) {
    next(err);
  }
};

// delete facility report entries
export const deleteComment = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'], res);

    const result = await service.deleteComment(parseInt(req.params.id), token);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const updateComment = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'], res);

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.updateComment(parseInt(req.params.id), token, payload.comment));
  } catch (err) {
    next(err);
  }
};

export const updateStatus = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'], res);
    res.json(await service.updateStatus(parseInt(req.params.id), token, req.params.status));
  } catch (err) {
    next(err);
  }
};

export const resolveAllStatus = async ({req, res, next}: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FACILITY'], res);

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.updateAllStatus(payload.facility_report_entry_id, payload.field_code, token));
  } catch (err) {
    next(err);
  }
};