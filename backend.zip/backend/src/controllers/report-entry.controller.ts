import * as freservice from 'services/facility-report-entry.service';
import * as service from 'services/report-entry.service';

import { changeBlankToNull, checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Report Entry';

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'VIEW_FRESAA_BATCHES'], res);

    const result = await service.getReportEntriesByReportId(parseInt(req.params.id), req.query);
    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAllReportEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MANAGE_REPORTS',
        'VIEW_FRESAA_BATCHES',
        'REVIEW_FRESAA_QUESTIONNAIRE',
        'VIEW_REGIONAL_DASHBOARD',
        'VIEW_PROVINCIAL_DASHBOARD',
        'VIEW_NATIONAL_DASHBOARD',
        'VIEW_MUNICIPAL_DASHBOARD',
      ],
      res
    );

    const result = await service.getAllReportEntries(req.query, token);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getActiveReportEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'VIEW_FRESAA_BATCHES', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.getActiveReportEntries(req.query, token);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getSummary = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'VIEW_FRESAA_BATCHES', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.getSummary(parseInt(req.params.id));
    if (!result) res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.create(payload));
  } catch (err) {
    next(err);
  }
};

export const createBulk = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const payload = changeBlankToNull(matchedData(req));
    const createdReportEntry = await service.create(payload);
    const facilityIds = await freservice.getAvailableFacilityIDs(createdReportEntry.id, token);

    // get all available facilities and add report entries
    await freservice.createBulkEntry(createdReportEntry.id, facilityIds);
    res.json(createdReportEntry);
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const payload = removeBlankProperty(matchedData(req));
    const result = await service.update(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const updateStatus = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const result = await service.update(parseInt(req.params.id), { status: req.params.status });
    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const result = await service.deleteItem(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const duplicate = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const payload = changeBlankToNull(matchedData(req));
    const { id, report_id, deadline, month } = payload;
    const result = await service.duplicateItem({ id, report_id, deadline, month, status: 'open' });

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};
