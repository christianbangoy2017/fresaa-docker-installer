import * as service from 'services/assessment.service';

import { changeBlankToNull, checkUserAuthority } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Facility Assessment';

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MONITOR_REGIONAL_FRESAA_QUESTIONNAIRE',
        'MONITOR_PROVINCIAL_FRESAA_QUESTIONNAIRE',
        'REVIEW_FRESAA_QUESTIONNAIRE',
        'ANSWER_FRESAA_QUESTIONNAIRE',
        'MANAGE_FACILITY',
        'VIEW_REGIONAL_DASHBOARD',
        'VIEW_PROVINCIAL_DASHBOARD',
        'VIEW_NATIONAL_DASHBOARD',
        'VIEW_MUNICIPAL_DASHBOARD',
      ],
      res
    );

    const result = await service.get(parseInt(req.params.id), token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MONITOR_REGIONAL_FRESAA_QUESTIONNAIRE',
        'MONITOR_PROVINCIAL_FRESAA_QUESTIONNAIRE',
        'ANSWER_FRESAA_QUESTIONNAIRE',
        'REVIEW_FRESAA_QUESTIONNAIRE',
        'VIEW_REGIONAL_DASHBOARD',
        'VIEW_PROVINCIAL_DASHBOARD',
        'VIEW_NATIONAL_DASHBOARD',
        'VIEW_MUNICIPAL_DASHBOARD',
      ],
      res
    );

    const batch_id = req.params.batch_id ? parseInt(req.params.batch_id) : undefined;
    res.json(await service.getList(req.query, token, batch_id));
  } catch (err) {
    next(err);
  }
};

export const getApprovedAssessments = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MONITOR_REGIONAL_FRESAA_QUESTIONNAIRE',
        'MONITOR_PROVINCIAL_FRESAA_QUESTIONNAIRE',
        'ANSWER_FRESAA_QUESTIONNAIRE',
        'REVIEW_FRESAA_QUESTIONNAIRE',
        'VIEW_REGIONAL_DASHBOARD',
        'VIEW_PROVINCIAL_DASHBOARD',
        'VIEW_NATIONAL_DASHBOARD',
        'VIEW_MUNICIPAL_DASHBOARD',
      ],
      res
    );

    const batch_id = req.params.batch_id ? parseInt(req.params.batch_id) : undefined;

    res.json(await service.getAllApproved(batch_id));
  } catch (err) {
    next(err);
  }
};

export const getActive = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      [
        'MONITOR_REGIONAL_FRESAA_QUESTIONNAIRE',
        'MONITOR_PROVINCIAL_FRESAA_QUESTIONNAIRE',
        'ANSWER_FRESAA_QUESTIONNAIRE',
        'REVIEW_FRESAA_QUESTIONNAIRE',
      ],
      res
    );
    const [active_batch, getAssessments]: any = await service.getActiveList(req.query, token);
    if (active_batch) {
      const data = await getAssessments;
      res.json({ ...data, active_batch });
      return;
    }

    res.json({ count: 0, rows: [] });
  } catch (err) {
    next(err);
  }
};

export const getAllByStatus = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const verified_auths = await checkUserAuthority(
      token,
      ['ANSWER_FRESAA_QUESTIONNAIRE', 'REVIEW_FRESAA_QUESTIONNAIRE', 'MANAGE_FRESAA_QUESTIONNAIRE'],
      res
    );

    let started: number = 0;
    let submitted: number = 0;
    let ongoing_approval: number = 0;
    let completed: number = 0;

    started = await service.getActiveFromStatus(token, 'started', req.query);
    submitted = await service.getActiveFromStatus(token, 'submitted', req.query);
    ongoing_approval = await service.getActiveFromStatus(token, 'ongoing-approval', req.query);
    completed = await service.getActiveFromStatus(token, 'completed', req.query);

    res.json({ started, submitted, ongoing_approval, completed });
  } catch (err) {
    console.log(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['CREATE_DELETE_REGIONAL_FRESAA_QUESTIONNAIRE'], res);

    const batch_id = parseInt(req.params.batch_id);
    const payload = changeBlankToNull(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.created_by = current_user.id;
    res.json(await service.create(payload, batch_id, token, res));
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const current_user = await getUserByToken(token);
    await checkUserAuthority(token, ['CREATE_DELETE_REGIONAL_FRESAA_QUESTIONNAIRE'], res);
    const update = await service.updateDeletedBy(parseInt(req.params.id), current_user.id);

    const deleteResult = await service.deleteItem(parseInt(req.params.id), token);

    if (!update || !deleteResult) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const removeFacilityFromGroup = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES'], res);

    res.json(await service.removeFacilityFromGroup(req.body, token));
  } catch (err) {
    next(err);
  }
};

export const updateAssessor = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FRESAA_QUESTIONNAIRE'], res);

    const id = parseInt(req.params.id);
    const user_id = parseInt(req.params.user_id);
    const result = await service.updateAssessor(id, user_id);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const startAssessment = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['ANSWER_FRESAA_QUESTIONNAIRE'], res);

    const id = parseInt(req.params.id);
    const result = await service.startAssessment(id, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const submitAssessment = async ({ req, res, next }: ControllerParam, draft?: boolean) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['ANSWER_FRESAA_QUESTIONNAIRE'], res);

    const id = parseInt(req.params.id);
    const payload = changeBlankToNull(matchedData(req));
    let result = draft
      ? await service.saveDraftAssessment(id, payload, token)
      : await service.submitAssessment(id, payload, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const approveAssessment = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const id = parseInt(req.params.id);
    const result = await service.approveAssessment(id, token, res);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const batchApproveAssessments = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const ids: any = req.body.ids;
    ids.forEach(async (id: number) => {
      const result = await service.approveAssessment(id, token, res);

      if (!result) {
        res.status(404).json({ message: `Assessment not found.` });
      }
    });

    res.json({ message: 'Selected Assessments approved' });
  } catch (err) {
    next(err);
  }
};

export const returnAssessment = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);
    const id = parseInt(req.params.id);

    const result = await service.returnAssessment(token, id, req.body);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getAllByFacilityId = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const result = await service.getAllByFacilityId(token, req.query);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};
