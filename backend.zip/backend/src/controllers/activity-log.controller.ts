import * as service from 'services/activity-log.service';

import { ControllerParam } from 'interfaces';
import { checkUserAuthority } from 'utils';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Facility';

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES'], res);

    const result = await service.get(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['VIEW_ACTIVITY_LOG'], res);

    const result = await service.getList(req.query, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};
