import * as service from 'services/facility-group.service';

import { checkUserAuthority, removeBlankProperty } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';
import { getUserByToken } from 'services/user.service';

const entity_name = 'Facility Group';

export const getOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const result = await service.get(parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getListAssessor = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const result = await service.getListAssessor(token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getMultiple = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const result = await service.getList(req.query, token);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const createOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const payload = removeBlankProperty(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.created_by = current_user.id;
    const result = await service.create(payload, token);

    res.json({ result, message: 'added group' });
  } catch (err) {
    next(err);
  }
};

export const updateOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const payload = removeBlankProperty(matchedData(req));
    const current_user = await getUserByToken(token);
    payload.updated_by = current_user.id;
    const result = await service.update(parseInt(req.params.id), payload);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const deleteOne = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);
    const current_user = await getUserByToken(token);
    const result = await service.deleteItem(parseInt(req.params.id), current_user);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const deleteGroupWithAllAssigned = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const current_user = await getUserByToken(token);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const update = await service.updateDeletedBy(parseInt(req.params.id), current_user.id);
    const result = await service.deleteGroupWithFacilityAssigned(parseInt(req.params.id), current_user.id);

    if (!update || !result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

export const getFacilitesInGroup = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY_GROUP'], res);

    const result = await service.getFacilitesInGroup(req.query, token, parseInt(req.params.id));

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }

    res.json(result);
  } catch (err) {
    next(err);
  }
};
