import * as service from 'services/mobile-link.service';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Mobile Link';

export const get = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    const result = await service.getLinkAvailable(token);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};
