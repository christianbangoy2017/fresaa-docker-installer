import * as service from 'services/facility-report-entry.service';

import { changeBlankToNull, checkUserAuthority, useridByToken } from 'utils';
import { matchedData, validationResult } from 'express-validator';

import { ControllerParam } from 'interfaces';
import { getTokenFromHeaders } from 'middlewares/token-guard';

const entity_name = 'Facility Report Entry';

export const get = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITIES', 'MANAGE_FACILITY', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.get(parseInt(req.params.id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// gets a facility report entry by id
export const getMany = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(
      token,
      ['MANAGE_REPORTS', 'MANAGE_FACILITY', 'MANAGE_FACILITIES', 'REVIEW_FRESAA_QUESTIONNAIRE'],
      res
    );

    const result = await service.getReportEntryById(req.query, token, parseInt(req.params.id), req.params.id_source);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getByFacilityId = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY', 'MANAGE_FACILITIES', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.getReportEntryByFacilityId(parseInt(req.params.facility_id), req.query, token, res);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// gets all the facilities that has no report entries yet
export const getAvailableFacilities = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const result = await service.getAvailableFacilities(parseInt(req.params.report_entry_id), req.query, token);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// creates multiple facility report entry
export const createReportFacilityEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const payload = changeBlankToNull(matchedData(req));
    res.json(await service.createBulkEntry(parseInt(req.params.report_entry_id), payload['facilities']));
  } catch (err) {
    next(err);
  }
};

// creates facility report entry for all available
export const createAllAvailable = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);
    res.json(await service.createEntryForAllNotIncluded(parseInt(req.params.report_entry_id), token));
  } catch (err) {
    next(err);
  }
};

// marks the facility report entry as submitted
export const submitFacilityReportEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY'], res);

    const userid = (await useridByToken(token)) as number;
    const payload = changeBlankToNull(matchedData(req));
    const marked = await service.markAsSubmitted(parseInt(req.params.id), userid, payload.responses);

    if (marked.length > 0) return res.json(await service.get(parseInt(req.params.id)));
    return null;
  } catch (err) {
    next(err);
  }
};

// approve the facility report entry
export const approveFacilityReportEntry = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);
    const approved = await service.approve(parseInt(req.params.id), token, res);

    return res.json(await service.get(parseInt(req.params.id)));
  } catch (err) {
    next(err);
  }
};

// batch approve facilty report entries
export const batchApproveFacilityReportEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const ids: any = req.body.ids;
    ids.forEach(async (id: number) => {
      const result = await service.approve(id, token, res);

      if (!result) {
        res.status(404).json({ message: `Facility Report Entry not found.` });
      }
    });

    res.json({ message: 'Facility Report Entries approved' });
  } catch (err) {
    next(err);
  }
};

export const getApprovedReportFacilityEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.getApprovedReportFacilityEntries(req.query);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getActiveReportEntryFacilityEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'VIEW_FRESAA_BATCHES', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const result = await service.getActiveReportEntryFacilityEntries(req.query, token);
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

// delete facility report entries using ID
export const deleteReportFacilityEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const payload = changeBlankToNull(matchedData(req));
    const result = await service.deleteFacilityReportEntries(payload.facilities);

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json({ message: `${entity_name} deleted.` });
  } catch (err) {
    next(err);
  }
};

// delete all the facility report entries using report entry ID
export const deleteAllFacilityReportEntries = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS'], res);

    const result = await service.deleteAllFacilityReportEntries(parseInt(req.params.report_entry_id));
    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json({ message: `All Facility Report Entries deleted.` });
  } catch (err) {
    next(err);
  }
};

// delete facility report entries
export const updateFacilityResponses = async ({ req, res, next }: ControllerParam) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json(errors.mapped());

    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_FACILITY', 'MANAGE_REPORTS'], res);

    const payload = changeBlankToNull(matchedData(req));
    const result = await service.updateFaciltyReportEntryResponse(parseInt(req.params.id), payload.responses);

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });
    res.json({ message: 'Responses added' });
  } catch (err) {
    next(err);
  }
};

export const getReportEntryIndicators = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'VIEW_FRESAA_BATCHES', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const { report_entry_id, facility_report_entry_id } = req.params;
    const result = await service.getReportEntryIndicators(
      token,
      parseInt(report_entry_id),
      parseInt(facility_report_entry_id)
    );

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const getDashboardData = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['MANAGE_REPORTS', 'VIEW_FRESAA_BATCHES', 'REVIEW_FRESAA_QUESTIONNAIRE'], res);

    const { report_entry_id } = req.params;
    const result = await service.getReportEntryIndicators(token, parseInt(report_entry_id), 0, true);

    if (!result) return res.status(404).json({ message: `${entity_name} not found.` });

    res.json(result);
  } catch (err) {
    next(err);
  }
};

export const returnReport = async ({ req, res, next }: ControllerParam) => {
  try {
    const token = getTokenFromHeaders(req.headers);
    await checkUserAuthority(token, ['REVIEW_FRESAA_QUESTIONNAIRE'], res);
    const id = parseInt(req.params.id);

    const result = await service.returnReport(token, id, req.body);

    if (!result) {
      res.status(404).json({ message: `${entity_name} not found.` });
    }
    res.json(result);
  } catch (err) {
    next(err);
  }
};
