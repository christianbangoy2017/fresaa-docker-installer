import express, { NextFunction, Request, Response } from 'express';

import { ValidationError } from 'sequelize';
import activityLogRouter from 'routes/activity-log.route';
import assessmentBatchFacilityRouter from 'routes/assessment-batch-facilities.route';
import assessmentBatchFormRouter from 'routes/assessment-batch-form.route';
import assessmentBatchRouter from 'routes/assessment-batch.route';
import assessmentCommentRouter from 'routes/assessment-comment.route';
import assessmentIndicatorRouter from 'routes/assessment-indicator.route';
import assessmentRouter from 'routes/assessment.route';
import dbInit from 'db/init';
import facilityGroupIndicatorAssessor from 'routes/facility-group-indicator-assessor.route';
import facilityGroupRouter from 'routes/facility-group.route';
import facilityReportEntryComment from 'routes/facility-report-entry-comment.route';
import facilityReportEntryRouter from 'routes/facility-report-entry.route';
import facilityRouter from 'routes/facility.route';
import formValidationWorkflowRouter from 'routes/form-validation-workflow.route';
import mobileLinkRouter from 'routes/mobile-link.route';
import regionRouter from 'routes/region.route';
import reportEntryRouter from 'routes/report-entry.route';
import reportRouter from 'routes/report.route';
import reportTemplateEntryRouter from 'routes/report-template-entry.route';
import reportTemplateRouter from 'routes/report-template-route';
import { tokenGuard } from 'middlewares/token-guard';
import { securityRequest, acceptableCorsHeaders } from 'middlewares/security-header';
import userAuthRouter from 'routes/user-auth.route';
import userGroupRouter from 'routes/user-group.route';
import userGroupValidatorRouter from 'routes/user-group-validator.route';
import userRouter from 'routes/user.route';
import widgetGroupRouter from 'routes/widget-group.route';
import widgetRouter from 'routes/widget.route';

const cors = require('cors');
const app = express();
const port = 3001;


// Body parsing Middleware
app.disable('x-powered-by');
app.use(cors({
  origin: acceptableCorsHeaders
}));

var bodyParser = require('body-parser');
app.use(bodyParser.json({ limit: '50mb' }));
app.use(
  bodyParser.urlencoded({
    limit: '50mb',
    extended: true,
    parameterLimit: 1000000,
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', async (req, res) => {
  return res.status(200).send({
    message: `Welcome to the FRESAA API! \n Endpoints available at http://localhost:${port}/api/v1`,
  });
});

dbInit();

// Unprotected routes
app.use(securityRequest());
app.use('/auth', userAuthRouter);

// Prtotected routes
app.use(tokenGuard());
app.use('/user', userRouter);
app.use('/region', regionRouter);
app.use('/facility', facilityRouter);
app.use('/facility-group', facilityGroupRouter);
app.use('/assessment', assessmentRouter);
app.use('/assessment-batch-facility', assessmentBatchFacilityRouter);
app.use('/assessment-batch', assessmentBatchRouter);
app.use('/assessment-batch-form', assessmentBatchFormRouter);
app.use('/assessment-comment', assessmentCommentRouter);
app.use('/assessment-indicator', assessmentIndicatorRouter);
app.use('/activity-log', activityLogRouter);
app.use('/widget', widgetRouter);
app.use('/widget-group', widgetGroupRouter);
app.use('/report', reportRouter);
app.use('/report-template', reportTemplateRouter);
app.use('/report-template-entry', reportTemplateEntryRouter);
app.use('/report-entry', reportEntryRouter);
app.use('/facility-report-entry', facilityReportEntryRouter);
app.use('/facility-report-entry-comment', facilityReportEntryComment);
app.use('/form-validation-workflow', formValidationWorkflowRouter);
app.use('/user-group-validator', userGroupValidatorRouter);
app.use('/user-group', userGroupRouter);
app.use('/mobile-link', mobileLinkRouter);
app.use('/group-indicator-assessor', facilityGroupIndicatorAssessor);

// Global error-handling middleware
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Server Error:', err.message); // Log error message only

  if (err instanceof ValidationError) {
    return res.status(400).json({
      success: false,
      message: 'Error. Please try again later.',
    });
  }

  res.status(400).json({
    success: false,
    message: 'Error. Please try again later.',
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
