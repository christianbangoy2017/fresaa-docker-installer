import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface AssessmentResponseAttributes {
  id: number;
  facility_id: number;
  assessment_id: number;
  region_code: string;
  province_code: string;
  municipality_code: string;
  batch_id: number;
  parent_name: string;
  item_name: string;
  item_code: string;
  item_response: string;
  item_notes: string;
  item_notes_resolve: boolean;
  created_by: number;
  updated_by: number;
  deleted_by: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface AssessmentResponseInput extends Optional<AssessmentResponseAttributes, 'id'> {}
export interface AssessmentResponseOuput extends Required<AssessmentResponseAttributes> {}

class AssessmentResponse
  extends Model<AssessmentResponseAttributes, AssessmentResponseInput>
  implements AssessmentResponseAttributes
{
  public id!: number;
  public facility_id!: number;
  public assessment_id!: number;
  public region_code!: string;
  public province_code!: string;
  public municipality_code!: string;
  public batch_id!: number;
  public parent_name!: string;
  public item_name!: string;
  public item_code!: string;
  public item_response!: string;
  public item_notes!: string;
  public item_notes_resolve!: boolean;
  public created_by!: number;
  public updated_by!: number;
  public deleted_by!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

AssessmentResponse.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    facility_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facilities', key: 'id' },
    },
    assessment_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facility_assessments', key: 'id' },
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    province_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_provinces', key: 'province_code' },
    },
    municipality_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: {
        model: 'location_municipalities',
        key: 'municipality_code',
      },
    },
    batch_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'assessment_batches', key: 'id' },
    },
    parent_name: {
      type: DataTypes.STRING,
    },
    item_name: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    item_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    item_response: {
      type: DataTypes.TEXT,
    },
    item_notes: {
      type: DataTypes.TEXT,
    },
    item_notes_resolve: {
      type: DataTypes.BOOLEAN,
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    deleted_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'assessment_responses',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default AssessmentResponse;
