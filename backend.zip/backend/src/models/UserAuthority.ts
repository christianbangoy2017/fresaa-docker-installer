import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface UserAuthorityAttributes {
  id: number;
  authority: string;
  description: string;
}
export interface UserAuthorityInput extends Optional<UserAuthorityAttributes, 'id'> {}
export interface UserAuthorityOuput extends Required<UserAuthorityAttributes> {}

class UserAuthority extends Model<UserAuthorityAttributes, UserAuthorityInput> implements UserAuthorityAttributes {
  public id!: number;
  public authority!: string;
  public description!: string;
}

UserAuthority.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    authority: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    description: {
      type: DataTypes.STRING,
    },
  },
  {
    tableName: 'user_authorities',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default UserAuthority;
