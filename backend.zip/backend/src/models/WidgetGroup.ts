import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

export interface WidgetGroupAttributes {
  id: number;
  indicator_id: number;
  column_type: string;
  order: number;
  layout: string;
}

export interface WidgetGroupInput extends Optional<WidgetGroupAttributes, 'id'> {}
export interface WidgetGroupOutput extends Required<WidgetGroupAttributes> {}
class WidgetGroup extends Model<WidgetGroupAttributes, WidgetGroupInput> implements WidgetGroupAttributes {
  public id!: number;
  public indicator_id!: number;
  public column_type!: string;
  public order!: number;
  public layout!: string;
}

WidgetGroup.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    indicator_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'assessment_indicators', key: 'id' },
      allowNull: false,
    },
    column_type: {
      type: DataTypes.ENUM('3-3-3-3', '4-4-4', '6-6', '8-4', '4-8'),
      allowNull: false,
    },
    order: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
    },
    layout: {
      type: DataTypes.TEXT('long'),
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'widget_groups',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default WidgetGroup;
