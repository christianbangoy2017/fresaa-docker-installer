import { DataTypes, Model, Optional } from 'sequelize';

import User from './User';
import sequelizeConnection from 'db/config';

interface FormValidationWorkflowAttributes {
  id: number;
  name: string;
  process: string;
  steps: string;
  region_code: string;
}
export interface FormValidationWorkflowInput extends Optional<FormValidationWorkflowAttributes, 'id'> {}
export interface FormValidationWorkflowOuput extends Required<FormValidationWorkflowAttributes> {}

class FormValidationWorkflow
  extends Model<FormValidationWorkflowAttributes, FormValidationWorkflowInput>
  implements FormValidationWorkflowAttributes
{
  public id!: number;
  public name!: string;
  public process!: string;
  public steps!: string;
  public region_code!: string;
}

FormValidationWorkflow.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
    },
    process: {
      type: DataTypes.TEXT('long'),
    },
    steps: {
      type: DataTypes.TEXT('long'),
    },
    region_code: {
      type: DataTypes.STRING,
      references: { model: 'location_regions', key: 'region_code' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    tableName: 'form_validation_workflow',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default FormValidationWorkflow;
