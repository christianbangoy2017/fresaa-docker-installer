import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface FacilityReportEntryAttributes {
  id?: number;
  report_id: number;
  report_entry_id: number;
  facility_id: number;
  responses: string;
  status: string;
  started_at?: Date;
  submitted_at?: Date;
  approved_at?: Date;
  assessor_id?: number;
  approver_id?: number;
  created_at?: Date;
  updated_at?: Date;
  current_step?: string;
}
export interface FacilityReportEntryInput extends Optional<FacilityReportEntryAttributes, 'id'> {}
export interface FacilityReportEntryOuput extends Required<FacilityReportEntryAttributes> {}

class FacilityReportEntry
  extends Model<FacilityReportEntryAttributes, FacilityReportEntryInput>
  implements FacilityReportEntryAttributes
{
  public id!: number;
  public report_id!: number;
  public report_entry_id!: number;
  public facility_id!: number;
  public responses!: string;
  public status!: string;
  public started_at!: Date;
  public submitted_at!: Date;
  public approved_at!: Date;
  public assessor_id!: number;
  public approver_id!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public current_step!: string;
}

FacilityReportEntry.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    report_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'reports', key: 'id' },
    },
    report_entry_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'report_entries', key: 'id' },
    },
    facility_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facilities', key: 'id' },
    },
    responses: {
      type: DataTypes.TEXT('long'),
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM,
      values: ['open', 'started', 'submitted', 'approved', 'ongoing-approval', 'completed'],
      defaultValue: 'open',
    },
    started_at: {
      type: DataTypes.DATE,
    },
    submitted_at: {
      type: DataTypes.DATE,
    },
    approved_at: {
      type: DataTypes.DATE,
    },
    assessor_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    approver_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    current_step: {
      type: DataTypes.STRING,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'facility_report_entries',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default FacilityReportEntry;
