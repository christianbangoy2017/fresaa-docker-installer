import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface ReportAttributes {
  id: number;
  name: string;
  indicator_id: number;
  frequency: string;
  region_code: string;
  dashboard_code: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface ReportInput extends Optional<ReportAttributes, 'id'> {}
export interface ReportOuput extends Required<ReportAttributes> {}

class Report extends Model<ReportAttributes, ReportInput> implements ReportAttributes {
  public id!: number;
  public name!: string;
  public indicator_id!: number;
  public frequency!: string;
  public region_code!: string;
  public dashboard_code!: string;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

Report.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      allowNull: false,
      type: DataTypes.STRING,
    },
    indicator_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'assessment_indicators', key: 'id' },
    },
    frequency: {
      type: DataTypes.ENUM,
      values: ['monthly', 'quarterly', 'yearly'],
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    dashboard_code: {
      type: DataTypes.STRING,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'reports',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default Report;
