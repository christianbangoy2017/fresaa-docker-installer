import { DataTypes, Model, Optional } from 'sequelize';

import User from './User';
import sequelizeConnection from 'db/config';

interface HealthProgramAttributes {
  id: number;
  program_name: string;
}

export interface HealthProgramInput extends Optional<HealthProgramAttributes, 'id'> {}
export interface HealthProgramOutput extends Required<HealthProgramAttributes> {}

// NOT USED
class HealthProgram extends Model<HealthProgramAttributes, HealthProgramInput> implements HealthProgramAttributes {
  public id!: number;
  public program_name!: string;
}

HealthProgram.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    program_name: {
      allowNull: false,
      type: DataTypes.STRING,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    tableName: 'health_programs',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default HealthProgram;
