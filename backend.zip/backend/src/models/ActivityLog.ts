import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface ActivityLogAttributes {
  id: number;
  user_id: number;
  activity: string;
  model: string;
  model_id: number;
  created_at?: Date;
  updated_at?: Date;
}
export interface ActivityLogInput extends Optional<ActivityLogAttributes, 'id'> {}
export interface ActivityLogOuput extends Required<ActivityLogAttributes> {}

class ActivityLog extends Model<ActivityLogAttributes, ActivityLogInput> implements ActivityLogAttributes {
  public id!: number;
  public user_id!: number;
  public activity!: string;
  public model!: string;
  public model_id!: number;
  public created_at!: Date;
  public updated_at!: Date;
}

ActivityLog.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      allowNull: false,
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    activity: {
      type: DataTypes.STRING(1000),
      allowNull: false,
    },
    model: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    model_id: {
      type: DataTypes.INTEGER.UNSIGNED,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    tableName: 'activity_logs',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default ActivityLog;
