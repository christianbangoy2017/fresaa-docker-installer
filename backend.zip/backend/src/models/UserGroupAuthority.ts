import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface UserGroupAuthorityAttributes {
  user_group_id: number;
  user_authority_id: number;
}
export interface UserGroupAuthorityOuput extends Required<UserGroupAuthorityAttributes> {}

class UserGroupAuthority extends Model<UserGroupAuthorityAttributes> implements UserGroupAuthorityAttributes {
  public user_group_id!: number;
  public user_authority_id!: number;
}

UserGroupAuthority.init(
  {
    user_group_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'user_groups', key: 'id' },
    },
    user_authority_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'user_authorities', key: 'id' },
    },
  },
  {
    tableName: 'user_group_authorities',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default UserGroupAuthority;
