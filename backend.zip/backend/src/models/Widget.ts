import { DataTypes, Model, Optional } from 'sequelize';

import AssessmentBatch from './AssessmentBatch';
import WidgetGroup from './WidgetGroup';
import sequelizeConnection from 'db/config';

export interface WidgetAttributes {
  id: number;
  group_id: number;
  type: string;
  title: number;
  configuration: string;
}
export interface WidgetInput extends Optional<WidgetAttributes, 'id'> {}
export interface WidgetOutput extends Required<WidgetAttributes> {}

class Widget extends Model<WidgetAttributes, WidgetInput> implements WidgetAttributes {
  public id!: number;
  public group_id!: number;
  public type!: string;
  public title!: number;
  public configuration!: string;
}

Widget.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },
    group_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: {
        model: 'widget_groups',
        key: 'id',
      },
    },
    type: {
      type: DataTypes.ENUM('line', 'pie', 'bar', 'scorecard'),
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    configuration: {
      type: DataTypes.TEXT('long'),
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'widgets',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default Widget;
