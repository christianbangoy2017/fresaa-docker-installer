import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface FacilityGroupIndicatorAssessorAttributes {
  id: number;
  region_code: string;
  group_id: number;
  indicator_id: number;
  assessor_id: number;
}

export interface FacilityGroupIndicatorAssessorInput extends Optional<FacilityGroupIndicatorAssessorAttributes, 'id'> {}
export interface FacilityGroupIndicatorOutput extends Required<FacilityGroupIndicatorAssessorAttributes> {}

class FacilityGroupIndicatorAssessor
  extends Model<FacilityGroupIndicatorAssessorAttributes, FacilityGroupIndicatorAssessorInput>
  implements FacilityGroupIndicatorAssessorAttributes
{
  public id!: number;
  public region_code!: string;
  public group_id!: number;
  public indicator_id!: number;
  public assessor_id!: number;
}

FacilityGroupIndicatorAssessor.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    region_code: {
      type: DataTypes.STRING,
    },
    group_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: {
        model: 'facility_groups',
        key: 'id',
      },
    },
    indicator_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: {
        model: 'assessment_indicators',
        key: 'id',
      },
    },
    assessor_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: {
        model: 'users',
        key: 'id',
      },
    },
  },
  {
    sequelize: sequelizeConnection,
    tableName: 'facility_group_indicator_assessors',
  }
);

export default FacilityGroupIndicatorAssessor;
