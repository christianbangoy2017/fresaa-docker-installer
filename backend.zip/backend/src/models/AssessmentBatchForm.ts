import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface AssessmentBatchFormAttributes {
  id: number;
  batch_id: number;
  indicator_id: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface AssessmentBatchFormInput extends Optional<AssessmentBatchFormAttributes, 'id'> {}
export interface AssessmentBatchFormOuput extends Required<AssessmentBatchFormAttributes> {}

class AssessmentBatchForm
  extends Model<AssessmentBatchFormAttributes, AssessmentBatchFormInput>
  implements AssessmentBatchFormAttributes
{
  public id!: number;
  public batch_id!: number;
  public indicator_id!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

AssessmentBatchForm.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    batch_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'assessment_batches', key: 'id' },
    },
    indicator_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'assessment_indicators', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'assessment_batch_forms',
    timestamps: true,
    sequelize: sequelizeConnection,
  }
);

export default AssessmentBatchForm;
