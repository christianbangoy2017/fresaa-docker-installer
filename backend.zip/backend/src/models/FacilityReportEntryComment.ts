import { DataTypes, Model, Optional } from 'sequelize';

import FacilityReportEntry from './FacilityReportEntry';
import User from './User';
import sequelizeConnection from 'db/config';

interface FacilityReportEntryCommentAttributes {
  id: number;
  facility_report_entry_id: number;
  user_id: number;
  status: string;
  field_code: string;
  field_name: string;
  comment: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}

export interface FacilityReportEntryCommentInput extends Optional<FacilityReportEntryCommentAttributes, 'id'> {}
export interface FacilityReportEntryCommentOutput extends Required<FacilityReportEntryCommentAttributes> {}

class FacilityReportEntryComment
  extends Model<FacilityReportEntryCommentAttributes, FacilityReportEntryCommentInput>
  implements FacilityReportEntryCommentAttributes
{
  public id!: number;
  public facility_report_entry_id!: number;
  public user_id!: number;
  public status!: string;
  public field_code!: string;
  public field_name!: string;
  public comment!: string;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

FacilityReportEntryComment.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    facility_report_entry_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facility_report_entries', key: 'id' },
    },
    user_id: {
      allowNull: false,
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    status: {
      type: DataTypes.ENUM,
      values: ['open', 'resolved'],
      defaultValue: 'open',
      allowNull: false,
    },
    field_code: {
      type: DataTypes.STRING,
    },
    field_name: {
      type: DataTypes.TEXT,
    },
    comment: {
      type: DataTypes.TEXT('long'),
      allowNull: false,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'facility_report_entry_comments',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default FacilityReportEntryComment;
