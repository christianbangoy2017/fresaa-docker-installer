import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface LocationMunicipalityAttributes {
  municipality_code: string;
  municipality_name: string;
  region_code: string;
  province_code: string;
}

export interface LocationMunicipalityInput extends Optional<LocationMunicipalityAttributes, 'municipality_code'> {}
export interface LocationMunicipalityOuput extends Required<LocationMunicipalityAttributes> {}

class LocationMunicipality
  extends Model<LocationMunicipalityAttributes, LocationMunicipalityInput>
  implements LocationMunicipalityAttributes
{
  public municipality_code!: string;
  public municipality_name!: string;
  public region_code!: string;
  public province_code!: string;
}

LocationMunicipality.init(
  {
    municipality_code: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    municipality_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    province_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_provinces', key: 'province_code' },
    },
  },
  {
    tableName: 'location_municipalities',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default LocationMunicipality;
