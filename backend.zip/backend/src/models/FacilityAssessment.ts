import { DataTypes, Model, Optional } from 'sequelize';

import Facility from './Facility';
import sequelizeConnection from 'db/config';

interface FacilityAssessmentAttributes {
  id: number;
  facility_id: number;
  batch_id: number;
  indicator_id: number;
  assessor_id: number;
  reviewer_id: number;
  approver_id: number;
  dmo_approver_id: number;
  status: string;
  validator_signature: string;
  mho_notes: string;
  pho_notes: string;
  dmo_notes: string;
  respondents: string;
  responses: string;
  draft_responses: string;
  started_at?: Date;
  submitted_at?: Date;
  reviewed_at?: Date;
  approved_at?: Date;
  created_by: number;
  updated_by: number;
  deleted_by: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
  facility?: Facility;
  current_step?: string;
}
export interface FacilityAssessmentInput extends Optional<FacilityAssessmentAttributes, 'id'> {}
export interface FacilityAssessmentOuput extends Required<FacilityAssessmentAttributes> {}

class FacilityAssessment
  extends Model<FacilityAssessmentAttributes, FacilityAssessmentInput>
  implements FacilityAssessmentAttributes
{
  public id!: number;
  public facility_id!: number;
  public batch_id!: number;
  public indicator_id!: number;
  public assessor_id!: number;
  public reviewer_id!: number;
  public approver_id!: number;
  public dmo_approver_id!: number;
  public status!: string;
  public validator_signature!: string;
  public mho_notes!: string;
  public pho_notes!: string;
  public dmo_notes!: string;
  public respondents!: string;
  public responses!: string;
  public draft_responses!: string;
  public started_at!: Date;
  public submitted_at!: Date;
  public reviewed_at!: Date;
  public approved_at!: Date;
  public created_by!: number;
  public updated_by!: number;
  public deleted_by!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
  public facility!: Facility;
  public current_step!: string;
}

FacilityAssessment.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    facility_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facilities', key: 'id' },
    },
    batch_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'assessment_batches', key: 'id' },
    },
    indicator_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'assessment_indicators', key: 'id' },
    },
    assessor_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    reviewer_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    approver_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    dmo_approver_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    status: {
      type: DataTypes.ENUM,
      values: ['open', 'assigned', 'started', 'reviewed', 'submitted', 'pho-approved', 'completed', 'ongoing-approval'],
      defaultValue: 'open',
    },
    validator_signature: {
      type: DataTypes.TEXT('long'),
    },
    mho_notes: {
      type: DataTypes.TEXT('long'),
    },
    pho_notes: {
      type: DataTypes.TEXT('long'),
    },
    dmo_notes: {
      type: DataTypes.TEXT('long'),
    },
    respondents: {
      type: DataTypes.TEXT('long'),
    },
    responses: {
      type: DataTypes.TEXT('long'),
    },
    draft_responses: {
      type: DataTypes.TEXT('long'),
    },
    started_at: {
      type: DataTypes.DATE,
    },
    submitted_at: {
      type: DataTypes.DATE,
    },
    reviewed_at: {
      type: DataTypes.DATE,
    },
    approved_at: {
      type: DataTypes.DATE,
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    deleted_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    current_step: {
      type: DataTypes.STRING,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'facility_assessments',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default FacilityAssessment;
