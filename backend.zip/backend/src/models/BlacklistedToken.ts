import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface BlacklistedTokenAttributes {
  id: number;
  token: string;
  expires_at: Date;
}

export interface BlacklistedTokenInput extends Optional<BlacklistedTokenAttributes, 'id'> {}
export interface BlacklistedTokenOutput extends Required<BlacklistedTokenAttributes> {}

class BlacklistedToken
  extends Model<BlacklistedTokenAttributes, BlacklistedTokenInput>
  implements BlacklistedTokenAttributes
{
  public id!: number;
  public token!: string;
  public expires_at!: Date;
}

BlacklistedToken.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    token: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    expires_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    tableName: 'blacklisted_tokens',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default BlacklistedToken;
