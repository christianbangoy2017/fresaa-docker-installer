import { DataTypes, Model } from 'sequelize';

import Facility from './Facility';
import LocationRegion from './LocationRegion';
import UserGroup from './UserGroup';
import sequelizeConnection from 'db/config';

export interface UserAttributes {
  id: number;
  username: string;
  password: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  title: string;
  user_group_id: number;
  mobile_number: string;
  email: string;
  region_code: string;
  province_code: string;
  municipality_code: string;
  facility_id: number;
  manager: number;
  created_by: number;
  updated_by: number;
  deleted_by: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}

export interface UserInput {
  username: string;
  password: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  title: string;
  user_group_id: number;
  user_group_name: string;
  mobile_number: string;
  email: string;
  region_code: string;
  province_code: string;
  municipality_code: string;
  facility_id: number;
  manager: number;
  created_by: number;
}

export interface UserOutput {
  id: number;
  username: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  title: string;
  user_group_id: number;
  mobile_number: string;
  email: string;
  region_code: string;
  province_code: string;
  municipality_code: string;
  facility_id: number;
  manager: number;
  created_at: Date;
  authorities: string[];
  user_group: UserGroup;
  region: LocationRegion;
  facility: Facility;
}

export interface UserCredential {
  username: string;
  password: string;
}

export const UserAttributesArray = [
  'id',
  'username',
  'first_name',
  'middle_name',
  'last_name',
  'title',
  'user_group_id',
  'mobile_number',
  'email',
  'region_code',
  'province_code',
  'municipality_code',
  'facility_id',
  'manager',
];

export const UserShortAttributesArray = ['id', 'first_name', 'middle_name', 'last_name', 'title'];

class User extends Model<UserAttributes, UserInput> implements UserAttributes {
  public id!: number;
  public username!: string;
  public password!: string;
  public first_name!: string;
  public middle_name!: string;
  public last_name!: string;
  public title!: string;
  public user_group_id!: number;
  public mobile_number!: string;
  public email!: string;
  public region_code!: string;
  public province_code!: string;
  public municipality_code!: string;
  public facility_id!: number;
  public manager!: number;
  public created_by!: number;
  public updated_by!: number;
  public deleted_by!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

User.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    first_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    middle_name: {
      type: DataTypes.STRING,
    },
    last_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING,
    },
    user_group_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'user_groups', key: 'id' },
    },
    mobile_number: {
      type: DataTypes.STRING,
    },
    email: {
      type: DataTypes.STRING,
    },
    region_code: {
      type: DataTypes.STRING,
      references: { model: 'location_regions', key: 'region_code' },
    },
    province_code: {
      type: DataTypes.STRING,
      references: { model: 'location_provinces', key: 'province_code' },
    },
    municipality_code: {
      type: DataTypes.STRING,
      references: {
        model: 'location_municipalities',
        key: 'municipality_code',
      },
    },
    facility_id: {
      type: DataTypes.INTEGER.UNSIGNED,
    },
    manager: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    deleted_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'users',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default User;
