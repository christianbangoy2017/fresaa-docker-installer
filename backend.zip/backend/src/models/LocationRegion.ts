import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface LocationRegionAttributes {
  region_code: string;
  region_name: string;
  region_short_name: string;
  region_logo: string;
  region_logo_dark: string;
}

export interface LocationRegionInput extends Optional<LocationRegionAttributes, 'region_code'> {}
export interface LocationRegionOuput extends Required<LocationRegionAttributes> {}

class LocationRegion extends Model<LocationRegionAttributes, LocationRegionInput> implements LocationRegionAttributes {
  public region_code!: string;
  public region_name!: string;
  public region_short_name!: string;
  public region_logo!: string;
  public region_logo_dark!: string;
}

LocationRegion.init(
  {
    region_code: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    region_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_short_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_logo: {
      type: DataTypes.BLOB('long'),
      get() {
        return this.getDataValue('region_logo')?.toString();
      },
    },
    region_logo_dark: {
      type: DataTypes.BLOB('long'),
      get() {
        return this.getDataValue('region_logo_dark')?.toString();
      },
    },
  },
  {
    tableName: 'location_regions',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default LocationRegion;
