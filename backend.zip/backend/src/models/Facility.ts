import { DataTypes, Model, Optional, WhereOptions } from 'sequelize';

import FacilityType from './FacilityType';
import LocationMunicipality from './LocationMunicipality';
import LocationProvince from './LocationProvince';
import LocationRegion from './LocationRegion';
import sequelizeConnection from 'db/config';

interface FacilityAttributes {
  id: number;
  facility_name: string;
  facility_code: string;
  gis_code: string;
  region_code: string;
  province_code: string;
  municipality_code: string;
  barangay_name: string;
  barangay_code: string;
  street_name: string;
  building_name: string;
  zip_code: string;
  facility_type_id: number;
  facility_head: string;
  facility_head_name: string;
  latitude: number;
  longitude: number;
  managing_authority: string;
  projected_population: string;
  projected_population_year: string;
  with_sbf: boolean;
  created_by: number;
  updated_by: number;
  deleted_by: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface FacilityInput extends Optional<FacilityAttributes, 'id'> {}
export interface FacilityOuput extends Required<FacilityAttributes> {}

class Facility extends Model<FacilityAttributes, FacilityInput> implements FacilityAttributes {
  public id!: number;
  public facility_name!: string;
  public facility_code!: string;
  public gis_code!: string;
  public region_code!: string;
  public province_code!: string;
  public municipality_code!: string;
  public barangay_name!: string;
  public barangay_code!: string;
  public street_name!: string;
  public building_name!: string;
  public zip_code!: string;
  public facility_type_id!: number;
  public facility_head!: string;
  public facility_head_name!: string;
  public latitude!: number;
  public longitude!: number;
  public managing_authority!: string;
  public projected_population!: string;
  public projected_population_year!: string;
  public with_sbf!: boolean;
  public created_by!: number;
  public updated_by!: number;
  public deleted_by!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

Facility.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    facility_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    facility_code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    gis_code: {
      type: DataTypes.STRING,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    province_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_provinces', key: 'province_code' },
    },
    municipality_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: {
        model: 'location_municipalities',
        key: 'municipality_code',
      },
    },
    barangay_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    barangay_code: {
      type: DataTypes.STRING,
    },
    street_name: {
      type: DataTypes.STRING,
    },
    building_name: {
      type: DataTypes.STRING,
    },
    zip_code: {
      type: DataTypes.STRING,
    },
    facility_type_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facility_types', key: 'id' },
    },
    facility_head: {
      type: DataTypes.STRING,
    },
    facility_head_name: {
      type: DataTypes.STRING,
    },
    latitude: {
      type: DataTypes.DOUBLE,
    },
    longitude: {
      type: DataTypes.DOUBLE,
    },
    managing_authority: {
      type: DataTypes.STRING,
    },
    with_sbf: {
      type: DataTypes.BOOLEAN,
    },
    projected_population: {
      type: DataTypes.INTEGER.UNSIGNED,
    },
    projected_population_year: {
      type: DataTypes.INTEGER.UNSIGNED,
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    deleted_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'facilities',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default Facility;

export const includeFacility = (where?: WhereOptions<any>) => {
  return {
    model: Facility,
    as: 'facility',
    include: [
      {
        model: FacilityType,
        as: 'facility_type',
        attributes: ['type'],
      },
      {
        model: LocationRegion,
        as: 'region',
        attributes: ['region_name'],
      },
      {
        model: LocationProvince,
        as: 'province',
        attributes: ['province_name'],
      },
      {
        model: LocationMunicipality,
        as: 'municipality',
        attributes: ['municipality_name'],
      },
    ],
    where,
  };
};
