import sequelizeConnection from 'db/config';
import { DataTypes, Model, Optional } from 'sequelize';

interface ReportTemplateEntryAttributes {
  id: number;
  template_id: number;
  responses?: string;
  age?: number;
  full_name?: string;
  first_name?: string;
  middle_name?: string;
  last_name?: string;
  birthday?: Date;
  address?: string;
}

export interface ReportTemplateEntryInput extends Optional<ReportTemplateEntryAttributes, 'id'> {}
export interface ReportTemplateEntryOutput extends Required<ReportTemplateEntryAttributes> {}

class ReportTemplateEntry
  extends Model<ReportTemplateEntryAttributes, ReportTemplateEntryInput>
  implements ReportTemplateEntryAttributes
{
  public id!: number;
  public template_id!: number;
  public responses!: string | undefined;
  public age!: number | undefined;
  public full_name!: string | undefined;
  public first_name!: string | undefined;
  public middle_name!: string | undefined;
  public last_name!: string | undefined;
  public birthday!: Date | undefined;
  public address!: string | undefined;
}

ReportTemplateEntry.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    template_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'report_templates', key: 'id' },
    },
    address: {
      type: DataTypes.STRING,
    },
    birthday: {
      type: DataTypes.STRING,
    },
    age: {
      type: DataTypes.INTEGER.UNSIGNED,
    },
    first_name: {
      type: DataTypes.STRING,
    },
    full_name: {
      type: DataTypes.STRING,
    },
    last_name: {
      type: DataTypes.STRING,
    },
    middle_name: {
      type: DataTypes.STRING,
    },
    responses: {
      type: DataTypes.TEXT('long'),
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'report_template_entries',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default ReportTemplateEntry;
