import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface UserGroupAttributes {
  id: number;
  group_name: string;
  description: string;
  level: string;
  validator: boolean;
  region_code: string | null;
}
export interface UserGroupInput extends Optional<UserGroupAttributes, 'id'> {}
export interface UserGroupOuput extends Required<UserGroupAttributes> {}

class UserGroup extends Model<UserGroupAttributes, UserGroupInput> implements UserGroupAttributes {
  public id!: number;
  public group_name!: string;
  public description!: string;
  public level!: string;
  public validator!: boolean;
  public region_code!: string;
}

UserGroup.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    group_name: {
      type: DataTypes.STRING,
      allowNull: false,
      // unique: true,
    },
    description: {
      type: DataTypes.STRING,
    },
    level: {
      type: DataTypes.STRING,
    },
    validator: {
      type: DataTypes.BOOLEAN,
    },
    region_code: {
      type: DataTypes.STRING,
      references: { model: 'location_regions', key: 'region_code' },
    },
  },
  {
    tableName: 'user_groups',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default UserGroup;
