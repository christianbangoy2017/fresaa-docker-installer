import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface FacilityTypeAttributes {
  id: number;
  type: string;
}
export interface FacilityTypeInput extends Optional<FacilityTypeAttributes, 'id'> {}
export interface FacilityTypeOuput extends Required<FacilityTypeAttributes> {}

class FacilityType extends Model<FacilityTypeAttributes, FacilityTypeInput> implements FacilityTypeAttributes {
  public id!: number;
  public type!: string;
}

FacilityType.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: 'facility_types',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default FacilityType;
