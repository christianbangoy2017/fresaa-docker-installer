import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface MobileLinkAttributes {
  id: number;
  link: string;
  active: boolean;
  region_code: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}

export interface MobileLinkInput extends Optional<MobileLinkAttributes, 'id'> {}
export interface MobileLinkOutput extends Required<MobileLinkAttributes> {}

class MobileLink extends Model<MobileLinkAttributes, MobileLinkInput> implements MobileLinkAttributes {
  public id!: number;
  public link!: string;
  public active!: boolean;
  public region_code!: string;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

MobileLink.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    link: {
      type: DataTypes.TEXT('long'),
      allowNull: false,
    },
    active: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      references: { model: 'location_regions', key: 'region_code' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'mobile_link',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default MobileLink;
