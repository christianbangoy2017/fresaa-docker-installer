import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface RefreshTokenAttributes {
  id: number;
  user_id: number;
  token: string;
  expiry_date: Date;
}
export interface RefreshTokenInput extends Optional<RefreshTokenAttributes, 'id'> {}
export interface RefreshTokenOuput extends Required<RefreshTokenAttributes> {}

class RefreshToken extends Model<RefreshTokenAttributes, RefreshTokenInput> implements RefreshTokenAttributes {
  public id!: number;
  public user_id!: number;
  public token!: string;
  public expiry_date!: Date;
}

RefreshToken.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'users', key: 'id' },
    },
    token: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    expiry_date: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'refresh_tokens',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default RefreshToken;
