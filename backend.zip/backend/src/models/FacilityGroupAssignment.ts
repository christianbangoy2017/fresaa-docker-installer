import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface FacilityGroupAssignmentAttributes {
  id: number;
  group_id: number;
  facility_id: number;
}
export interface FacilityGroupAssignmentInput extends Optional<FacilityGroupAssignmentAttributes, 'id'> {}
export interface FacilityGroupAssignmentOuput extends Required<FacilityGroupAssignmentAttributes> {}

class FacilityGroupAssignment
  extends Model<FacilityGroupAssignmentAttributes, FacilityGroupAssignmentInput>
  implements FacilityGroupAssignmentAttributes
{
  public id!: number;
  public group_id!: number;
  public facility_id!: number;
}

FacilityGroupAssignment.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    group_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'facility_groups', key: 'id' },
      allowNull: false,
    },
    facility_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'facilities', key: 'id' },
      allowNull: false,
    },
  },
  {
    tableName: 'facility_group_assignment',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default FacilityGroupAssignment;
