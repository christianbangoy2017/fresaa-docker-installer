import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface LocationProvinceAttributes {
  province_code: string;
  province_name: string;
  region_code: string;
}

export interface LocationProvinceInput extends Optional<LocationProvinceAttributes, 'province_code'> {}
export interface LocationProvinceOuput extends Required<LocationProvinceAttributes> {}

class LocationProvince
  extends Model<LocationProvinceAttributes, LocationProvinceInput>
  implements LocationProvinceAttributes
{
  public province_code!: string;
  public province_name!: string;
  public region_code!: string;
}

LocationProvince.init(
  {
    province_code: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    province_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
  },
  {
    tableName: 'location_provinces',
    timestamps: false,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default LocationProvince;
