import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface ReportEntryAttributes {
  id: number;
  report_id: number;
  month: string;
  status: string;
  deadline: Date;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface ReportEntryInput extends Optional<ReportEntryAttributes, 'id'> {}
export interface ReportEntryOuput extends Required<ReportEntryAttributes> {}

class ReportEntry extends Model<ReportEntryAttributes, ReportEntryInput> implements ReportEntryAttributes {
  public id!: number;
  public report_id!: number;
  public month!: string;
  public status!: string;
  public deadline!: Date;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

ReportEntry.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    report_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'reports', key: 'id' },
    },
    month: {
      type: DataTypes.STRING,
    },
    deadline: {
      type: DataTypes.DATE,
    },
    status: {
      type: DataTypes.ENUM,
      values: ['open', 'active', 'closed'],
      defaultValue: 'open',
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'report_entries',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default ReportEntry;
