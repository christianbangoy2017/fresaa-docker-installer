import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface AssessmentBatchAttributes {
  id: number;
  batch_name: string;
  region_code: string;
  status: string;
  year: number;
  indicator_id: number;
  dashboard_code: string;
  created_by: number;
  updated_by: number;
  deleted_by: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface AssessmentBatchInput extends Optional<AssessmentBatchAttributes, 'id'> {}
export interface AssessmentBatchOuput extends Required<AssessmentBatchAttributes> {}

class AssessmentBatch
  extends Model<AssessmentBatchAttributes, AssessmentBatchInput>
  implements AssessmentBatchAttributes
{
  public id!: number;
  public batch_name!: string;
  public region_code!: string;
  public status!: string;
  public year!: number;
  public indicator_id!: number;
  public dashboard_code!: string;
  public created_by!: number;
  public updated_by!: number;
  public deleted_by!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

AssessmentBatch.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    batch_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    status: {
      type: DataTypes.ENUM,
      values: ['open', 'active', 'closed'],
      defaultValue: 'open',
    },
    year: {
      type: DataTypes.INTEGER.UNSIGNED,
    },
    indicator_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'assessment_indicators', key: 'id' },
    },
    dashboard_code: {
      type: DataTypes.STRING,
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    deleted_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'assessment_batches',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default AssessmentBatch;
