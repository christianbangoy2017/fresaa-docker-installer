import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface FacilityGroupAttributes {
  id: number;
  group_name: string;
  region_code: string;
  province_code: string;
  assessor_id: number;
  created_by: number;
  updated_by: number;
  deleted_by: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}
export interface FacilityGroupInput extends Optional<FacilityGroupAttributes, 'id'> {}
export interface FacilityGroupOuput extends Required<FacilityGroupAttributes> {}

class FacilityGroup extends Model<FacilityGroupAttributes, FacilityGroupInput> implements FacilityGroupAttributes {
  public id!: number;
  public group_name!: string;
  public region_code!: string;
  public province_code!: string;
  public assessor_id!: number;
  public created_by!: number;
  public updated_by!: number;
  public deleted_by!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

FacilityGroup.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    group_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    province_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_provinces', key: 'province_code' },
    },
    assessor_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
    deleted_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'facility_groups',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default FacilityGroup;
