import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface AssessmentBatchFacilityAttributes {
  id: number;
  facility_id: number;
  batch_id: number;
  created_by: number;
}
export interface AssessmentBatchFacilityInput extends Optional<AssessmentBatchFacilityAttributes, 'id'> {}
export interface AssessmentBatchFacilityOuput extends Required<AssessmentBatchFacilityAttributes> {}

class AssessmentBatchFacility
  extends Model<AssessmentBatchFacilityAttributes, AssessmentBatchFacilityInput>
  implements AssessmentBatchFacilityAttributes
{
  public id!: number;
  public facility_id!: number;
  public batch_id!: number;
  public created_by!: number;
}

AssessmentBatchFacility.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    facility_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'facilities', key: 'id' },
    },
    batch_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      references: { model: 'assessment_batches', key: 'id' },
    },
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      references: { model: 'users', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    tableName: 'assessment_batch_facilities',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default AssessmentBatchFacility;
