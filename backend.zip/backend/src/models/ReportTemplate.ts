import sequelizeConnection from 'db/config';
import { DataTypes, Model, Optional } from 'sequelize';

interface ReportTemplateAttributes {
  id: number;
  template_name: string;
  template_code: string;
  region_code: string;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}

export interface ReportTemplateInput extends Optional<ReportTemplateAttributes, 'id'> {}
export interface ReportTemplateOutput extends Required<ReportTemplateAttributes> {}

class ReportTemplate extends Model<ReportTemplateAttributes, ReportTemplateInput> implements ReportTemplateAttributes {
  public id!: number;
  public template_name!: string;
  public template_code!: string;
  public region_code!: string;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

ReportTemplate.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    template_name: {
      type: DataTypes.STRING,
    },
    region_code: {
      type: DataTypes.STRING,
      references: { model: 'location_regions', key: 'region_code' },
    },
    template_code: {
      type: DataTypes.STRING,
    },
    created_at: {
      type: DataTypes.DATE,
    },
    deleted_at: {
      type: DataTypes.DATE,
    },
    updated_at: {
      type: DataTypes.DATE,
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'report_templates',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default ReportTemplate;
