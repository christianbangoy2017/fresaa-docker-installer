import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface FailedLoginAttemptAttributes {
  id: number;
  username: string;
  attempts: number;
  last_attempt: Date;
}

export interface FailedLoginAttemptInput extends Optional<FailedLoginAttemptAttributes, 'id'> {}
export interface FailedLoginAttemptOutput extends Required<FailedLoginAttemptAttributes> {}

class FailedLoginAttempt
  extends Model<FailedLoginAttemptAttributes, FailedLoginAttemptInput>
  implements FailedLoginAttemptAttributes
{
  public id!: number;
  public username!: string;
  public attempts!: number;
  public last_attempt!: Date;
}

FailedLoginAttempt.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    attempts: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
    },
    last_attempt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    tableName: 'failed_login_attempts',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    sequelize: sequelizeConnection,
    paranoid: false,
  }
);

export default FailedLoginAttempt;
