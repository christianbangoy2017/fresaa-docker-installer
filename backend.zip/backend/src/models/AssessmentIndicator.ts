import { DataTypes, Model, Optional } from 'sequelize';

import sequelizeConnection from 'db/config';

interface AssessmentIndicatorsAttributes {
  id: number;
  name: string;
  indicators: string;
  region_code: string;
  validation_workflow_id: number;
  created_at?: Date;
  updated_at?: Date;
  deleted_at?: Date;
}

export interface AssessmentIndicatorsInput extends Optional<AssessmentIndicatorsAttributes, 'id'> {}
export interface AssessmentIndicatorsOutput extends Required<AssessmentIndicatorsAttributes> {}

class AssessmentIndicators
  extends Model<AssessmentIndicatorsAttributes, AssessmentIndicatorsInput>
  implements AssessmentIndicatorsAttributes
{
  public id!: number;
  public name!: string;
  public indicators!: string;
  public region_code!: string;
  public validation_workflow_id!: number;
  public created_at!: Date;
  public updated_at!: Date;
  public deleted_at!: Date;
}

AssessmentIndicators.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    indicators: {
      type: DataTypes.TEXT('long'),
      allowNull: false,
    },
    region_code: {
      type: DataTypes.STRING,
      allowNull: false,
      references: { model: 'location_regions', key: 'region_code' },
    },
    validation_workflow_id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: true,
      references: { model: 'form_validation_workflow', key: 'id' },
    },
  },
  {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at',
    tableName: 'assessment_indicators',
    timestamps: true,
    sequelize: sequelizeConnection,
    paranoid: true,
  }
);

export default AssessmentIndicators;
