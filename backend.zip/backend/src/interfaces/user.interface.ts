export interface UserGroup {
  id: number;
  group_name: string;
  description: string;
}

export interface UserGroupFilter {
  group_name: string;
  description: string;
}

export interface UserModel {
  id: number;
  user_group_id: number;
  username: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  email: string;
  title: string;
}

export interface UserAuthorityModel {
  id: number;
  authority: string;
  description: string;
}

export interface UserFilter {
  user_group_id?: number | number[];
  user_group_name?: string;
  region_code?: string;
  province_code?: string;
}
