import * as express from 'express';

import { UserGroup, UserGroupFilter } from './user.interface';

interface ControllerParam {
  req: express.Request;
  res: express.Response;
  next: express.NextFunction;
}

interface PasswordParam {
  old_password: string;
  new_password: string;
}

interface ApiQuery {
  search?: string;
  order?: 'asc' | 'desc';
  order_by?: string;
  page?: number;
  length?: number;
  status?: string | string[];
  province_code?: string;
  municipality_code?: string;
  region_code?: string;
  facility_id?: number;
  facility_type?: number;
  for_approval?: boolean;
  facility_group?: number[];
}

interface UserDropdownQuery {
  type?: string;
  facility_id?: number;
}

export { UserGroup, UserGroupFilter, ControllerParam, PasswordParam, ApiQuery, UserDropdownQuery };
