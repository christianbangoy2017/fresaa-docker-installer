import { NextFunction, Request, Response, Router } from 'express';
import {
  createOne,
  getMultiple,
  getOne,
  edit,
  updateOne,
  deleteOne,
} from 'controllers/assessment-indicator.controller';
import { createRules, editRules, updateRules } from 'rules/assessment-indicator.rules';

export const router = Router();

// GET ONE
router.get('/:id', async (req, res, next) => {
  getOne({ req, res, next });
});

// GET MULTIPLE
router.get('/', async (req, res, next) => {
  getMultiple({ req, res, next });
});

//CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// DUPLICATE
router.post('/duplicate/:id', async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', updateRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// EDIT
router.put('/edit/:id', editRules, async (req: Request, res: Response, next: NextFunction) => {
  edit({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});

export default router;
