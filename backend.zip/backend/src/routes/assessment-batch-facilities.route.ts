import { NextFunction, Request, Response, Router } from 'express';
import {
  createForAll,
  createMany,
  deleteAllByBatch,
  deleteMany,
  getDashboardData,
  getFacilitiesNotIn,
  getFacilityAssessment,
  getManyByBatchId,
} from 'controllers/assessment-batch-facility.controller';
import { createRules, deleteRules } from 'rules/assessment-batch-facilities.rules';

export const router = Router();

// creates one or many batch facility
router.post('/:batch_id', createRules, (req: Request, res: Response, next: NextFunction) => {
  createMany({ req, res, next });
});

// adds all the available facilities to assessment batch
router.post('/add-all/:batch_id', (req: Request, res: Response, next: NextFunction) => {
  createForAll({ req, res, next });
});

// deletes all the batch facility in assessment batch
router.delete('/:batch_id', (req: Request, res: Response, next: NextFunction) => {
  deleteAllByBatch({ req, res, next });
});

// deletes one or many batch facility
router.delete('/', deleteRules, (req: Request, res: Response, next: NextFunction) => {
  deleteMany({ req, res, next });
});

// retrieves all assessment batch facility details by batch id
router.get('/added/:batch_id', (req: Request, res: Response, next: NextFunction) => {
  getManyByBatchId({ req, res, next });
});

// retrieves all the facilities that are not yet added
router.get('/not-added/:batch_id', (req: Request, res: Response, next: NextFunction) => {
  getFacilitiesNotIn({ req, res, next });
});

// facility assessment of the batch
router.get(
  '/facility-assessment/:batch_id/:indicator_id/:facility_id?',
  (req: Request, res: Response, next: NextFunction) => {
    getFacilityAssessment({ req, res, next });
  }
);

router.get(
  '/facility-assessment-dashboard/:batch_id/:indicator_id/:facility_id?',
  (req: Request, res: Response, next: NextFunction) => {
    getDashboardData({ req, res, next });
  }
);

export default router;
