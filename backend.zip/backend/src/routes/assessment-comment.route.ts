import { NextFunction, Request, Response, Router } from 'express';
import {
  createOne,
  deleteOne,
  getAll,
  getMultiple,
  updateAllStatus,
  updateOne,
  updateStatus,
} from 'controllers/assessment-comment.controller';
import { createRules, updateAllStatusRules, updateRules, updateStatusRules } from 'rules/assessment-comment.rules';

export const router = Router();

// GET MULTIPLE by assessment_id
router.get('/:id', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', updateRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// UPDATE STATUS
router.patch('/:id', updateStatusRules, async (req: Request, res: Response, next: NextFunction) => {
  updateStatus({ req, res, next });
});

// UPDATE ALL STATUS
router.patch('/', updateAllStatusRules, async (req: Request, res: Response, next: NextFunction) => {
  updateAllStatus({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;
