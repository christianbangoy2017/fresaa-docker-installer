import { NextFunction, Request, Response, Router } from 'express';
import { createOne, deleteOne, getMultiple, reorder, reorderWidgets } from 'controllers/widget-group.controller';

import { createRules } from 'rules/widget-group.rules';

export const router = Router();

router.get('/:indicator_id', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

router.put('/:indicator_id/reorder', async (req: Request, res: Response, next: NextFunction) => {
  reorder({ req, res, next });
});

router.put('/:id/reorder-widgets', async (req: Request, res: Response, next: NextFunction) => {
  reorderWidgets({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;
