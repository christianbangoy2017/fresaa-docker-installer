import { NextFunction, Request, Response, Router } from 'express';
import { getAllReportTemplate, getOneReportTemplate } from 'controllers/report-template.controller';

export const router = Router();

router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  getAllReportTemplate({ req, res, next });
});

router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  getOneReportTemplate({ req, res, next });
});

export default router;
