import { NextFunction, Request, Response, Router } from 'express';
import {
  create,
  deleteComment,
  getCommentsByReportId,
  updateComment,
  updateStatus,
  resolveAllStatus
} from 'controllers/facility-report-entry-comment.controller';
import { createRules, updateRules, resolveAllRules } from 'rules/facility-report-entry-comment.rules';

export const router = Router();

router.get('/:id', (req: Request, res: Response, next: NextFunction) => {
  getCommentsByReportId({ req, res, next });
});

router.post('/', createRules, (req: Request, res: Response, next: NextFunction) => {
  create({ req, res, next });
});

router.delete('/:id', (req: Request, res: Response, next: NextFunction) => {
  deleteComment({ req, res, next });
});

router.put('/:id', updateRules, (req: Request, res: Response, next: NextFunction) => {
  updateComment({ req, res, next });
});

router.patch('/set-status/:status/:id', (req: Request, res: Response, next: NextFunction) => {
  updateStatus({ req, res, next });
});

router.patch('/', resolveAllRules, (req: Request, res: Response, next: NextFunction) => {
  resolveAllStatus({ req, res, next });
});

export default router;
