import { createOne, deleteOne, getAll, updateOne } from 'controllers/user-group-validator.controller';
import { NextFunction, Request, Response, Router } from 'express';

import { createRules } from 'rules/user-group-validator.rules';

export const router = Router();

// GET ALL
router.get('/', async (req, res, next) => {
  getAll({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', createRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;
