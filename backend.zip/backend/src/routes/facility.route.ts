import { NextFunction, Request, Response, Router } from 'express';
import {
  assignFacilityToGroup,
  createFacilitiesCSV,
  createOne,
  deleteFacilityToGroup,
  deleteOne,
  getAllFacilities,
  getAvailable,
  getAvailableMunicipality,
  getAvailableNotSelected,
  getAvailableProvince,
  getAvailableRegion,
  getFacilityTypes,
  getFieldAssessors,
  getMultiple,
  getOne,
  updateOne,
} from 'controllers/facility.controller';
import { assignmentRules, createRules, updateRules } from 'rules/facility.rules';

import fileUpload from 'express-fileupload';

export const router = Router();

router.use(fileUpload());

// GET ONE
router.get('/:id', async (req, res, next) => {
  getOne({ req, res, next });
});

// GET MULTIPLE
router.get('/', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// GET MULTIPLE
router.get('/not-in-batch/:batch_id', async (req, res, next) => {
  getMultiple({ req, res, next });
});

router.get('/list/types', async (req, res, next) => {
  getFacilityTypes({ req, res, next });
});

// GET ALL - used in export to csv
router.get('/list/all', async (req, res, next) => {
  getAllFacilities({ req, res, next });
});

// GET AVAILABLE REGION
router.get('/location/regions', async (req, res, next) => {
  getAvailableRegion({ req, res, next });
});

// GET AVAILABLE PROVINCE
router.get('/location/provinces', async (req, res, next) => {
  getAvailableProvince({ req, res, next });
});

// GET AVAILABLE MUNICIPALITY
router.get('/location/municipalities', async (req: Request, res: Response, next: NextFunction) => {
  getAvailableMunicipality({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// ASSIGN FACILITY TO FACILITY GROUP
router.post('/facility-group/:group_id', assignmentRules, async (req: Request, res: Response, next: NextFunction) => {
  assignFacilityToGroup({ req, res, next });
});

// UPDATE
router.put('/:id', createRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;

// GET AVAILABLE FACILITY NOT ADDED IN THE BATCH
router.get('/batch/:batch_id', async (req, res, next) => {
  getAvailable({ req, res, next });
});

// GET AVAILABLE FACILITY NOT ADDED IN THE FACILITY GROUP
router.get('/facility-group/not-selected/:group_id', async (req, res, next) => {
  getAvailableNotSelected({ req, res, next });
});

// GET AVAILABLE FACILITY ASSESSORS  IN THE FACILITY GROUP
router.get('/facility-group/get-assessors/:province_code', async (req: Request, res: Response, next: NextFunction) => {
  getFieldAssessors({ req, res, next });
});

// REMOVE FACILITY FROM FACILITY GROUP
router.delete('/facility-group/remove-group-in-facility', async (req, res, next) => {
  deleteFacilityToGroup({ req, res, next });
});

// IMPORT CSV FILE AND CREATE FACILITIES
router.post('/import-csv', async (req, res, next) => {
  createFacilitiesCSV({ req, res, next });
});
