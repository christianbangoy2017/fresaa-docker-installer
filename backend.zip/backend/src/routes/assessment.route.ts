import { NextFunction, Request, Response, Router } from 'express';
import {
  approveAssessment,
  batchApproveAssessments,
  createOne,
  deleteOne,
  getActive,
  getAllByFacilityId,
  getAllByStatus,
  getApprovedAssessments,
  getMultiple,
  getOne,
  removeFacilityFromGroup,
  returnAssessment,
  startAssessment,
  submitAssessment,
  updateAssessor,
  updateOne,
} from 'controllers/assessment.controller';
import { createRules, saveDraftRules, submitRules } from 'rules/assessment.rules';

export const router = Router();

// GET ONE
router.get('/:id', async (req, res, next) => {
  getOne({ req, res, next });
});

router.get('/list/pho/:batch_id', async (req, res, next) => {
  getApprovedAssessments({ req, res, next });
});

// GET MULTIPLE
router.get('/batch/:batch_id', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// GET ALL
router.get('/list/all', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// GET ACTIVE
router.get('/list/active', async (req, res, next) => {
  getActive({ req, res, next });
});

router.get('/list/by_status', async (req, res, next) => {
  getAllByStatus({ req, res, next });
});

// GET ALL BY FACILITY
router.get('/list/by_facility', async (req: Request, res: Response, next: NextFunction) => {
  getAllByFacilityId({ req, res, next });
});

// CREATE
router.post('/:batch_id', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', createRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});

router.delete('/batch/remove-facility', async (req, res, next) => {
  removeFacilityFromGroup({ req, res, next });
});

// Update Assessor
router.patch('/assessor/:id/:user_id', async (req: Request, res: Response, next: NextFunction) => {
  updateAssessor({ req, res, next });
});

// Start Asssessment
router.patch('/start/:id', async (req: Request, res: Response, next: NextFunction) => {
  startAssessment({ req, res, next });
});

// Save Draft Asssessment
router.patch('/draft/:id', saveDraftRules, async (req: Request, res: Response, next: NextFunction) => {
  submitAssessment({ req, res, next }, true);
});

// Submit Asssessment
router.patch('/submit/:id', submitRules, async (req: Request, res: Response, next: NextFunction) => {
  submitAssessment({ req, res, next });
});

// Approve Assessment
router.patch('/approve/:id', async (req: Request, res: Response, next: NextFunction) => {
  approveAssessment({ req, res, next });
});

// Batch Approve Assessments
router.patch('/batch-approve', async (req: Request, res: Response, next: NextFunction) => {
  batchApproveAssessments({ req, res, next });
});

// Return to FA
router.patch('/return-assessment/:id', async (req: Request, res: Response, next: NextFunction) => {
  returnAssessment({ req, res, next });
});

export default router;
