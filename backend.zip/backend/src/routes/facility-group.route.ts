import { NextFunction, Request, Response, Router } from 'express';
import {
  createOne,
  deleteGroupWithAllAssigned,
  deleteOne,
  getFacilitesInGroup,
  getListAssessor,
  getMultiple,
  getOne,
  updateOne,
} from 'controllers/facility-group.controller';
import { createRules, updateRules } from 'rules/facility-group.rules';

export const router = Router();

// GET ONE
router.get('/:id', async (req, res, next) => {
  getOne({ req, res, next });
});

// GET MULTIPLE
router.get('/', async (req, res, next) => {
  getMultiple({ req, res, next });
});

router.get('/get-list-assessor', async (req, res, next) => {
  getListAssessor({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', updateRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});

router.delete('/delete-groups-with-assigned/:id', async (req, res, next) => {
  deleteGroupWithAllAssigned({ req, res, next });
});

router.get('/get-groups-with-facilities/:id', async (req, res, next) => {
  getFacilitesInGroup({ req, res, next });
});
export default router;
