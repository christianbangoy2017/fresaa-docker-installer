import { Router } from 'express';
import { getMultiple } from 'controllers/activity-log.controller';

export const router = Router();

// GET MULTIPLE
router.get('/', async (req, res, next) => {
  getMultiple({ req, res, next });
});

export default router;
