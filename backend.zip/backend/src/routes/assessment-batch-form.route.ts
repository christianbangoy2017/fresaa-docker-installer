import { NextFunction, Request, Response, Router } from 'express';
import { createOne, deleteOne, getAvailable, getMultiple, getOne } from 'controllers/assessment-batch-form.controller';

import { createRules } from 'rules/assessment-batch-form.rules';

export const router = Router();

// GET ONE
router.get('/:id', async (req, res, next) => {
  getOne({ req, res, next });
});

// GET MULTIPLE
router.get('/all/:batch_id', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// GET AVAILABLE
router.get('/available/:batch_id', async (req, res, next) => {
  getAvailable({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;
