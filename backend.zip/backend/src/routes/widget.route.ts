import { NextFunction, Request, Response, Router } from 'express';
import { createOne, deleteOne, updateOne } from 'controllers/widget.controller';
import { createRules, updateRules } from 'rules/widget.rules';

export const router = Router();

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', updateRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;
