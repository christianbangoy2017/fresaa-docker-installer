import { NextFunction, Request, Response, Router } from 'express';
import {
  deleteOne,
  getAssessorsByGroupID,
  updateGroupIndicatorAssessor,
} from 'controllers/facility-group-indicator-assessor.controller';

const router = Router();

router.post('/:id', (req: Request, res: Response, next: NextFunction) => {
  updateGroupIndicatorAssessor({ req, res, next });
});

router.delete('/:id', (req: Request, res: Response, next: NextFunction) => {
  deleteOne({ req, res, next });
});

router.get('/:id', (req: Request, res: Response, next: NextFunction) => {
  getAssessorsByGroupID({ req, res, next });
});

export default router;
