import { NextFunction, Request, Response, Router } from 'express';
import {
  createOne,
  deleteOne,
  getMultiple,
  getOne,
  updateOne,
  updateStatus,
} from 'controllers/assessment-batch.controller';
import { createRules, updateRules } from 'rules/assessment-batch.rules';

export const router = Router();

// GET ONE
router.get('/:id', async (req, res, next) => {
  getOne({ req, res, next });
});

// GET MULTIPLE
router.get('/', async (req, res, next) => {
  getMultiple({ req, res, next });
});

// CREATE
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// UPDATE
router.put('/:id', updateRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// Update Status
router.put('/:status/:id', async (req: Request, res: Response, next: NextFunction) => {
  updateStatus({ req, res, next });
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});
export default router;
