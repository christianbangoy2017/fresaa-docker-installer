import { NextFunction, Request, Response, Router } from 'express';
import {
  createBulk,
  createOne,
  deleteOne,
  duplicate,
  getActiveReportEntries,
  getAllReportEntries,
  getMultiple,
  getSummary,
  updateOne,
  updateStatus,
} from 'controllers/report-entry.controller';
import { createRules, duplicateRules, updateRules } from 'rules/report-entry.rules';

export const router = Router();

// retrieves all report entry by report_id
router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  getMultiple({ req, res, next });
});

// get all approved facility report entries
router.get('/list/all', async (req: Request, res: Response, next: NextFunction) => {
  getAllReportEntries({ req, res, next });
});

// retrieves report entry summary
router.get('/summary/:id', async (req: Request, res: Response, next: NextFunction) => {
  getSummary({ req, res, next });
});

// get all approved facility report entries
router.get('/active/all', async (req: Request, res: Response, next: NextFunction) => {
  getActiveReportEntries({ req, res, next });
});

// creates one report entry
router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createOne({ req, res, next });
});

// creates one report entry
router.post('/assess-all', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createBulk({ req, res, next });
});

// duplicaes one report entry
router.post('/duplicate', duplicateRules, async (req: Request, res: Response, next: NextFunction) => {
  duplicate({ req, res, next });
});

// updates a report entry by id
router.patch('/:id', updateRules, async (req: Request, res: Response, next: NextFunction) => {
  updateOne({ req, res, next });
});

// updates a report entry by id
router.patch('/:status/:id', async (req: Request, res: Response, next: NextFunction) => {
  updateStatus({ req, res, next });
});

// deletes a report entry by id
router.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {
  deleteOne({ req, res, next });
});

export default router;
