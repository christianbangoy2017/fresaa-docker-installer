import {
  changePassword,
  deleteOne,
  getAll,
  getCurrentUser,
  getUser,
  getUserDropdown,
  registerUser,
  updateUser,
} from 'controllers/user.controller';
import { NextFunction, Request, Response, Router } from 'express';
import { changePasswordRules, registerRules, updateUserRules } from 'rules/user.rules';

export const router = Router();

router.post('/', registerRules, async (req: Request, res: Response, next: NextFunction) => {
  registerUser({ req, res, next });
});

router.put('/:id', updateUserRules, async (req: Request, res: Response, next: NextFunction) => {
  updateUser({ req, res, next });
});

router.patch('/change-password', changePasswordRules, async (req: Request, res: Response, next: NextFunction) => {
  changePassword({ req, res, next });
});

router.delete('/:id', async (req, res, next) => {
  deleteOne({ req, res, next });
});

router.get('/', async (req, res, next) => {
  getCurrentUser({ req, res, next });
});

router.get('/:id', async (req, res, next) => {
  getUser({ req, res, next });
});

router.get('/list/all-accounts', async (req, res, next) => {
  getAll({ req, res, next });
});

router.get('/list/dropdown', async (req, res, next) => {
  getUserDropdown({ req, res, next });
});

router.get('/list/facility-accounts/:facility_id', async (req, res, next) => {
  getAll({ req, res, next });
});

export default router;
