import { NextFunction, Request, Response, Router } from 'express';
import { login, logout, refreshToken } from 'controllers/user-auth.controller';
import { matchedData, validationResult } from 'express-validator';

import { loginRules } from 'rules/user.rules';

export const router = Router();

router.post('/login', loginRules, async (req: Request, res: Response, next: NextFunction) => {
  login({ req, res, next });
});

router.post('/logout', async (req, res, next) => {
  logout({ req, res, next });
});

router.post('/refresh-token', async (req, res, next) => {
  refreshToken({ req, res, next });
});

export default router;
