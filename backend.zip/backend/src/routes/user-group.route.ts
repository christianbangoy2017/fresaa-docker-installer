import { getAll } from 'controllers/user-group.controller';
import { Router } from 'express';

export const router = Router();

// GET ALL
router.get('/', async (req, res, next) => {
  getAll({ req, res, next });
});

export default router;
