import { Router } from 'express';
import { uploadLogo } from 'controllers/region.controller';

export const router = Router();

router.patch('/upload-logo/:id', async (req, res, next) => {
  uploadLogo({ req, res, next });
});

export default router;
