import { NextFunction, Request, Response, Router } from 'express';
import { createRules } from 'rules/report-template-entry.rules';
import {
  getByTemplateId,
  getEntry,
  createReportTemplateEntry,
  updateReportTemplateEntry,
  deleteReportTemplateEntry,
} from 'controllers/report-template-entry.controller';

export const router = Router();

router.get('/template/:id', async (req: Request, res: Response, next: NextFunction) => {
  getByTemplateId({ req, res, next });
});

router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  getEntry({ req, res, next });
});

router.post('/', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createReportTemplateEntry({ req, res, next });
});

router.put('/:id', createRules, async (req: Request, res: Response, next: NextFunction) => {
  updateReportTemplateEntry({ req, res, next });
});

router.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {
  deleteReportTemplateEntry({ req, res, next });
});

export default router;
