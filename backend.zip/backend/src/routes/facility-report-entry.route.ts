import { NextFunction, Request, Response, Router } from 'express';
import {
  approveFacilityReportEntry,
  batchApproveFacilityReportEntries,
  createAllAvailable,
  createReportFacilityEntry,
  deleteAllFacilityReportEntries,
  deleteReportFacilityEntries,
  get,
  getActiveReportEntryFacilityEntries,
  getApprovedReportFacilityEntries,
  getAvailableFacilities,
  getByFacilityId,
  getDashboardData,
  getMany,
  getReportEntryIndicators,
  returnReport,
  submitFacilityReportEntry,
  updateFacilityResponses,
} from 'controllers/facility-report-entry.controllers';
import { createRules, updateResponsesRules } from 'rules/facility-report-entry.rules';

export const router = Router();

router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  get({ req, res, next });
});

// get facility report entry by report entry id
router.get('/list/:id_source/:id', async (req: Request, res: Response, next: NextFunction) => {
  getMany({ req, res, next });
});

// get only facility reports not yet completed
router.get('/facility/:facility_id', async (req: Request, res: Response, next: NextFunction) => {
  getByFacilityId({ req, res, next });
});

// get the available facilities for the specified report entry
router.get('/available/:report_entry_id', async (req: Request, res: Response, next: NextFunction) => {
  getAvailableFacilities({ req, res, next });
});

// get all approved facility report entries
router.get('/approved/all', async (req: Request, res: Response, next: NextFunction) => {
  getApprovedReportFacilityEntries({ req, res, next });
});

// get all facility report entries from active report entries
router.get('/active-report-entry/all', async (req: Request, res: Response, next: NextFunction) => {
  getActiveReportEntryFacilityEntries({ req, res, next });
});

// add new facility report entry
router.post('/:report_entry_id', createRules, async (req: Request, res: Response, next: NextFunction) => {
  createReportFacilityEntry({ req, res, next });
});

// add all available facilities to facility report entry
router.post('/add-all/:report_entry_id', async (req: Request, res: Response, next: NextFunction) => {
  createAllAvailable({ req, res, next });
});

// mark the facility report entry id to submitted
router.patch('/submit/:id', updateResponsesRules, async (req: Request, res: Response, next: NextFunction) => {
  submitFacilityReportEntry({ req, res, next });
});

// mark the facility report entry id to approved
router.patch('/approve/:id', async (req: Request, res: Response, next: NextFunction) => {
  approveFacilityReportEntry({ req, res, next });
});

// batch approve facility report entries
router.patch('/batch-approve', async (req: Request, res: Response, next: NextFunction) => {
  batchApproveFacilityReportEntries({ req, res, next });
});

// delete one or more entries
router.delete('/remove-facilities', createRules, async (req: Request, res: Response, next: NextFunction) => {
  deleteReportFacilityEntries({ req, res, next });
});

// delete all the entries
router.delete('/remove-all-facilities/:report_entry_id', async (req: Request, res: Response, next: NextFunction) => {
  deleteAllFacilityReportEntries({ req, res, next });
});

// updates the facility report entry responses
router.patch('/responses/:id', updateResponsesRules, async (req: Request, res: Response, next: NextFunction) => {
  updateFacilityResponses({ req, res, next });
});

// get report entry indicators of the batch
router.get(
  '/responses/:report_entry_id/:facility_report_entry_id?',
  (req: Request, res: Response, next: NextFunction) => {
    getReportEntryIndicators({ req, res, next });
  }
);

router.get('/report-dashboard/:report_entry_id', (req: Request, res: Response, next: NextFunction) => {
  getDashboardData({ req, res, next });
});

// Return report
router.patch('/return-report/:id', async (req: Request, res: Response, next: NextFunction) => {
  returnReport({ req, res, next });
});

export default router;
