import { get } from 'controllers/mobile-link-controller';
import { NextFunction, Request, Response, Router } from 'express';

export const router = Router();

router.get('/', (req: Request, res: Response, next: NextFunction) => {
  get({ req, res, next });
});

export default router;