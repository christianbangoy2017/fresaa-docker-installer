import { FacilityGroup, User } from 'models';

import { check } from 'express-validator';

export const createRules = [
  check('group_name').notEmpty().withMessage('Group Name is required.'),
  check('province_code').notEmpty().withMessage('Province is required.'),
];

export const updateRules = [
  check('group_name').notEmpty().withMessage('Group Name is required.'),
];
