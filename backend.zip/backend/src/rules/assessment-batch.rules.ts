import { check } from 'express-validator';

export const createRules = [
  check('batch_name').notEmpty().withMessage('Batch Name is required'),
  check('year').notEmpty().withMessage('Year is required'),
  check('indicator_id').notEmpty().withMessage('Health Indicator is required'),
  check('dashboard_code'),
];

export const updateRules = [
  check('batch_name').notEmpty().withMessage('Batch Name is required'),
  check('year').notEmpty().withMessage('Year is required'),
  check('dashboard_code'),
];
