import { check } from 'express-validator';

export const createRules = [
  check('comment').notEmpty().withMessage('Comment is required'),
  check('field_code').notEmpty().withMessage('Field code is required'),
  check('field_name').notEmpty().withMessage('Field name is required'),
  check('facility_report_entry_id').notEmpty().withMessage('Facility report entry ID is required'),
];

export const updateRules = [
  check('comment').notEmpty().withMessage('Comment is required'),
];

export const resolveAllRules = [
  check('facility_report_entry_id').notEmpty().withMessage('Facility report entry ID is required'),
  check('field_code').notEmpty().withMessage('Field code is required'),
];