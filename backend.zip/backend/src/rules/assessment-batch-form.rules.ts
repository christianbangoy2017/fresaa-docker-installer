import { check } from 'express-validator';

export const createRules = [
  check('batch_id').notEmpty().withMessage('Assessment Batch is required'),
  check('indicator_id').notEmpty().withMessage('Assessment Indicator is required'),
];
