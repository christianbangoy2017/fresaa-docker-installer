import { FacilityType } from 'models';
import { check } from 'express-validator';

export const createRules = [
  check('facility_name').notEmpty().withMessage('Facility Name is required.'),
  check('facility_code').notEmpty().withMessage('Facility Code is required.'),
  check('gis_code'),
  check('region_code'),
  check('province_code'),
  check('municipality_code').notEmpty().withMessage('Municipality Code is required.'),
  check('barangay_name').notEmpty().withMessage('Barangay Name is required.'),
  check('barangay_code').notEmpty().withMessage('Barangay Code is required.'),
  check('facility_type_id')
    .isNumeric()
    .withMessage('Invalid facility type.')
    .bail()
    .custom((facility_type_id) => {
      return FacilityType.findByPk(facility_type_id).then(async (user) => {
        if (!user) {
          return Promise.reject('Invalid facility type.');
        }
      });
    }),
  check('facility_head'),
  check('facility_head_name'),
  check('latitude'),
  check('longitude'),
  check('managing_authority'),
  check('street_name'),
  check('building_name'),
  check('zip_code'),
  check('with_sbf'),
  check('projected_population'),
  check('projected_population_year'),
];

export const assignmentRules = [check('facilities').notEmpty().withMessage('Facilities is required.')];

export const updateRules = [
  check('facility_name').notEmpty().withMessage('Facility Name is required.'),
  check('facility_code').notEmpty().withMessage('Facility Code is required.'),
  check('gis_code'),
  check('region_code'),
  check('province_code'),
  check('municipality_code'),
  check('barangay_name').notEmpty().withMessage('Barangay Name is required.'),
  check('barangay_code').notEmpty().withMessage('Barangay Code is required.'),
  check('facility_type_id')
    .isNumeric()
    .withMessage('Invalid facility type.')
    .bail()
    .custom((facility_type_id) => {
      return FacilityType.findByPk(facility_type_id).then(async (user) => {
        if (!user) {
          return Promise.reject('Invalid facility type.');
        }
      });
    }),
  check('facility_head'),
  check('facility_head_name'),
  check('latitude'),
  check('longitude'),
  check('managing_authority'),
  check('with_sbf'),
  check('projected_population'),
  check('projected_population_year'),
];
