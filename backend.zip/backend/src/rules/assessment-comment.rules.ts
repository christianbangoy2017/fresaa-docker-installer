import { check } from 'express-validator';

export const createRules = [
  check('assessment_id').notEmpty().withMessage('Assessment is required'),
  check('field_code'),
  check('field_name'),
  check('comment').notEmpty().withMessage('Comment is required'),
  check('status'),
];

export const updateRules = [check('comment').notEmpty().withMessage('Comment is required')];

export const updateStatusRules = [check('status').notEmpty().withMessage('Status is required')];

export const updateAllStatusRules = [
  check('assessment_id').notEmpty().withMessage('Assessment is required'),
  check('field_code').notEmpty().withMessage('Field code is required'),
];
