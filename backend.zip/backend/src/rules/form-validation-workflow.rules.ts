import { check } from 'express-validator';

export const createRules = [check('name').notEmpty().withMessage('Name is required')];

export const updateRules = [check('name'), check('process'), check('steps')];
