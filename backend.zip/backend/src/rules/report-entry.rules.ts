import { check } from 'express-validator';

export const createRules = [
  check('report_id').notEmpty().withMessage('Report ID is required'),
  check('month').notEmpty().withMessage('Month is required'),
  check('deadline').notEmpty().withMessage('Deadline is required'),
];

export const duplicateRules = [
  check('id').notEmpty().withMessage('id is required as reference for duplication'),
  check('report_id').notEmpty().withMessage('Report ID is required'),
  check('month').notEmpty().withMessage('Month is required'),
  check('deadline').notEmpty().withMessage('Deadline is required'),
];

export const updateRules = [
  check('month').notEmpty().withMessage('Month is required'),
  check('deadline').notEmpty().withMessage('Deadline is required'),
];