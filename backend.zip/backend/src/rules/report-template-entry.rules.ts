import { check } from 'express-validator';

export const createRules = [
  check('template_id').notEmpty().withMessage('Template ID is required'),
  check('responses'),
  check('birthday'),
  check('address'),
  check('age'),
  check('full_name'),
  check('first_name'),
  check('last_name'),
  check('middle_name'),
];
