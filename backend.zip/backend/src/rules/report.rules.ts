import { check } from 'express-validator';

export const createRules = [
  check('name').notEmpty().withMessage('Name is required'),
  check('frequency').notEmpty().withMessage('Frequency is required'),
  check('frequency').isIn(['monthly', 'quarterly', 'yearly']).withMessage('Invalid frequency value'),
  check('indicator_id').notEmpty().withMessage('Health Indicator is required'),
  check('dashboard_code'),
];

export const updateRules = [
  check('name').notEmpty().withMessage('Name is required'),
  check('frequency').notEmpty().withMessage('Frequency is required'),
  check('frequency').isIn(['monthly', 'quarterly', 'yearly']).withMessage('Invalid frequency value'),
  check('dashboard_code'),
];
