import { User, UserGroup } from 'models';

import { check } from 'express-validator';

export const registerRules = [
  check('username')
    .notEmpty()
    .withMessage('Username is required')
    .bail()
    .custom((username) =>
      User.findOne({ where: { username } }).then((u) => {
        if (u) {
          return Promise.reject('Username is already taken.');
        }
      })
    ),
  check('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 8, max: 64 })
    .withMessage('Password must be between 8 and 64 characters.')
    .matches(/[!@#$%^&*(),.?":{}|<>]/)
    .withMessage('Password must include at least one special character.')
    .matches(/\d/)
    .withMessage('Password must include at least one number.'),
  check('first_name').notEmpty().withMessage('First Name is required'),
  check('middle_name'),
  check('last_name').notEmpty().withMessage('Last Name is required'),
  check('title'),
  check('user_group_name').custom((user_group_name) =>
    UserGroup.findOne({ where: { group_name: user_group_name } }).then((u) => {
      if (!u) {
        return Promise.reject('Invalid user group.');
      }
    })
  ),
  check('mobile_number'),
  check('email'),
  check('region_code'),
  check('province_code'),
  check('municipality_code'),
  check('facility_id'),
  check('manager'),
];

export const updateUserRules = [
  check('first_name').notEmpty().withMessage('First Name is required'),
  check('middle_name'),
  check('last_name').notEmpty().withMessage('Last Name is required'),
  check('title'),
  check('password')
    .optional({ checkFalsy: true })
    .matches(/[!@#$%^&*(),.?":{}|<>]/)
    .withMessage('Password must include at least one special character.')
    .matches(/\d/)
    .withMessage('Password must include at least one number.'),
  check('user_group_name').custom((user_group_name) =>
    UserGroup.findOne({ where: { group_name: user_group_name } }).then((u) => {
      if (!u) {
        return Promise.reject('Invalid user group.');
      }
    })
  ),
  check('mobile_number'),
  check('email'),
  check('region_code'),
  check('province_code'),
  check('municipality_code'),
  check('facility_id'),
  check('manager'),
];

export const changePasswordRules = [
  check('old_password').isLength({ min: 8 }).withMessage('Invalid password. Minimum password length is 8.'),
  check('new_password')
    .isLength({ min: 8, max: 64 })
    .withMessage('Password must be between 8 and 64 characters.')
    .matches(/[!@#$%^&*(),.?":{}|<>]/)
    .withMessage('Password must include at least one special character.')
    .matches(/\d/)
    .withMessage('Password must include at least one number.'),
];

export const loginRules = [
  check('password').notEmpty().withMessage('Password is required'),
  check('username').custom((username, { req }) => {
    return User.findOne({ where: { username } }).then(async (user) => {
      if (!user) {
        return Promise.reject('Invalid username or password');
      }
    });
  }),
];
