import { check } from 'express-validator';

export const createRules = [
  check('group_id').notEmpty().withMessage('Group ID is required'),
  check('type').notEmpty().withMessage('Type is required'),
  check('title').notEmpty().withMessage('Title is required'),
  check('configuration'),
];

export const updateRules = [check('title').notEmpty().withMessage('Title is required'), check('configuration')];
