import { check } from 'express-validator';

export const createRules = [
  check('name').notEmpty().withMessage('Name is required'),
  check('region_code').notEmpty().withMessage('Region is required'),
  check('validation_workflow_id').notEmpty().withMessage('Validation Workflow is required'),
];

export const updateRules = [check('indicators').notEmpty().withMessage('Indicator is required')];

export const editRules = [check('name').notEmpty().withMessage('Name is required')];
