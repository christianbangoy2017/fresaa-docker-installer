import { check } from 'express-validator';

export const createRules = [check('first_name').notEmpty().withMessage('First Name is required')];

export const updateRules = [check('first_name').notEmpty().withMessage('First Name is required')];
