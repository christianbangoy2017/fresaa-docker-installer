import { FacilityAssessment } from 'models';
import { check } from 'express-validator';

export const createRules = [check('facilities').notEmpty().withMessage('Facility is required')];
export const submitRules = [check('responses').notEmpty().withMessage('Response is required'), check('respondents')];
export const saveDraftRules = [check('draft_responses').notEmpty().withMessage('Draft Response is required')];
