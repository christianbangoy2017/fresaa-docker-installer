import { check } from 'express-validator';

export const createRules = [
  check('facilities').notEmpty().withMessage('Facility IDs are required')
];

export const updateResponsesRules = [
  check('responses').notEmpty().withMessage('Responses field is required')
];