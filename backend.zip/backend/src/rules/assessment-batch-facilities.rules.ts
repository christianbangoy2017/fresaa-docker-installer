import { check } from 'express-validator';

export const createRules = [
  check('facility_ids').notEmpty().withMessage('Facility IDs are required')
];

export const deleteRules = [
  check('assessment_batch_facility_ids').notEmpty().withMessage('Assessment batch facility ids are required')
];