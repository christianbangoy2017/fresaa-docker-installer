import { check } from 'express-validator';

export const createRules = [
  check('indicator_id').notEmpty().withMessage('Indicator ID is required'),
  check('column_type').notEmpty().withMessage('Column Type is required'),
];
