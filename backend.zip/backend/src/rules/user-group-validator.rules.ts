import { check } from 'express-validator';

export const createRules = [
  check('group_name').notEmpty().withMessage('Group Name is required.'),
  check('description'),
  check('level'),
];
