require("dotenv").config();

import { RequestHandler, Request, Response, NextFunction } from 'express';

const acceptableHeaders = process.env.ACCEPTABLE_HEADERS || "*";

export const securityRequest: () => RequestHandler = () => 
  async (req: Request, res: Response, next: NextFunction) => {
  // security headers logic
  res.append("Strict-Transport-Security", "max-age=31536000 preload");
  res.append("Content-Security-Policy", "default-src 'self'");
  next();
}

// allow users to easily configure the acceptable headers
export const acceptableCorsHeaders = acceptableHeaders.split(",");
