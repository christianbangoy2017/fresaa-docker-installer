require('dotenv').config();

import * as jwt from 'jsonwebtoken';

import { RequestHandler, Response } from 'express';

import { BlacklistedToken } from 'models';
import { IncomingHttpHeaders } from 'http';

const { TokenExpiredError } = jwt;
const _jwtSecret = process.env.JWT_SECRET as string;

export const getTokenFromHeaders = (headers: IncomingHttpHeaders) => {
  const header = headers.authorization as string;

  if (!header) return header;

  return header.split(' ')[1];
};

export const tokenGuard: () => RequestHandler = () => async (req: any, res, next) => {
  const token = getTokenFromHeaders(req.headers);
  if (!token) return res.status(401).json({ message: 'Access Denied' });

  // **Check if token is blacklisted**
  const blacklisted = await BlacklistedToken.findOne({ where: { token } });
  if (blacklisted) {
    return res.status(401).json({ message: 'Session expired. Please log in again.' });
  }

  jwt.verify(token, _jwtSecret, (err, decoded: any) => {
    if (err) {
      catchError(err, res);
    }
    req.user_id = decoded?.id;
    next();
  });
};

const catchError = (err: jwt.VerifyErrors, res: Response) => {
  if (err instanceof TokenExpiredError) {
    return res.status(401).send({ message: 'Unauthorized! Access Token was expired!' });
  }

  return res.status(401).send({ message: 'Unauthorized!' });
};
