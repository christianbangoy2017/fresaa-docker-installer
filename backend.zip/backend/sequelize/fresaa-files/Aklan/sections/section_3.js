module.exports = {
  section_number: 3,
  section_name: 'Health Workforce',
  section_description: `The health workforce can be defined as “all people engaged in actions whose primary intent is to enhance health” (WHO, 2010). These human resources include clinical staff, such as physicians, nurses, pharmacists and dentists, as well as management and support staff, i.e. those who do not deliver services directly but are essential to the performance of health systems, such as managers, ambulance drivers and accountants.`,
  has_subsection: true,
  section_body: [
    {
      type: 'section',
      section_number: '3.1',
      section_name: 'Health Care Personnel',
      section_body: [
        {
          type: 'parent',
          field_code: '1',
          field_name:
            'The organization documents and follows policies and procedures for hiring and credentialing of its staff.',
          children: [
            {
              type: 'field',
              field_name: 'Policies and procedures available for hiring and credentialing of staff',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name:
                'Administrative officer or Head of PCF aware and able to explain policies and procedures available for hiring and credentialing of staff',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'field',
          field_name:
            'New personnel, new graduates and external contractors are adequately supervised by qualified staff, with documentation of orientations conducted available',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, based on the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            { name: 'Plantillia', type: 'numeric', code: '1' },
            { name: 'Permanent', type: 'numeric', code: '1' },
            { name: 'Job Order', type: 'numeric', code: '2' },
            { name: 'Deployed by DOH', type: 'numeric', code: '3' },
            { name: 'Deployed by the Province', type: 'numeric', code: '4' },
            { name: 'Contract of Service', type: 'numeric', code: '5' },
            { name: 'Volunteer', type: 'numeric', code: '6' },
            { name: 'Adequate number to provide services to catchment population?', type: 'y/n', code: '7' },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Physician',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Registered Nurse',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Registered Midwife',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Medical Technologist',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Dentist',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Dental aide',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Sanitation inspector (government PCFs only)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'Information Technology Officer* *may be allowed to handle two administrative roles at a time',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Records Officer* *may be allowed to handle two administrative roles at a time',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Administrative Officer* *may be allowed to handle two administrative roles at a time',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Pharmacist',
              field_code: '1',
            },
          ],
        },
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, based on the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            { name: 'Registered', type: 'numeric', code: '1' },
            { name: 'Registered and Accredited', type: 'numeric', code: '1' },
            { name: 'Adequate number to provide services to catchment population?', type: 'y/n', code: '7' },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Active Barangay Health Worker',
              field_code: '1',
            },
          ],
        },
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, based on the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            { name: 'Plantillia', type: 'numeric', code: '1' },
            { name: 'Permanent', type: 'numeric', code: '1' },
            { name: 'Job Order', type: 'numeric', code: '2' },
            { name: 'Deployed by DOH', type: 'numeric', code: '3' },
            { name: 'Deployed by the Province', type: 'numeric', code: '4' },
            { name: 'Deployed by the Municipality', type: 'numeric', code: '4' },
            { name: 'Contract of Service', type: 'numeric', code: '5' },
            { name: 'Volunteer', type: 'numeric', code: '6' },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Utility worker ',
              field_code: '1',
            },
          ],
        },
        {
          type: 'field',
          field_name:
            'Is the MHO/COH registered in the National Privacy Commission, with an office order designating them as Data Privacy Officer signed by the municipal mayor?',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
        },
        {
          type: 'field',
          field_name:
            'Is there a health service provider present at all times, or officially on call for the facility at all times (24hrs a day including weekends) for deliveries?',
          field_code: '1',
          response_type: 'radio',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
          options: [
            'Yes, schedule is posted publicly',
            'Yes, but no schedule/list is posted',
            'No 24 hrs staff',
            'Don’t know',
          ],
        },
        {
          type: 'field',
          field_name: 'On average, how many hours is this facility open?',
          field_code: '1',
          response_type: 'radio',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
          options: [
            '24 hrs, 7 days a week',
            '24 hrs, 5 days a week (closed weekends)',
            '8 hrs/day, 5 days a week (40 hrs)',
            '2-4 days per week (<40 hrs) ',
            '2-4 days per month',
            'Once a month',
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '3.2',
      section_name: 'Health Care Personnel Trainings',
      section_body: [
        {
          type: 'sub-section',
          section_number: '3.2.1',
          section_name: ' ANTENATAL CARE',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Medical Technologist', type: 'numeric', code: '5' },
                { name: 'Others', type: 'numeric', code: '6' },
                { name: 'Total', type: 'total', code: '7' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name:
                    'Quality Assurance Package (QAP) / Pregnancy, Childbirth, Postpartum and Newborn Care (PCPNC)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Interpersonal Communication Skills (ICS)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Lactation Management Training',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis and Treatment of Malaria in Pregnancy',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Others', type: 'numeric', code: '6' },
                { name: 'Total', type: 'total', code: '7' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Community Tracking Tool',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Supportive Supervision',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'TB DOTS',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },

                { name: 'Total', type: 'total', code: '7' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Diagnosis and/or Treatment of STI, excluding HIV',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'HIV Counseling',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Medical Technologist', type: 'numeric', code: '5' },

                { name: 'Others', type: 'numeric', code: '6' },
                { name: 'Total', type: 'total', code: '7' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'TB screening',
                  field_code: '1',
                },
              ],
            },
          ],
        },

        {
          type: 'sub-section',
          section_number: '3.2.2',
          section_name: 'DELIVERY SERVICES',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Others', type: 'numeric', code: '6' },
                { name: 'Total', type: 'total', code: '7' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Care for the Small Babies (for low birth weight babies) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Basic Life Support (BLS) (*within the past 2 years only)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Maternal Death Review and Reporting System (MDRRS) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Maternal, Neonatal and Infant Death Reporting System (MNIDRS) ',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },

                { name: 'Others', type: 'numeric', code: '6' },
                { name: 'Total', type: 'total', code: '7' },
              ],
              rows: [
                { type: 'field', field_name: 'Basic Emergency Obstetric and Neonatal Care (BEmONC) ', field_code: '1' },
                { type: 'field', field_name: 'Essential Intrapartum and Newborn Care (EINC) ', field_code: '1' },
                { type: 'field', field_name: 'Lactation Management Training (LMT) ', field_code: '1' },
                { type: 'field', field_name: 'Expanded Newborn Screening Training ', field_code: '1' },
              ],
            },
            {
              type: 'sub-section',
              section_number: '3.2.3',
              section_name: ' POSTNATAL CARE',
              section_content: [
                {
                  type: 'table',
                  field_name:
                    'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
                  field_code: '1',
                  columns: [
                    { name: 'Doctors', type: 'numeric', code: '1' },
                    { name: 'Nurses', type: 'numeric', code: '2' },
                    { name: 'Midwives', type: 'numeric', code: '3' },
                    { name: 'Others', type: 'numeric', code: '6' },
                    { name: 'Total', type: 'total', code: '7' },
                  ],
                  rows: [
                    {
                      type: 'field',
                      field_name: 'Quality Assurance Package / Pregnancy, Childbirth, Postpartum and Newborn Care ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Management of Breastfeeding Difficulties (any one) ',
                      field_code: '1',
                    },
                  ],
                },
              ],
            },
            {
              type: 'sub-section',
              section_number: '3.2.4',
              section_name: ' FAMILY PLANNING',
              section_content: [
                {
                  type: 'table',
                  field_name:
                    'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
                  field_code: '1',
                  columns: [
                    { name: 'Doctors', type: 'numeric', code: '1' },
                    { name: 'Nurses', type: 'numeric', code: '2' },
                    { name: 'Midwives', type: 'numeric', code: '3' },
                    { name: 'Others', type: 'numeric', code: '6' },
                    { name: 'Total', type: 'total', code: '7' },
                  ],
                  rows: [
                    {
                      type: 'field',
                      field_name: 'Family Planning Competency-Based Training (FPBCT) Level 1  ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'FPCBT Level 2: Interval IUD insertion and Removal  ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'FPCBT Level 2: Post-Partum IUD Insertion and Removal  ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'FPCBT Level 2: Progestin-only Subdermal Implant Insertion and Removal  ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Bilateral Tubal Ligation-Mini-Laparotomy under Local Anesthesia (for Hospitals)  ',
                      field_code: '1',
                    },
                  ],
                },
                {
                  type: 'table',
                  field_name:
                    'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
                  field_code: '1',
                  columns: [
                    { name: 'Doctors', type: 'numeric', code: '1' },
                    { name: 'Nurses', type: 'numeric', code: '2' },

                    { name: 'Others', type: 'numeric', code: '6' },
                    { name: 'Total', type: 'total', code: '7' },
                  ],
                  rows: [
                    { type: 'field', field_name: 'No-Scalpel Vasectomy (Training for Physicians) ', field_code: '1' },
                  ],
                },
              ],
            },
            {
              type: 'sub-section',
              section_number: '3.2.5',
              section_name: ' CHILD HEALTH SERVICES',
              section_content: [
                {
                  type: 'table',
                  field_name:
                    'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
                  field_code: '1',
                  columns: [
                    { name: 'Doctors', type: 'numeric', code: '1' },
                    { name: 'Nurses', type: 'numeric', code: '2' },
                    { name: 'Midwives', type: 'numeric', code: '3' },
                    { name: 'Dentists', type: 'numeric', code: '8' },
                    { name: 'Others', type: 'numeric', code: '6' },
                    { name: 'Total', type: 'total', code: '7' },
                  ],
                  rows: [
                    {
                      type: 'field',
                      field_name: 'Expanded Program on Immunization / National Immunization Program ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Growth Monitoring or Training Course on Child Growth Standards ',
                      field_code: '1',
                    },
                    { type: 'field', field_name: 'Integrated Management of Child Illness ', field_code: '1' },
                    { type: 'field', field_name: 'Management of TB in Children ', field_code: '1' },
                    {
                      type: 'field',
                      field_name:
                        'Philippine Integrated Management of Acute Malnutrition (PIMAM)/ Training on Community-Based Management of Acute Malnutrition ',
                      field_code: '1',
                    },
                    { type: 'field', field_name: 'Infant Young Child Feeding (IYCF) ', field_code: '1' },
                    {
                      type: 'field',
                      field_name: 'Maternal Nutrition and Infant Young Child Feeding (MNIYCF)',
                      field_description: '**Different from IYCF',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Basic Oral Health Care ',
                      field_code: '1',
                      not_applicable: ['Safe Birthing Facility'],
                    },
                    {
                      type: 'field',
                      field_name:
                        'Capacity Enhancement Course - Universal Health Care, Prevention and Detection of Early Childhood Caries (ECC) ',
                      field_code: '1',
                    },
                    { type: 'field', field_name: 'Cold Chain Management Training ', field_code: '1' },
                  ],
                },
              ],
            },
            {
              type: 'sub-section',
              section_number: '3.2.6',
              section_name: ' ADOLESCENT HEALTH SERVICES',
              section_content: [
                {
                  type: 'table',
                  field_name:
                    'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
                  field_code: '1',
                  columns: [
                    { name: 'Doctors', type: 'numeric', code: '1' },
                    { name: 'Nurses', type: 'numeric', code: '2' },
                    { name: 'Midwives', type: 'numeric', code: '3' },

                    { name: 'Others', type: 'numeric', code: '6' },
                    { name: 'Total', type: 'total', code: '7' },
                  ],
                  rows: [
                    {
                      type: 'field',
                      field_name: 'Adolescent Health Care for Primary Health Service Providers - Foundational Course',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Adolescent Health, Education and Practical Training (ADEPT)',
                      field_code: '1',
                    },
                    { type: 'field', field_name: 'Adolescent Job Aid (AJA)', field_code: '1' },
                    { type: 'field', field_name: 'Healthy Young Ones', field_code: '1' },
                    {
                      type: 'field',
                      field_name: 'Mental Health and Psychosocial Support Services (MHPSS)',
                      field_code: '1',
                    },
                  ],
                },
              ],
            },
            {
              type: 'sub-section',
              section_number: '3.2.7',
              section_name: 'Other trainings',
              section_content: [
                {
                  type: 'table',
                  field_name:
                    'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
                  field_code: '1',
                  columns: [
                    { name: 'Doctors', type: 'numeric', code: '1' },
                    { name: 'Nurses', type: 'numeric', code: '2' },
                    { name: 'Midwives', type: 'numeric', code: '3' },

                    { name: 'Others', type: 'numeric', code: '6' },
                    { name: 'Total', type: 'total', code: '7' },
                  ],
                  rows: [
                    {
                      type: 'field',
                      field_name: 'FHSIS Training ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'SMART Verbal Autopsy (VA) Training ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'International Classification of Diseases (ICD) ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Civil Registration and Vital Statistics Training (CRVS) ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'Medical Certification of the Cause of Death Training (MCCOD) ',
                      field_code: '1',
                    },
                    {
                      type: 'field',
                      field_name: 'iClinicSys Training ',
                      field_code: '1',
                      not_applicable: ['Hospital', 'Infirmary'],
                    },
                    {
                      type: 'field',
                      field_name: 'iHOMIS/iHOMIS Plus Training ',
                      field_code: '1',
                      applicable: ['Hospital', 'Infirmary'],
                    },
                    {
                      type: 'field',
                      field_name: 'Standard first aid (*within the past 2 years only)',
                      field_code: '1',
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
