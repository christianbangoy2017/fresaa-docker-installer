module.exports = {
  section_number: 2,
  section_name: 'Service Delivery (including equipment for service delivery)',
  section_description:
    'Strengthening service delivery is crucial to the achievement of the health-related Sustainable Development Goals (SDGs) and the National Objectives for Health (NOH) for the Philippines, which include the delivery of  interventions to reduce child and maternal mortality. Service provision or delivery is an immediate output of the inputs into the health system, such as the health workforce, procurement and supplies, and financing. Increased inputs should lead to improved service delivery and enhanced access to services. Ensuring availability of health services that meet a minimum quality standard and securing access to them are key functions of a health system.',
  has_subsection: true,
  section_body: [
    {
      type: 'section',
      section_number: '2.1',
      section_name: ' Demand Generation',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.1.1',
          section_name: ' Information, Education and Communication materials for demand generation',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does your facility use IEC materials for the following programmes?',
              children: [
                {
                  type: 'parent',
                  field_code: '1',
                  field_name: 'Maternal Care & Oral Health',
                  children: [
                    {
                      type: 'field',
                      field_name: 'Leaflets/pamphlets ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Posters ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Flip Charts ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Models ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Videos ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Photographs ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                  ],
                },
                {
                  type: 'parent',
                  field_code: '1',
                  field_name: 'Family Planning',
                  children: [
                    {
                      type: 'field',
                      field_name: 'WHO Medical Eligibility Criteria (MEC) Wheel 5th Edition ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Flip chart in the facility ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'FP Posters in the facility ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'FP Flyers in the facility ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'GATHER approach Cue Card ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                  ],
                },
                {
                  type: 'parent',
                  field_code: '1',
                  field_name: 'Newborn, child, and adolescent health',
                  children: [
                    {
                      type: 'field',
                      field_name: 'Flyer for Newborn screening ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Are there advocacy materials on the National Immunization Program in the facility? ',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Healthy Young Ones Flipchart ',
                      field_code: '1',
                      response_type: 'y/n',
                      applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },

    {
      type: 'section',
      section_number: '2.2',
      section_name: 'Water, Sanitation and Hygiene (WASH) and Standard Precautions and Waste Management',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.2.1',
          section_name: ' Safe Practice and Environment',
          section_content: [
            {
              type: 'field',
              field_code: '1',
              field_name: 'Has your facility been assessed for WASH using WASH FIT?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'If yes, what is the score?',
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Facility has an incident reporting system identifies potential harms, evaluates causal and contributing factors for the necessary corrective and preventive action, with documented record of incident reports implementation',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Presence of a management plan, policies and procedures addressing safety',
              children: [
                {
                  type: 'field',
                  field_name: 'Management plan, policies, and procedures on safety',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Proof of implementation of a fire drill conducted in the past 12 months',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Proof of implementation of an earthquake drill conducted in the past 12 months',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Routine program of works for preventive maintenance and record of corrective maintenance are available.',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Safe and efficient use of medical equipment according to specifications ',
              children: [
                {
                  type: 'field',
                  field_name: 'Presence of operating manuals for medical equipment',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Preventive and corrective maintenance logbook and plan for replacement available',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Coordinated security arrangement to assure protection of patients and staff',
              children: [
                {
                  type: 'field',
                  field_name: 'There is a designated person in charge of security',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'There are security policies in place',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Security measures are seen being implemented',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Generator, emergency light, water system, adequate ventilation or air conditioning',
              children: [
                {
                  type: 'field',
                  field_name: 'Bacterial water analysis is done every 6 months',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name:
                    'Available proof of corrective measures done for failed bacterial water analysis, if applicable (add response option for N/A)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name:
                    'Preventive and corrective maintenance logbooks of generator, emergency light, ventilation and air conditioning available',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Faucets and water closets are working',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Emergency lights and generators are functional',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Records of preventive and corrective maintenance and plan for replacement for non-medical equipment are available',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name:
                'Operating manuals of equipment, generators, air conditioners, and other non-medical equipment are available',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Policies and procedures on Waste Disposal Management',
              children: [
                {
                  type: 'field',
                  field_name:
                    'laws, memos, guidelines on waste segregation, collection, treatment and disposal are available ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name:
                    'Contracts with service providers, waste handlers or disposal contractors are available, if applicable ',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Yes', 'No', 'N/A'],
                },
                {
                  type: 'field',
                  field_name: 'There is a waste holding area ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'There is segregation of waste with use of color coded garbage plastic and/or bins',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'There is proper labelling of waste receptacles ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'There is proper management of temporary storage areas prior to hauling for disposal ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Manual available for an Infection Prevention and Control (IPC) Program ',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name:
                'Policies and procedures in cleaning, disinfecting, drying, packaging and sterilizing of equipment, instruments and supplies available ',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Organization takes steps to prevent and control outbreaks of healthcare associated infections.',
              children: [
                {
                  type: 'field',
                  field_name:
                    'PCF has available policies on infection control such as use of PPEs, isolation precaution and hand washing ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'PCF has written policies and procedures in accordance with DOH issuances ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'PCF personnel use gloves, surgical masks, etc., as needed ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name:
                    'PCF has sinks or lavatories or designated areas for hand washing or dispenser for sanitizer ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'PCF staff is able to demonstrate proper hand washing technique ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'There are programs for prevention and treatment of needle stick injuries, and policies and procedures for the safe disposal of used needles are documented and monitored.',
              children: [
                {
                  type: 'field',
                  field_name: 'There are available reports of needle stick injuries ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Staff know about the facility’s needle stick injury policies when asked',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Staff use PPE in doing minor surgeries, handling patients with infectious disease etc.',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Has available copies of reports of notifiable diseases submitted to PIDSR and other applicable DOH recording and notification systems.',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.3',
      section_name: 'Service Specific Readiness',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.3.1',
          section_name: ' ANTENATAL CARE',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Are the following services available in this facility as part of Antenatal Care services?',
              field_code: '1',
              columns: ['Available', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name:
                    'Antenatal physical examination including Leopold’s maneuver and fundic height measurement ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Iron and Folic acid supplementation + Calcium Carbonate ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Basic Oral Health Care ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Intermittent Preventive Treatment for Malaria (for endemic area only) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Tetanus Toxoid vaccination / Tetanus-diphtheria (Td) vaccination ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Monitoring for Hypertensive Disorder of Pregnancy ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on danger signs of pregnancy and importance of 8 prenatal visits ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on having a birth plan and facility-based delivery ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Health education regarding Newborn Screening (Blood and Hearing) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on Family Planning',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Counseling about Maternal Nutrition and Infant and Young Child Feeding ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Counseling about sexually transmitted infections from mother to child, including HIV ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Mental Health Screening ',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'field',
              field_name: 'What is the schedule for delivery of antenatal care services in this facility',
              field_code: '1',
              response_type: 'radio',
              options: ['Everyday', 'Once a Week', 'Once A Month', 'Other'],
            },
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Are the following national guidelines, job-aids, checklist, and charts on antenatal care available in the facility today?',
              field_code: '1',
              columns: ['Available', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name:
                    'Quality Assurance Package (QAP) Manual / Pregnancy, Childbirth, Postpartum and Newborn Care (PCPNC) Manual',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Mother-Baby Book',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Maternal Health Record',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Birth Emergency Plan',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Are individual client records (Maternal Health Record) for antenatal care maintained in this facility?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Does this facility use any form of pregnancy tracking tool (e.g Community Tracking Tool)',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'Safe Birthing Facility'],
            },
          ],
        },

        {
          type: 'sub-section',
          section_number: '2.3.2',
          section_name: ' Delivery Services',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Are the following services available in this facility as part of Delivery services?',
              field_code: '1',
              columns: ['Available', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Monitoring and Management of Labor using Partograph ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Thermal Protection, Immediate Drying and Skin-to-Skin Contact',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Delayed Cord Cutting',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Hygienic Cord Care',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Immediate and Exclusive Breastfeeding',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Normal Delivery',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Assisted Vaginal Delivery, including imminent Breech Delivery',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Administration of Uterotonic (e.g. Oxytocin) Drug',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Manual Removal of Placenta ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Removal of Retained Products after Delivery',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Administration of Corticosteroids for Pre-Term Labor ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Administration of Intravenous Antibiotics',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Administration of Anticonvulsant',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Basic Emergency Obstetric Care',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Neonatal Resuscitation',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name:
                    'Quality Assurance Package Manual / Pregnancy, Childbirth, Postpartum and Newborn Care Manual',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Does the facility have a copy of the EINC Clinical Practical Pocket Guide?',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name:
                    'Does this facility have maternal clinical charts with properly accomplished consent forms and ICD-10 coded medical diagnosis and procedures performed? ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name:
                    'Does this facility have newborn patient charts with properly and completely filled out birth certificate forms? ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does this facility have the following health personnel full time or on call 24/7?',
              children: [
                {
                  type: 'field',
                  field_name: 'Physician trained in Basic Emergency Obstetric and Neonatal Care',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'PhilHealth Accredited Professional Provider (Midwife/Doctor)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Bachelor of Science in Midwifery (Midwife with Diploma)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.3',
          section_name: ' Postnatal Care',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Are the following routinely (always, for every client) carried out by providers in this facility as part of postnatal care?',
              children: [
                {
                  type: 'field',
                  field_name: 'Hemoglobin postnatal',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Iron supplementation',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Vitamin A supplementation',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup at 24 hours after delivery',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup at 48-72 hours after delivery',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup within 1 week of delivery',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup within 4-6 weeks of delivery',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Blood pressure monitoring postpartum',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on family planning',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on breastfeeding',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Are the following national guidelines, job-aids, checklist, and charts for postpartum care in the facility today?',
              children: [
                {
                  type: 'field',
                  field_name: 'Early Childhood Care and Development Card ',
                  field_code: '1',
                  response_type: 'y/n',
                },

                {
                  type: 'field',
                  field_name: 'Maternal, Neonatal, Infant and Young Child Feeding Job Aid ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Visual Inspection using Acetic Acid (VIA)',
                  field_code: '1',
                  response_type: 'y/n',
                  not_applicable: ['Barangay Health Station'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.4',
          section_name: ' Newborn Care',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Are the following procedures routinely performed by providers of newborn care in this facility?',
              children: [
                {
                  type: 'field',
                  field_name: 'Vitamin K injection ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Eye prophylaxis ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Hepatitis B injection within 24 hours of life ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'BCG injection within 24 hours of life ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Weighing of the newborn and measurement of length (anthropometrics) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Physical examination of the baby ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Antibiotics for Babies whose mothers had Premature Rupture of Membranes ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Antibiotics for Meconium-Stained Babies',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Antibiotics for Neonatal Sepsis ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Care for Small Babies ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Newborn Screening / Expanded Newborn Screening ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Critical Congenital Heart Defect Screening ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Newborn Hearing Screening ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Apgar Scoring ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Ballard Scoring ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Are there any newborn care national guidelines, job-aids, charts, checklist, posters in this facility today? ',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.5',
          section_name: ' Family Planning',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Are the following services available in the facility as part of Family Planning services?',
              children: [
                {
                  type: 'field',
                  field_name: 'Counselling on Family Planning',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Combined oral contraceptive pills (COC)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Progestin only contraceptive pills (POP)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Depot-Medroxyprogesterone Acetate (DMPA)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Male condom',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Interval IUD insertion & removal',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Postpartum IUD (PPIUD) insertion and removal',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary', 'Hospital'],
                },
                {
                  type: 'field',
                  field_name: 'Provision of Progesterone Subdermal Implant (PSI) insertion & removal, and reinsertion ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary', 'Hospital'],
                },
                {
                  type: 'field',
                  field_name: 'Provision of Natural Family Planning (NFP) services',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary', 'Hospital'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Is the FP Form 1 for family planning available in the facility today? ',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Are individual records or cards maintained in this facility for family planning clients? ',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.6',
          section_name: 'Child Vaccination',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Are the following child vaccination services offered in this facility as part of Child Health services?',
              children: [
                {
                  type: 'field',
                  field_name: 'BCG Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'DPT-Hib-HepB (Pentavalent) Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Inactivated Polio Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Oral Polio Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Pneumococcal Conjugate Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Rotavirus Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Measles-Rubella (MR) / Measles, Mumps, and Rubella (MMR) Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Tetanus, Diphtheria (Td)/ Tetanus Toxoid ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'What is the schedule for vaccinations in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Everyday', 'Once a week', 'Once A Month', 'Other'],
              applicable: ['Rural Health Unit', 'Barangay Health Station'],
            },
            {
              type: 'field',
              field_name:
                'Is there a national guideline, job-aid, checklist, chart on Expanded Program on Immunization/National Immunization Program (e.g. Basic EPI Manual) in the facility today?',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name:
                'Are individual child vaccination cards or booklets (Child Health Record) maintained in this facility?',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Infirmary', 'Safe Birthing Facility', 'Hospital'],
            },
            {
              type: 'field',
              field_name: 'Are TCL updated and completed showing unimmunized children?',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.7',
          section_name: 'Child Growth Monitoring Services',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Are Child Growth Monitoring services offered in this facility?',
              children: [
                {
                  type: 'field',
                  field_name: 'Measurement of weight ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Measurement of height ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Measurement of mid-upper arm circumference (MUAC) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'What is the schedule for conducting child growth monitoring in this facility? ',
              field_code: '1',
              response_type: 'radio',
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
              options: ['Daily/Weekly', 'Monthly/Quarterly', 'Annual/Semi-annual', 'Other'],
            },
            {
              type: 'field',
              field_name:
                'Are any national guidelines, job-aids, checklist, and charts for growth monitoring (e.g. Child Growth Standards Manual) in the facility today? ',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Are individual child records for growth monitoring maintained in this facility? ',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.8',
          section_name: 'Child Preventive and Curative Care Services',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Are the following carried out in this facility as part of child preventive and curative care services?',
              children: [
                {
                  type: 'field',
                  field_name:
                    'Diagnosis and/or treatment of Pneumonia, Diarrhea, Dengue, and Measles (e.g. Provision of ORS + Zinc)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis and/or treatment of Malaria in endemic areas',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis of Malnutrition (Mild, Moderate and Severe Acute Malnutrition)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Treatment of Mild, Moderate Acute Malnutrition ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Basic Oral Health Care',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Vitamin A supplementation to children ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Iron supplementation to low-birthweight infants',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Iron supplementation for children (6-11) with anemia ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Zinc supplementation to sick children with diarrhea',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Diagnosis and/or treatment of TB in children / Isoniazid Preventive Therapy',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Deworming ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Micronutrient (Vitamin A, Iron, and Iodine) supplementation to children',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'What is the schedule for delivery of child preventive and curative care services in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Everyday', 'Once a week', 'Once a month', 'Other'],
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'parent',
              field_name: 'Are the following national guidelines available in the facility today?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Are the following national guidelines available in the facility today?',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Integrated Management of Child Illness Chart Booklet',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Micronutrient Supplementation Program Manual of Operations',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Infant and Young Child Feeding Manual',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Philippine Integrated Management of Acute Malnutrition (PIMAM) Guidelines',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name:
                    'Guidelines in the Implementation of Oral Health Program for Public Health Services in the Philippines',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Are individual child records (Child Health Record) for management of childhood illnesses maintained in this facility? ',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.9',
          section_name: 'Adolescent Health Services',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Are the following services available in this facility as part of Adolescent Health Services?',
              children: [
                {
                  type: 'field',
                  field_name:
                    'Education and counselling on health effects of tobacco/smoking, diet, oral hygiene, and Adolescent Sexual and Reproductive Health (ASRH) (RHU/BHS/School) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Basic Oral Health Care Services ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'HIV and STI services ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'HPV vaccine ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Promotion of healthy diets, nutrition counselling and assessment of nutritional status ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
              field_name:
                'Are the following national guidelines, job-aids, checklist, charts on adolescent health services in the facility today?',
              children: [
                {
                  type: 'field',
                  field_name: 'Adolescent Job Aid (AJA) Manual',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name:
                    'Adolescent Health Care for Primary Health Service Providers - Foundational Course Manual',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Healthy Young Ones',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'Infirmary'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Is there an adolescent-friendly space designated in the facility? ',
              field_code: '1',
              response_type: 'radio',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station'],
              options: ['Yes, Level 1', 'Yes, Level 2', 'Yes, Level 3', 'No'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.3.10',
          section_name: 'Laboratory Services',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Are the following services available in this facility as part of Laboratory Services?',
              field_code: '1',
              columns: ['Available', 'Not Available', 'Outsourced'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Hemoglobin determination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Urine dipstick test',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Urinalysis',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Urine glucose',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Urine protein',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Blood glucose',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Blood typing',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Malaria rapid diagnostic test for endemic areas',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Syphilis rapid diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Hepatitis B diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'HIV rapid diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Complete Blood Count (CBC)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Fecalysis Test parasite in stool (general microscopy)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Pregnancy blood test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Lipid profile',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.4',
      section_name: 'Referral',
      section_body: [
        {
          type: 'parent',
          field_code: '1',
          field_name:
            'Does this facility have referral forms/records and compile return referrals for MNCHN services and the PCF min referrals below:',
          children: [
            {
              type: 'field',
              field_name:
                'Community-based rehabilitation services (e.g. physical therapy, occupational therapy, speech therapy) ',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Development and mental health evaluation',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Substance abuse services ',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'parent',
          field_code: '1',
          field_name: 'Does the facility refer high risk patients to higher facilities for delivery services?',
          children: [
            {
              type: 'field',
              field_name: 'Referral form',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Transport (non-licensed ambulance)',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Transport (licensed ambulance - accredited ambulance and driver) ',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility', 'City Health Office'],
            },

            {
              type: 'field',
              field_name: 'Memorandum of Agreement/Understanding of policy ',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility', 'City Health Office'],
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.5',
      section_name: 'Equipment, Instruments, and Other Fixtures',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.5.1',
          section_name: ' Antenatal Care',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section (tap the indicator).',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Non-mercury Sphygmomanometer',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Stethoscope',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Adult weighing scale with height measuring stick',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Stadiometer/Allen stick',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Tape measure ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Fetal Doppler',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Examination table with/without stirrups',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Digital thermometer',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Ultrasound machine',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Foot stool',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.2',
          section_name: 'Delivery Services',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Newborn weighing scale',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Infant weighing scale - crib type',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Sphygmomanometer, Non-Mercury, Pediatric',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Sphygmomanometer, Non-Mercury, Neonatal',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Pulse Oximeter (Pedia/Adult)',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Light source for examination ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Stethoscope for Pediatric Use',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Stethoscope, for Neonatal use',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: ' Delivery Table with pail',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Newborn Resuscitation Table or equivalent ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Patient Bed w/ clean sheets/linen',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Stretcher',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Wheeled stretcher',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Wheelchair',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Mid-upper arm circumference tape (Adult)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Mid-upper arm circumference tape (Child) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: ' Delivery Set',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Bandage scissors',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Thumb forceps',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Umbilical cord scissors',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name:
                    ' Disposable delivery kit (sterile cord clip or ties, plastic sheet to place under mother and sterile blade) ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Instrument Tray with Cover',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Kidney basin',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Instrument Cabinet',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },

                {
                  type: 'field',
                  field_name: 'Instrument Table or equivalent',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Storage Containers with Cover for Dry Cotton Balls ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Jar with cover and without cover',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Vaginal speculum - Small size',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Vaginal speculum - Medium size',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Vaginal speculum - Large size',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit'],
                },

                {
                  type: 'field',
                  field_name: ' Sponge Forceps',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Suction Apparatus',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Suction catheter (adult and newborn sizes)',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Rubber Suction Bulb / Penguin',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Ambu bag or self-inflating bag (adult and pediatric)',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Oxygen Tank with Regulator and Humidifier',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Cone Mask, may be improvised ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Newborn Size Mask 0 and 1',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Nebulizer (portable)',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: ' Room Thermometer',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'IV Stand or equivalent ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Wall Clock with Seconds hand',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Slippers for use in Delivery Area',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Bench',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Cabinet',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Chair',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Desk',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Electric fan',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Autoclave, 20 L /Steam sterilizer or its equivalent ',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.3',
          section_name: 'Newborn Care',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Apgar and Ballard Scoring Chart',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Drying rack',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: ' Newborn Screening (NBS) filter card',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.4',
          section_name: ' Family Planning',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: ' Tenaculum Forceps ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Mayo Scissors ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Placental Forceps',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' 10” Ovum Forceps ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' 10” Straight Forceps',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' 10” Narrow or “Alligator” Forceps ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Uterine Sound ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Kelly Pad ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: ' Printed materials/ posters for patient education',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Scalpel Blade holder for no. 2 ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Scalpel Blade no. 11 ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Mosquito Forcep',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: ' Progestin Subdermal Implant (PSI) Ancillary kit',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.5',
          section_name: ' Child Vaccination',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'EPI monitoring chart ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Vaccine carrier with cold dog ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Vaccine carrier thermometer',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Ice packs',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Cold-Chain Temperature Monitoring Chart',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Vaccine refrigerator or freezer',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Temperature monitoring devices (thermometer) ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Sharps container (“safety box”) ',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.6',
          section_name: ' Child Growth Monitoring Services',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Infant weighing scale - Salter type',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Child Weighing Scale (250-gram gradation) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Infant Weighing Scale (100-gram gradation) ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Height or Length board ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.7',
          section_name: ' Child Preventive and Curative Care Services',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Other device (e.g. cellphone) that can measure seconds',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Air Compressor',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Ultrasonic Scaler',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Light Curing Machine',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Calibrated ½ or 1-liter measuring jar for ORS',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Oxygen tank with regulator and humidifier',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Nebulizer',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.8',
          section_name: 'Other services',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', 'For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Surgical scissors straight',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Surgical scissors curved',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Bandage scissors',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pick up (ovum) forceps',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Mosquito forceps',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Tissue forceps with teeth',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Tissue forceps without teeth',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Suture removal scissors',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Ophthalmoscope',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Otoscope',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Neurohammer',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Snellen’s Chart, Visual Acuity Chart',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Dental equipment and services ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name:
                    'Dental Unit and chair with compressor and complete accessories, with high and low speed hand pieces',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Universal sealer, non-magnetic hollow handle',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pert Curette, non-magnetic hollow handle',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Periodontal probe',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Gracey curette, set of 6 different tips, non-magnetic hollow handle',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Dental instruments: mouth mirror, cotton plier, explorer,spoon excavator (1 set)',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #16 with cross serration (for better grip)',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Ergonomic for better comfort designed instrument',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #17',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #18L',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #18R',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #44',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #69',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #150',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Extraction forcep, #151',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pedo forcep, #150',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pedo forcep, #151',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pedo forcep, #17S',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pedo forcep, #165',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pedo forcep, #18R',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Pedo forcep, #18L',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Aspirating syringe (2), stainless steel, with locking mechanism',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Minnesota retractor, stainless steel',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Bone file, stainless steel',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Dental instrument cabinet',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Instrument table',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Sterilizing unit, table top',
                  field_code: '1',
                  not_applicable: ['Safe Birthing Facility'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.8',
          section_name: ' Non-medical Equipment and Instruments',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name:
                'Please show me if the following medical equipment and instruments are available in the facility today. You may add the specific count in the Remarks section.',
              field_code: '1',
              columns: ['Available & Functional', ' For Repair', 'For Replacement / Procurement', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Computer/laptop with internet connection (mobile data, Ethernet)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Mobile phone/cellphone',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Fire extinguisher',
                  field_code: '1',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
