module.exports = {
  section_number: 6,
  section_name: 'Health Information System',
  section_description: `Sound and reliable information is the foundation of decision-making across all health system building blocks. It is essential for health system policy development and implementation, governance and regulation, health research, human resources development, health education and training, service delivery and financing`,
  section_body: [
    {
      type: 'sub-section',
      section_number: '6.1',
      section_name: 'Information Management',
      section_content: [
        {
          type: 'parent',
          field_code: '1',
          field_name:
            'Records are stored, retained and disposed of in accordance with the guidelines set by National Archives of the Philippines (NAP) ',
          children: [
            {
              type: 'field',
              field_name: 'Facility has logbooks on record storage, retention, and disposal',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Facility has proper storage of records',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'field',
          field_name:
            'The facility 1) defines data sets, data generation, collection and aggregation methods, 2) determines qualified staff who are involved in each stage, and 3) has policies and procedures on record storage, safekeeping and maintenance, retention, and disposal',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name:
            'Patient records documenting any previous care can be retrieved within 10–15 minutes for review, updating and, concurrent use.',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'parent',
          field_code: '1',
          field_name:
            'The organization has policies and procedures, and devotes resources, including infrastructure, to protect records and patient charts against loss, destruction, tampering and unauthorized access or use. Only authorized individuals make entries in the patient records',
          children: [
            {
              type: 'field',
              field_name: 'Facility has logbooks for borrowing and retrieval of records',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Records can be accessed',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'field',
          field_name:
            'Facility has validated EMR, with implementation that includes but is not limited to primary care benefits, maternal and neonatal deaths, injury, and confirmed cases of diagnosis',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name:
            'Facility has proof of submission of data to the National Database of Human Resources for Health Information System (NDHRHIS)',
          field_code: '1',
          response_type: 'y/n',
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '6.2',
      section_name: 'HIS and Electronic Medical Records (EMR)',
      section_content: [
        {
          type: 'field',
          field_name: 'EMR engagement (Regional circular 23 June 2023)',
          field_code: '1',
          response_type: 'y/n',
          field_description: `
            Letter of intent
            Notarized memorandum of agreement
            Sangguinang Bayan resolution
            Service Level Agreement
            HCI Engagement Registration Form
            Notarized Non-Disclosure Agreement
          `,
        },
        {
          type: 'field',
          field_name: 'ICT compliant',
          field_code: '1',
          response_type: 'y/n',
          field_description: `
          Field Description:
          At least 6 desktop/laptop (Minimum specs: Windows 10, Core i3 [3.0 GHz], 8 GB DDR4 memory, 256 GB SSD and 1 TB HDD, 2 GB or higher graphics [optional]) 
          Facility has internet connection with at least 100 mbps speed
          At least 1 Automatic Document Feeder Printer and Scanner
          At least 1 webcam
          `,
        },
        {
          type: 'field',
          field_name: 'At least 2 trained personnel/encoder to oversee the EMR implementation',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Report (M2) is generated in EMR',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'conditional-field',
          field_name: 'Are Electronic Medical Records (EMR) present in the facility?',
          field_code: '1',
          response_type: 'y/n',

          children: [
            {
              type: 'field',
              field_name: 'Name of EMR',
              field_code: '1',
              response_type: 'text',
            },
            {
              type: 'field',
              field_name: 'Name of Health Information Technology Provider',
              field_code: '1',
              response_type: 'text',
            },
            {
              type: 'parent',
              field_name: 'Does the EMR have these functionalities?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Patients Consultation Recording',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Inventory of Logistics',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Environmental',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Financial for PhilHealth Claims',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Does the facility submit reports to PhilHealth through EMR (utilizing eClaims functions)',
              field_code: '1',
              response_type: 'y/n',
            },
            // {
            //   type: 'parent',
            //   field_name: 'IP Monitoring',
            //   field_code: '1',
            //   children: [
            //     {
            //       type: 'field',
            //       field_name: 'Is this data submitted for regional level analysis?',
            //       field_code: '1',
            //       response_type: 'radio',
            //       options: ['Yes', 'No', 'Not Applicable'],
            //     },
            //   ],
            // },
          ],
        },
        // {
        //   type: 'table',
        //   field_name: 'Types of PhilHealth Claims',
        //   field_code: '1',
        //   columns: [
        //     {
        //       name: 'Is claiming of PhilHealth packages available within the facility?',
        //       type: 'y/n',
        //       code: '1',
        //       trigger: ['No'],
        //     },
        //     {
        //       name: 'Name of the system used',
        //       type: 'text',
        //       code: '2',
        //       default: ['N/A'],
        //     },
        //   ],
        //   rows: [
        //     {
        //       type: 'field',
        //       field_name: 'E-Konsulta',
        //       field_code: '1',
        //     },
        //     {
        //       type: 'field',
        //       field_name: 'Maternal Care Package (MCP)',
        //       field_code: '1',
        //     },
        //     {
        //       type: 'field',
        //       field_name: 'TB-DOTS',
        //       field_code: '1',
        //     },
        //     {
        //       type: 'field',
        //       field_name: 'Animal Bite Package',
        //       field_code: '1',
        //     },
        //     {
        //       type: 'field',
        //       field_name: 'Family Planning Claims',
        //       field_code: '1',
        //     },
        //     {
        //       type: 'field',
        //       field_name: 'COVID Isolation Claims',
        //       field_code: '1',
        //     },
        //   ],
        // },
        {
          type: 'parent',
          field_name: 'FHSIS Reporting',
          field_code: '1',
          children: [
            {
              type: 'field',
              field_name: 'Does the facility submit FHSIS reports to DOH through EMR?',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_name: 'Are there any other recording tools present?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Target Client List (TCL) ',
                  field_code: '1',
                  response_type: 'y/n',
                  not_applicable: ['Infirmary', 'Hospital'],
                },
                {
                  type: 'field',
                  field_name: 'Summary Table ',
                  field_code: '1',
                  response_type: 'y/n',
                  not_applicable: ['Infirmary', 'Hospital'],
                },
                {
                  type: 'field',
                  field_name: 'Hospital Statistics Report',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Hospital', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'M1',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Q1',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit'],
                },
                {
                  type: 'field',
                  field_name: 'Others 1 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Others 2 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Others 3 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Others 4 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
              ],
            },
          ],
        },
        {
          type: 'field',
          field_name:
            'Does the facility monitor access of IP to health services using Electronic Medical Records (EMR)?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: ' Submitted FHSIS reports to DOH through EMR.',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Submitted claims to PhilHealth through EMR utilizing eClaims functions',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Submitted claims to PhilHealth through EMR utilizing eKonsulta functions',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'parent',
          field_name: 'Presence of Telemedicine',
          field_code: '1',
          children: [
            {
              type: 'conditional-field',
              field_name: 'Is telemedicine available in the facility?',
              field_code: '1',
              response_type: 'y/n',
              children: [
                {
                  type: 'field',
                  field_name: 'Name of provider',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'parent',
                  field_name: 'Is this technology utilized in telemedicine',
                  field_code: '1',
                  children: [
                    {
                      type: 'field',
                      field_name: 'in-house web-application',
                      field_code: '1',
                      response_type: 'y/n',
                    },

                    {
                      type: 'field',
                      field_name: 'SMS/call',
                      field_code: '1',
                      response_type: 'y/n',
                    },

                    {
                      type: 'field',
                      field_name: 'Video Conferencing',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'social-media',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'web-application',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                  ],
                },
              ],
            },
          ],
        },
        {
          type: 'conditional-field',
          field_name: 'Interoperable with other EMR within the EMR interoperability network',
          field_code: '1',
          response_type: 'y/n',

          children: [
            {
              type: 'field',
              field_name: 'Name of System',
              field_code: '1',
              response_type: 'text',
            },
            {
              type: 'field',
              field_name: 'Name of Health Information Technology Provider',
              field_code: '1',
              response_type: 'text',
            },
          ],
        },
        {
          type: 'parent',
          field_name: 'Presence/Utilization of Other DOH Information Systems ',
          field_code: '1',
          children: [
            {
              type: 'field',
              field_name: 'Online Malaria Information System (OLMIS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Integrated Tuberculosis Information System (ITIS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'National Rabies Information System (NaRIS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Philippine Registry for Persons with Disability (PRPWD)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Health Emergency Allowance Processing System (HEAPS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Electronic Logistic Management Information System (eLMIS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Online National Electronic Injury Surveillance System (ONEISS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Philippine Integrated Disease Surveillance and Response (PIDSR)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'National BHW Registry System (NBHWRS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'LGU Health Scorecard Information System (LGUHSC IS)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Health Facility Profile - DOH Data Collect Hub (HFPDDC)',
              field_code: '1',
              response_type: 'y/n',
              not_applicable: ['Safe Birthing Facility'],
            },
          ],
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '6.2',
      section_name: 'Human Resources for ICT',
      section_content: [
        {
          type: 'table',
          field_name: 'Human Resources for ICT',
          field_code: '1',
          columns: [
            {
              name: '# Regular Personnel',
              type: 'numeric',
              code: '2',
              trigger: ['0'],
            },
            {
              name: '# Contractual/Job Order Personnel ',
              type: 'numeric',
              code: '3',
              default: ['0'],
            },
            {
              name: 'Source of Fund',
              type: 'parent',
              children: [
                { name: 'LGU', type: 'y/n', code: '4', default: ['No'] },
                { name: 'DOH', type: 'y/n', code: '5', default: ['No'] },
                { name: 'Province', type: 'y/n', code: '6', default: ['No'] },
                { name: 'NGO', type: 'y/n', code: '7', default: ['No'] },
              ],
            },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Presence of dedicated ICT personnel primarily functioning on EMR.',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Presence of designated personnel primarily functioning as Data Privacy Officer',
              field_code: '1',
            },
          ],
        },
      ],
    },

    {
      type: 'sub-section',
      section_number: '6.3',
      section_name: 'ICT Equipment and Infrastructure',
      section_content: [
        {
          type: 'sub-section',
          section_number: '6.3.1',
          section_name: 'ICT Equipment',
          section_content: [
            {
              type: 'table',
              field_name: 'Are the following items available in the facility?',
              field_code: '1',
              columns: [
                {
                  name: 'Count',
                  type: 'numeric',
                  code: '1',
                  trigger: [0],
                },
                {
                  name: 'Count per Specs',
                  type: 'parent',
                  code: '2',
                  children: [
                    {
                      name: 'Below min specs',
                      type: 'numeric',
                      code: '1',
                      default: [0],
                    },
                    {
                      name: 'Min specs',
                      type: 'numeric',
                      code: '1',
                      default: [0],
                    },
                    {
                      name: 'Recommended specs',
                      type: 'numeric',
                      code: '1',
                      default: [0],
                    },
                  ],
                },
                {
                  name: 'Source of Fund',
                  type: 'parent',
                  code: '2',
                  children: [
                    { name: 'LGU', type: 'y/n', code: '2', default: ['No'] },
                    { name: 'DOH', type: 'y/n', code: '3', default: ['No'] },
                    { name: 'Province', type: 'y/n', code: '4', default: ['No'] },
                    { name: 'NGO', type: 'y/n', code: '5', default: ['No'] },
                  ],
                },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Desktop',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Laptop',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Tablet',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Server',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name: 'Are the following items available in the facility?',
              field_code: '1',
              columns: [
                {
                  name: 'Count',
                  type: 'numeric',
                  code: '1',
                  trigger: [0],
                },
                {
                  name: 'Source of Fund',
                  type: 'parent',
                  code: '2',
                  children: [
                    { name: 'LGU', type: 'y/n', code: '2', default: ['No'] },
                    { name: 'DOH', type: 'y/n', code: '3', default: ['No'] },
                    { name: 'Province', type: 'y/n', code: '4', default: ['No'] },
                    { name: 'NGO', type: 'y/n', code: '5', default: ['No'] },
                  ],
                },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Scanner',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Printer',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Is the facility certified with functional EMR?',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '6.3.2',
          section_name: 'Presence of Internet Service Provider',
          section_content: [
            {
              type: 'conditional-field',
              field_name: 'Is the internet available in the facility?',
              field_code: '1',
              response_type: 'y/n',
              children: [
                {
                  type: 'field',
                  field_name: 'Name of Internet Service Provider',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Internet Speed',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Actual download speed (Mbps)',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Actual upload speed (Mbps)',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'parent',
                  field_name: 'Source of Fund',
                  field_code: '1',
                  children: [
                    {
                      type: 'field',
                      field_name: 'LGU',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'DOH',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Province',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'NGO',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                  ],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Is there a presence of a Local Area Network (LAN), and what is the type of topology?',
              field_code: '1',
              response_type: 'radio',
              options: ['WiFi', 'LAN-cabling', 'LAN and WiFi', 'Not available'],
            },
          ],
        },
      ],
    },
  ],
};
