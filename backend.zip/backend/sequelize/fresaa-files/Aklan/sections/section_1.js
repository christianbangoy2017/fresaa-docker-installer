module.exports = {
  section_number: 1,
  section_name: 'Leadership, Governance and Policy',
  has_subsection: 'true',
  section_body: [
    {
      type: 'section',
      section_number: '1.1',
      section_name: 'DOH policies, certification, ordinances, executive orders, or resolutions',
      section_body: [
        {
          type: 'sub-section',
          section_number: '1.1.1',
          section_name: ' Maternal Care',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does the facility have the following DOH ordinances, executive orders, or resolutions?',
              children: [
                {
                  type: 'field',
                  field_name: 'BEMONC certified only',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'License to Operate as birthing facility',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Mother-Baby Friendly Facility ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Maternal, Neonatal, Child Health and Nutrition (MNCHN) Policy',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Safe Motherhood and/or Facility-based Deliveries',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Contraceptive Self-Reliance Policy',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Breastfeeding and/or Milk Code ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'PhilHealth enrollment of women about to give birth',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Disease Outbreak (e.g. COVID-19) Policies on Maternal Health',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'FP Clinical Standards Manual (2014 Edition)',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.1.2',
          section_name: 'Oral Health',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does the facility have the following DOH ordinances, executive orders, or resolutions?',
              children: [
                {
                  type: 'field',
                  field_name: 'National Policy on Oral Health Care',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Oral Health Program (OHP) Implementing Guidelines and Procedures',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Local ordinances enacted/passed for oral health',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.1.3',
          section_name: 'Newborn, child, and adolescent health',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does the facility have the following DOH ordinances, executive orders, or resolutions?',
              children: [
                {
                  type: 'field',
                  field_name: 'Newborn Screening Policy',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Micro plan and session plan for routine immunization',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name:
                    'National guidelines, memos, advisories, monitoring tools, Manual of Operation on National Immunization Program in the BHS',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Is the facility certified as Adolescent-Friendly? If yes, what level?',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Level 1', 'Level 2', 'Level 3', 'No'],
                },
                {
                  type: 'field',
                  field_name: 'Is there an existing AHDP Policy in the LGU?',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Ordinance with IRR', 'Ordinance only', 'MOP', 'No'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.1.4',
          section_name: 'Nutrition',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does the facility have the following DOH ordinances, executive orders, or resolutions?',
              children: [
                {
                  type: 'field',
                  field_name: 'Eo51/ Milk code',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'RA 11148 Kalusugan ng Magnanay Act (First 1000 Days)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Philippine Integrated Management of Acute Malnutrition (PIMAM)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Food Fortification',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Asin Law',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.1.5',
          section_name: 'Population-based Primary Care Services',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does the facility have written policies and procedures based on DOH issued guidelines on:',
              children: [
                {
                  type: 'field',
                  field_name: 'health promotion',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'epidemiologic surveillance',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'health protection (vector control, environmental health, occupational safety',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'emergency preparedness and response',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.1.6',
          section_name: 'Individual-based Primary Care Services',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Does the facility have written policies and procedures based on DOH guidelines and Manual of Procedures on:',
              children: [
                {
                  type: 'field',
                  field_name: 'Maternal and Newborn Care ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Family planning services ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Nutrition services ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Dental services ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Actual or Referral services to community-based rehabilitation services ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Actual or Referral services to developmental and mental health evaluation ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Actual or Referral services to substance abuse services ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '1.2',
      section_name: 'PhilHealth accreditation',
      section_body: [
        {
          type: 'parent',
          field_code: '1',
          field_name: 'Does this facility have accreditation from PhilHealth?',
          children: [
            {
              type: 'field',
              field_name: 'Konsulta Package',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Maternity Care Package',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Newborn Care Package',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Family Planning Package',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Z-Benefit Package: Dialysis',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Hospital'],
            },
            {
              type: 'field',
              field_name: 'Outpatient HIV/AIDS Treatment (OHAT)',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Tuberculosis Directly Observed Treatment, Short Course (TB-DOTS)',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Animal Bite Treatment Center',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Out-Patient Malaria Package',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'COVID-19 Community Isolation Benefit Package (CCIBP)',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'field',
          field_code: '1',
          field_name: 'Is the facility able to do Point-of-care/ Point of service enrollment to PhilHealth?',
          response_type: 'y/n',
        },
      ],
    },

    {
      type: 'section',
      section_number: '1.3',
      section_name: 'Maternal Neonatal and Infant Death Review and Reporting Systems',
      section_body: [
        {
          type: 'sub-section',
          section_number: '1.3.1',
          section_name: ' Maternal Neonatal and Infant Death Review and Reporting Systems',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Does this facility implement and use the following?',
              children: [
                {
                  type: 'field',
                  field_name: 'Maternal Death Review and Reporting System (MDRRS) ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Maternal, Neonatal and Infant Death Reporting System (MNIDRS) ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.3.2',
          section_name: "Patient's Rights and Organization Ethics",
          section_content: [
            {
              type: 'field',
              field_name:
                'All patient charts have signed consent for procedures in accordance to Data Privacy Act (e.g. minor surgery, immunization) ',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.3.3',
          section_name: ' Patient Care',
          section_content: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Written policies and procedures in conducting minor surgical procedures: ',
              children: [
                {
                  type: 'field',
                  field_name: 'suturing of superficial lacerations ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'circumcision ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Incision and drainage ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Debridement ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Excision of small cyst ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Written policies and procedures on issuance of certificates (medical certification, death certification, and medico-legal certifications) ',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Written policies and procedures on sanitation inspection and issuance of sanitary permit',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Written policies and procedures on:',
              children: [
                {
                  type: 'field',
                  field_name: 'Patient navigation in its primary network',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Supervision of barangay health stations',
                  field_code: '1',
                  response_type: 'y/n',
                  not_applicable: ['Hospital', 'Infirmary', 'Barangay Health Station'],
                },
                {
                  type: 'field',
                  field_name: 'Supervision of health workers',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'The contents of patient’s records are the following: ',
              children: [
                {
                  type: 'field',
                  field_name: 'Doctor’s order',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Informed consent in accordance to Data Privacy Act',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Medication and/or treatment record',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Dental records if dental facility is within the PCF and not outsourced  ',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Yes', 'No', 'N/A'],
                },
                {
                  type: 'field',
                  field_name: 'Laboratory and x-ray reports, if any',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Yes', 'No', 'N/A'],
                },
                {
                  type: 'field',
                  field_name:
                    'Record of referral or transfer of patient to other facility/service/doctor including notes.',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Yes', 'No', 'N/A'],
                },
              ],
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Coordinated plan of care with goals with proof of implementation of adopted/developed protocols, and DOH approved CPGs, once available',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.3.4',
          section_name: ' Leadership and management',
          section_content: [
            {
              type: 'field',
              field_name:
                'Facility has evaluation and monitoring activities to assess management and organizational performance, with accomplishment reports or other annual reports available',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '1.4',
      section_name: 'Physical Structure of Facility',
      section_body: [
        {
          type: 'sub-section',
          section_number: '1.4.1',
          section_name: ' PHYSICAL STRUCTURE OF FACILITY',
          section_content: [
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a clear sign bearing the name of the facility?',
              response_type: 'y/n',
            },

            {
              type: 'parent',
              field_code: '1',
              field_name:
                'Entrances and exits are clearly and prominently marked, free of any obstruction and readily accessible',
              children: [
                {
                  type: 'field',
                  field_name: 'There are posted entrance and exit signs ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Exit signs are luminous or illuminated ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Entrances and exits are accessible and free from any obstruction ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is the NHFR facility code metal plate posted in the facility?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Directional signs are prominently posted to help locate service areas within the organization.',
              response_type: 'y/n',
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Ramps for patients with special needs ',
              children: [
                {
                  type: 'field',
                  field_name: 'Available ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Prominently marked ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Free from obstruction ',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Posted patients’ rights in conspicuous places.',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'List of services and schedule of operation posted in a conspicuous area.',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'DOH LTO (updated, valid and original) posted in a conspicuous area.',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Organizational structure/chart is posted in conspicuous area',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Facility has a written vision and mission, which are posted in a conspicuous area',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a sign indicating it is a PhilHealth provider?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
            },

            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a sign enumerating the services available?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a generally clean environment inside the facility?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Are there visible signs prohibiting smoking?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there sufficient seating for clients in a well-ventilated area?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there adequate lighting or naturally well-lighted?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Is there a consultation/examination room/cubicle with auditory and visual privacy available?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a Delivery Room?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Does the delivery room have an area for resuscitation of newborn?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there an area for cleaning instruments?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a labor room?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a recovery room?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there an area for telemedicine?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a dedicated cold chain area?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a functional toilet for in-patient use only (1 toilet: 6 beds)?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there an accessible toilet for the public?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a separate toilet for the staff?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Are there separate toilets for males and females?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Are there emergency escape plans posted in conspicuous places?',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a reception area?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there a waiting area?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there an IEC area?',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name: 'Is there an area for record keeping?',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '1.4.2',
          section_name: '  Improving performance',
          section_content: [
            {
              type: 'field',
              field_code: '1',
              field_name: 'Facility has a continuous quality improvement (CQI) plan and proof of implementation',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_code: '1',
              field_name:
                'Facility conducts a customer satisfaction survey and documents results and how complaints/comments are acted upon implementation',
              response_type: 'y/n',
            },
          ],
        },
      ],
    },
  ],
};
