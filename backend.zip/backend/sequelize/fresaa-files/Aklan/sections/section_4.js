module.exports = {
  section_number: 4,
  section_name: 'Financing',
  has_subsection: false,
  section_description: `Accreditations that allow facilities to apply for reimbursements. Health financing refers to the “function of a health system concerned with the mobilization, accumulation and allocation of money to cover the health needs of the people, individually and collectively, in the health system… the purpose of health financing is to make funding available, as well as to set the right financial incentives to providers, to ensure that all individuals have access to effective public health and personal health care” (WHO, 2010).`,
  section_body: [
    {
      type: 'sub-section',
      section_number: '4.1',
      section_name: 'Budget Allocation for Health',
      section_content: [
        {
          type: 'parent',
          field_code: '1',
          field_name: 'Please indicate the approved budget allocation for health across programs at MUNICIPAL levels.',
          children: [
            {
              type: 'field',
              field_name: 'Total budget for all health programs',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Safe Motherhood',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Family Planning',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Child Health (including National Immunization Programme)',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Nutrition',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Adolescent Health Development',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Oral Health',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Information, Communication and Technology (ICT)/ Electronic Medical Records (EMR)',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Other programs',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
          ],
        },
        {
          type: 'parent',
          field_code: '1',
          field_name: 'Please indicate the approved budget allocation for health across programs at BARANGAY levels.',
          children: [
            {
              type: 'field',
              field_name: 'Total budget for all health programs',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Safe Motherhood',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Family Planning',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Child Health (including National Immunization Programme)',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Nutrition',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Adolescent Health Development',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Oral Health',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Information, Communication and Technology (ICT)/ Electronic Medical Records (EMR)',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
            {
              type: 'field',
              field_name: 'Other programs',
              field_code: '1',
              response_type: 'numeric',
              applicable: ['Barangay Health Station'],
            },
          ],
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '4.2',
      section_name: ' Public Access to Price Information',
      section_content: [
        {
          type: 'table',
          table_type: 'simple-table',
          field_name: 'Public Access to Price Information',
          field_code: '1',
          columns: ['Yes', 'No', 'N/A'],
          rows: [
            {
              type: 'field',
              field_name:
                'Price list of health services and goods in a conspicuous area, such as, but not limited to, the lobby, reception area, information kiosk and business office (may be a printed handout, menu booklet, interactive digital format, poster, tarpaulin, etc ',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'The price list shall include, but not limited to, the following: * Price per type of accommodation, critical care units and emergency room* Fees for medical and surgical procedures * Price of laboratory tests* Professional fees* Price of drugs, medicines, and medical supplies* Bundle/package price of health services* Corresponding PhilHealth case rate packages and Z-package rates, if applicable* Corresponding Health Maintenance Organization (HMO) rate, if applicable*May be presented in ranges, if deemed appropriate. ',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'For health facilities that have official website, updated price list is available on the health facility’s official website and the date when the price list was last updated is indicated. ',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'Facility price list is updated at least annually and the date when the price list was last updated is indicated ',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'Documented proof that the price list, including the No Balance Billing policy for basic accommodation, was presented and explained ',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'Documented proof that the information was understood and accepted by the patient or patient’s guardian ',
              field_code: '1',
            },
            {
              type: 'field',
              field_name:
                'Health facility has proof of submission of information regarding its prices and charges for goods and health services, including professional fees, to the information system of DOH and PhilHealth, once the system is fully functional ',
              field_code: '1',
            },
          ],
        },
      ],
    },
  ],
};
