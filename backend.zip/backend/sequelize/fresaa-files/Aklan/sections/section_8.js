module.exports = {
  section_number: 8,
  section_name: 'Health Regulation',
  section_body: [
    {
      type: 'sub-section',
      section_number: '8.1',
      section_name: 'DOH Licensing',
      section_content: [
        {
          type: 'field',
          field_name: 'Safe Birthing Facility',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Pharmacy',
          field_code: '1',
          response_type: 'radio',
          options: ['Yes', 'No', 'Service outsourced'],
        },
        {
          type: 'field',
          field_name: 'Radiologic Services',
          field_code: '1',
          response_type: 'radio',
          options: ['Yes', 'No', 'Service outsourced'],
        },
        {
          type: 'field',
          field_name: 'Ambulance',
          field_code: '1',
          response_type: 'radio',
          options: ['Yes', 'No', 'Service outsourced'],
        },
      ],
    },
  ],
};
