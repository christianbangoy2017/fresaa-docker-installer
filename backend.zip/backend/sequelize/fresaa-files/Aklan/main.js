const section0 = require('../Aklan/sections/section_0');
const section1 = require('../Aklan/sections/section_1');
const section2 = require('../Aklan/sections/section_2');
const section3 = require('../Aklan/sections/section_3');
const section4 = require('../Aklan/sections/section_4');
const section5 = require('../Aklan/sections/section_5');
const section6 = require('../Aklan/sections/section_6');
const section7 = require('../Aklan/sections/section_7');
const section8 = require('../Aklan/sections/section_8');

module.exports = [section0, section1, section2, section3, section4, section5, section6, section7, section8];
