module.exports = {
  section_number: 2,
  section_name: 'Service Delivery (including equipment for service delivery)',
  section_description:
    'Strengthening service delivery is crucial to the achievement of the health-related Sustainable Development Goals (SDGs) and the National Objectives for Health (NOH) for the Philippines, which include the delivery of  interventions to reduce child and maternal mortality. Service provision or delivery is an immediate output of the inputs into the health system, such as the health workforce, procurement and supplies, and financing. Increased inputs should lead to improved service delivery and enhanced access to services. Ensuring availability of health services that meet a minimum quality standard and securing access to them are key functions of a health system.',
  has_subsection: true,
  section_body: [
    {
      type: 'section',
      section_number: '2.1',
      section_name: 'General Maternal, Newborn, Child Health & Nutrition (MNCHN) Services',
      section_body: [
        {
          type: 'parent',
          field_name:
            'Does this facility offer any of the following client services? Is there any location in this facility where clients can receive any of the following services?',
          field_code: '1',
          children: [
            {
              type: 'field',
              field_name: 'Health Education',
              field_code: '1',
              response_type: 'y/n',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'field',
              field_name: 'Natural method of family planning',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Artificial method of family planning',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Antenatal care',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Normal delivery',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Assisted delivery',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Postnatal care',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Breastfeeding education',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Newborn care',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Newborn screening - Blood',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Newborn Hearing Screening',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Child Vaccinations',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Child Growth Monitoring',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Integrated Management of Child Illnesses',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Therapeutic food supplementation for children with acute malnutrition',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Micronutrient Supplementation',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Management of TB in children',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Basic Oral Health Care',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name:
                'Education and counselling on health effects of tobacco/smoking, diet, and oral hygiene to adolescents',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Adolescent Sexual and Reproductive Health (ASRH)',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Laboratory diagnostic services',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Point-of-care/ Point of service enrollment to PhilHealth',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility'],
            },
          ],
        },
        {
          type: 'field',
          field_name: 'Are TCL updated and completed showing defaulters?',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Barangay Health Station'],
        },
        {
          type: 'field',
          field_name: 'Is there enough cold chain equipment in the facility?',
          field_code: '1',
          response_type: 'y/n',
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.2',
      section_name: 'Demand Generation',
      section_description: 'Information, Education and Communication materials for demand generation',
      section_body: [
        {
          type: 'parent',
          field_name: 'Does your facility use IEC materials for the following programmes?',

          children: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Maternal Care',
              children: [
                {
                  type: 'field',
                  field_name: 'Leaflets/pamphlets',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Posters',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Flip Charts',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Models',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Videos',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Photographs',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Oral Health',
              children: [
                {
                  type: 'field',
                  field_name: 'Leaflets/pamphlets',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Posters',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Flip Charts',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Models',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Videos',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Photographs',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Family Planning',
              children: [
                {
                  type: 'field',
                  field_name: 'WHO Medical Eligibility Criteria (MEC) Wheel 5th Edition',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Flip chart in the facility',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'FP Posters in the facility',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'FP flyers in the facility',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'GATHER appproach Cue Card',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Newborn, child, and adolescent health',
              children: [
                {
                  type: 'field',
                  field_name: 'Healthy Young Ones Flipchart',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Is there advocacy materials on the National Immunization Program in the facility?',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
      ],
    },

    {
      type: 'section',
      section_number: '2.3',
      section_name: 'Physical Structure of Facility',
      section_body: [
        {
          type: 'field',
          field_name: 'Is there a clear sign bearing the name of the facility?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a sign indicating it is a PhilHealth provider?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a sign enumerating the services available?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a generally clean environment inside the facility?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Are there visible signs prohibiting smoking?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there sufficient seating for clients in a well-ventilated area?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there adequate lighting or naturally well-lighted?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there adequate clean water supply from a reliable source?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a consultation/examination room/cubicle with auditory and visual privacy available?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a Delivery Room with area for cleaning/resuscitation of newborn?',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility'],
        },
        {
          type: 'field',
          field_name: 'Is there an area for cleaning instruments?',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'Is there any room/s for patients awaiting delivery or while recovering?',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility'],
        },
        {
          type: 'field',
          field_name: 'Are there adequate signages (entrance, exits, laboratory, etc.)?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a functional toilet for in-patient use only (1 toilet: 6 beds)',
          field_code: '1',
          response_type: 'radio',
          options: [
            'Flush (or Pour Flush Toilet) to Piped Sewer System',
            'Flush to Septic Tank',
            'Flush to Pit Latrine',
            'Flush to Somewhere Else',
            'Flush, Don’t Know Where',
            'Ventilated Improved Pit Latrine',
            'Pit Latrine with Slab',
            'Open Pit',
            'Composting Toilet',
            'Bucket Toilet',
            'Hanging Toilet',
            'No Functioning Facility/Bush/Field',
          ],
        },
        {
          type: 'field',
          field_name: 'Is there a functional toilet for general out-patient use only?',
          field_code: '1',
          response_type: 'radio',
          options: [
            'Flush (or Pour Flush Toilet) to Piped Sewer System',
            'Flush to Septic Tank',
            'Flush to Pit Latrine',
            'Flush to Somewhere Else',
            'Flush, Don’t Know Where',
            'Ventilated Improved Pit Latrine',
            'Pit Latrine with Slab',
            'Open Pit',
            'Composting Toilet',
            'Bucket Toilet',
            'Hanging Toilet',
            'No Functioning Facility/Bush/Field',
          ],
        },
        {
          type: 'field',
          field_name: 'Are there separate toilets for males and females?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a ramp entrance?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Are there emergency escape plans posted in conspicuous places?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a reception area?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there a waiting area?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there an IEC area?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there an access to comfort room/lavatory?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Is there an area for record keeping?',
          field_code: '1',
          response_type: 'y/n',
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.4',
      section_name: 'Basic Supplies and Equipment',
      section_body: [
        {
          type: 'table',
          field_name:
            'I would like to know if the following items are available today in the main service area and are functioning.',
          field_code: '1',
          table_type: 'simple-table',
          columns: [
            'Observed and Functioning',
            'Observed but NOT Functioning',
            'Reported but NOT Seen',
            'Not Available',
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Adult Weighing Scale',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Child Weighing Scale (250 Gram Gradation)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Infant Weighing Scale (100 Gram Gradation)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Stadiometer (or Height Rod) For Measuring Height',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Thermometer',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Stethoscope',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Sphygmomanometer (Non-Mercury)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Light Source for examination (or equivalent)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Stretcher or Examining Table',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Wheelchair',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Mid-upper arm circumference tape (Adult)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Mid-upper arm circumference tape (Child)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Emergency/Alternative Light Source',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Wall Clock with Second Hand',
              field_code: '1',
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.5',
      section_name: 'Water, Sanitation and Hygiene (WASH) and Standard Precautions and Waste Management',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.5.1',
          section_name: 'Water',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Does the facility comply with the following WASH elements?',
              field_code: '1',
              columns: ['Observed', 'Reported, not seen', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Improved DRINKING WATER supply piped into facility or on premises.',
                  field_code: '1',
                  field_description: `Improved drinking water sources are as follows: Piped water into health facility or yard/ plot; Public tap or standpipe; Tube Well or borehole or protected well; improved spring; Rainwater from a cistern or tank; Packaged water - bottled water; Water from water refilling stations.
              Unimproved drinking water sources are unprotected well/ spring and surface water, water provided through tanker trucks.`,
                },
                {
                  type: 'field',
                  field_name: 'Improved water supply piped into the facility or on premises, with no leaks.',
                  field_code: '1',
                  field_description: `This refers to the water supply for general purposes, including washing and cleaning. Improved water sources are as follows: Piped water into health facility or yard/ plot; Public tap or standpipe; Tube Well or borehole; or protected well; improved spring; Rainwater from a cistern or tank; Packaged water - bottled water; Water from water refilling stations Unimproved water sources are unprotected well/ spring and surface water, water provided through tanker truck`,
                },
                {
                  type: 'field',
                  field_name: 'Shower and bathing areas are accessible and functioning',
                  field_code: '1',
                  field_description: `For BHS or RHU or UHC, with birthing facilities, at least 1 bathroom inside the labor room or ward. `,
                },
                {
                  type: 'field',
                  field_name: 'Water services available at all times and of sufficient quantity.',
                  field_code: '1',
                  field_description: `To calculate the facility’s water requirements, add up the following applicable national standards: 
                + Outpatients: 5 L/consultation 
                + Inpatients: 40–60 L/patient/day 
                + Operating theater or maternity unit: 100 L/intervention 
                
                `,
                },
                {
                  type: 'field',
                  field_name: 'Reliable drinking water station available ',
                  field_code: '1',
                  field_description: `This refers to a water station or water dispenser or water containers available at all times and accessible to all.`,
                },
                {
                  type: 'field',
                  field_name: 'Drinking water safe storage and has no E. Coli',
                  field_code: '1',
                  field_description: `This refers to a water dispenser or water containers with cover and tap.`,
                },
                {
                  type: 'field',
                  field_name: 'Water storage is sufficient.',
                  field_code: '1',
                  field_description: `To calculate the facility’s water requirement for a day, add up the following applicable national standards: 
                + Outpatients: 5 L/consultation 
                + Inpatients: 40–60 L/patient/day
                + Operating theatre or maternity unit: 100 L/intervention  
                
                `,
                },
                {
                  type: 'field',
                  field_name: 'Water supply has chlorine residual ',
                  field_code: '1',
                  field_description: `During an emergency period, a free residual chlorine (FRC) of 0.5mg/L min is required, as a general preventive measure for patient’s safety.
                In normal settings, bulk water supply shall maintain a free residual chlorine (FRC) level of 0.3 mg/L to a maximum of 1.5 mg/L at the point of delivery. (DOH PNSDW 2017) 
                `,
                },
                {
                  type: 'field',
                  field_name: 'Sufficient energy for water',
                  field_code: '1',
                  field_description: `On-site renewable energy generation or backup electricity generation that can power the facility’s emergency power needs.`,
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.2',
          section_name: 'Sanitation',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Does the facility comply with the following WASH elements?',
              field_code: '1',
              columns: ['Observed', 'Reported, not seen', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Sufficient number of functional toilets or latrines available.',
                  field_code: '1',
                  field_description:
                    'A toilet is defined as having a flush toilet following the standard septic tank design under the Code on Sanitation of the Philippines and DOH AO 2019-0047 (National Standard on the Design, Construction, Operation and Maintenance of Septic Tank System). It is also recommended that toilets be provided with a bidet. A latrine refers to pour flush systems that follow standard septic tank design. A functioning or usable toilet or latrine should have water available at all times.',
                },
                {
                  type: 'field',
                  field_name: 'Toilets or latrines separated for staff, patients, and visitors.',
                  field_code: '1',
                  field_description: `For primary care facilities, separate toilets for staff and patients are required for Rural Health Units or Urban Health Centers, with or without birthing facilities or TB-DOTS. No separate toilets for staff, patients and visitors are required in Barangay Health Stations, except in BHS with birthing facilities.`,
                },
                {
                  type: 'field',
                  field_name: 'Toilets or latrines separated for male and female.',
                  field_code: '1',
                  field_description: `For Rural Health Units or Urban Health Centers, with or without birthing facility or TB-DOTS, there should be at least 1 set of separate public toilets for males and females. In Barangay Health Stations, no separate public toilets for males and females are required.`,
                },

                {
                  type: 'field',
                  field_name: 'Menstrual hygiene management',
                  field_code: '1',
                  field_description: `Toilets should have a bin for disposal of waste and an area for washing, with water available.`,
                },
                {
                  type: 'field',
                  field_name: 'Toilet meeting the needs of people with reduced mobility.',
                  field_code: '1',
                  field_description: `For primary care facilities, at least one PWD toilet is required for BHS (with or without birthing facility), and RHU / UHC (with or without birthing facility or TB-DOTS). `,
                },
                {
                  type: 'field',
                  field_name: 'Functioning hand hygiene stations at latrines or toilets.',
                  field_code: '1',
                  field_description: `A functional hand hygiene station should have a sink or bucket with tap and water with soap. In settings where this is not possible, water “flowing” from a pre-filled container with a tap is preferable to still-standing water in a basin. Alcohol-based handrub is not suitable for use at latrines or toilets.`,
                },
                {
                  type: 'field',
                  field_name: 'Wastewater is safely managed.',
                  field_code: '1',
                  field_description: `Wastewater is safely managed through use of an on-site treatment facility that has been provided with a discharge permit by DENR or through use of a septic tank followed by a drainage pit or sent to a functioning sewer system. `,
                },
                {
                  type: 'field',
                  field_name: 'Greywater drainage system is safely managed.',
                  field_code: '1',
                  field_description: `Grey water (i.e. rainwater or wash water) drainage system is in place that diverts water away from the facility (i.e. no standing water) and also protects nearby households`,
                },
                {
                  type: 'field',
                  field_name: 'Toilets and latrines are adequately lit.',
                  field_code: '1',
                  field_description: `Toilet and latrines shall have an efficient and functional lightning at all times`,
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.3',
          section_name: 'Hygiene',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Does the facility comply with the following WASH elements?',
              field_code: '1',
              columns: ['Observed', 'Reported, not seen', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Functioning hand hygiene stations are available at all points of care.',
                  field_code: '1',
                  field_description: `Point of care is where three elements come together: the patient; the health care workers; and care or treatment involving contact with the patient or their surroundings. This may include consultation rooms, operating rooms, delivery rooms and laboratories. Hand hygiene stations should have a sink or bucket with tap, water and soap; or 70% alcohol-based handrub. In settings where tap water is not possible, water “flowing” from a pre-filled container with a tap is preferable to still-standing water in a basin. `,
                },
                {
                  type: 'field',
                  field_name: 'Hand hygiene promotion materials.',
                  field_code: '1',
                  field_description: `Key places include at points of care areas, the waiting room, at the facility’s entrance and within 5 meters of latrines or toilets.`,
                },
                {
                  type: 'field',
                  field_name: 'Functioning hand hygiene stations available in service areas.',
                  field_code: '1',
                  field_description: `Sink or bucket with tap, water and soap or 70% alcohol-based hand rub should be available 24/7. `,
                },
                {
                  type: 'field',
                  field_name: 'Functioning hand hygiene stations available in the waste disposal area.',
                  field_code: '1',
                  field_description: `Sink or bucket with tap and water with soap`,
                },
                {
                  type: 'field',
                  field_name: 'Hand hygiene compliance undertaken regularly.',
                  field_code: '1',
                  field_description: `Hand hygiene compliance refers to the practice of hand hygiene during five critical moments, as shown below, including during donning and removal of PPEs: 
                1- before touching a patient 
                2- before doing a clean / aseptic procedure 
                3- after touching body fluid / exposure risk 
                4- after touching a patient 
                5- after touching patient surroundings`,
                },
                {
                  type: 'field',
                  field_name: 'Staff can demonstrate correct procedures for hand washing.',
                  field_code: '1',
                  field_description: `Training to staff and protocol on hand hygiene technique being followed.`,
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.4',
          section_name: 'Health Care Waste Management',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Please tell me if the following resources/ supplies are available in this facility today.',
              field_code: '1',
              columns: ['Observed', 'Reported, not seen', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name: 'Clean Running Water (Piped, Bucket with Tap or Pour Pitcher)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Hand-Washing Soap (May Be Liquid Soap)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: '70% Isopropyl Alcohol',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Disposable Latex Gloves',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Waste Receptacle (Pedal Bin) With Lid and Plastic Liner',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Segregated, Properly Labelled Garbage Containers',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Sharps Container',
                  field_code: '1',
                },

                {
                  type: 'field',
                  field_name: 'Infectious Wastes Container',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Environmental Disinfectant (Alcohol, Chlorine) and Facility Cleaning Materials',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Auto-Disable Syringes',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Soaking Solution for Medical Instruments',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Autoclave or Sterilization Equipment',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Guidelines for Standard Precautions Posted',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Eye Protection (Goggles)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Medical Mask ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Sterile Drapes ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Surgical Cap',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Gown',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Trained person responsible for health care waste. ',
                  field_code: '1',
                  field_description: `Ensure training conducted to HCWM committee and other healthcare workers involved with HCWM`,
                },
                {
                  type: 'field',
                  field_name: 'Functional collection containers for each type of health care waste.  ',
                  field_code: '1',
                  field_description: `Pedal-operated waste collection bins with liners should be available at all waste generation points. In absence of pedal-operated waste bins, bins with swinging lids can be opted as the alternative. Otherwise, open waste containers are better than those which require touching the lid of the garbage container. `,
                },
                {
                  type: 'field',
                  field_name: 'Waste correctly segregated at all generation points ',
                  field_code: '1',
                  field_description: `Garbage container and plastic liners should follow the color-coded for various healthcare waste based on the latest HCWM Manual`,
                },
                {
                  type: 'field',
                  field_name: 'Hazardous and non-hazardous waste are stored separately  ',
                  field_code: '1',
                  field_description: `For primary care facilities, there should be a waste holding area located outside the building but within the site or premises.`,
                },
                {
                  type: 'field',
                  field_name: 'Infectious waste stored in protected area and treated within safe time period ',
                  field_code: '1',
                  field_description: `Unless a refrigerated storage room (at 3 to 8 degree Celsius) is available, storage times for infectious waste (e.g. the time between generation and treatment) should not exceed the following periods: 
                • 48 hours during the cold season 
                • 24 hours during the hot season`,
                },
                {
                  type: 'field',
                  field_name: 'Disposal of anatomical-pathological waste',
                  field_code: '1',
                  field_description: `In primary care facilities, placenta pit should be provided if birthing services are being offered in the facility. 
                Placenta pits: lined or unlined depending on the geology, with slab, with ventilation pipe; and should be more than 30m from water source. 
                SKIP THIS FOR Primary Care Facilities without inpatient beds`,
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name:
                    'Disposal of ash or residue from facilities using a thermal process or other alternative treatment methods   ',
                  field_code: '1',
                  field_description: `Ash pits: lined or unlined depending on the geology but must prevent leaching to the environment, with slab, bottom of pit at least 1.5 m away from groundwater table. If water gets into the ash pit, it can leach pollutants into the soil. `,
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Protocol or Standard Operating Procedure in place for health care waste ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Appropriate protective equipment for waste treatment and disposal  ',
                  field_code: '1',
                  field_description: `Protective equipment for people handling waste includes: gloves, apron, mask, heavy duty rubber boots. 
                `,
                },
              ],
            },
            {
              type: 'field',
              field_name: 'How does this facility process its medical equipment for re-use?',
              field_code: '1',
              response_type: 'radio',
              need_user_input: ['Process elsewhere'],
              options: [
                'Wash with soap and water Only',
                'Soak in chemical solution then wash with soap and water',
                'Sterilizer',
                'Autoclave',
                'Process elsewhere',
                'Don’t know',
              ],
            },
            {
              type: 'field',
              field_name: 'How does the facility finally dispose of its used sharps?',
              field_code: '1',
              response_type: 'radio',
              options: [
                'Incineration',
                'Open burning in protected area',
                'Dump without burning in protected area',
                'Remove offsite with protected storage',
                'Remove offsite and dump in general landfill',
                'Don’t know',
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.5.5',
          section_name: 'Environmental Cleaning',
          section_content: [
            {
              type: 'table',
              table_type: 'simple-table',
              field_name: 'Please tell me if the following resources/ supplies are available in this facility today.',
              field_code: '1',
              columns: ['Observed', 'Reported, not seen', 'Not Available'],
              rows: [
                {
                  type: 'field',
                  field_name:
                    'A clear and detailed facility (or ward) cleaning policy or protocol is clearly displayed, which is implemented and monitored.',
                  field_code: '1',
                  field_description: `Environmental surfaces or objects contaminated with blood, other body fluids, secretions or excretions are cleaned and disinfected as soon as possible using standard hospital disinfectants. Floors shall be made of materials that are non-slip, easy to clean, and resistant to chipping. A clean surface is noted by absence of waste, visible dirt, excreta, body fluid spills and insects.`,
                },
                {
                  type: 'field',
                  field_name: 'Appropriate and well-maintained materials for cleaning available',
                  field_code: '1',
                  field_description:
                    'There should be a designated physical space for storage, preparation, and care of cleaning supplies and equipment. Cleaning materials include: 1. Detergent or soap 2. Disinfectants, liquid bleach or chlorine granules or powder 3. Portable containers (e.g., bottles, pump dispenser, small buckets) 4. Surface cleaning cloths 5. Mops or floor cloths, with buckets/wringers 6. Pedal-operated (or swing lid) trash bins',
                },
                {
                  type: 'field',
                  field_name: 'Personal protective equipment available to all cleaning staff  ',
                  field_code: '1',
                  field_description: `Protective equipment for people cleaning the facility or handling waste includes gloves, mask, heavy duty rubber boots, goggles (if there is risk for splash); and, water-proof apron or cover-all. 
                `,
                },
                {
                  type: 'field',
                  field_name: 'Staff have received training on environmental cleaning. ',
                  field_code: '1',
                  field_description: `Demonstrate proper procedure in cleaning and disinfection of toilets, patients’ rooms and high-touch surfaces.`,
                },
                {
                  type: 'field',
                  field_name: 'Mechanism exists to track supply of IPC-related materials   ',
                  field_code: '1',
                  field_description: `IPC-related materials include PPEs, materials and supplies used for cleaning and disinfection and for hand hygiene. 
                `,
                },
                {
                  type: 'field',
                  field_name: 'Record of cleaning visible and signed by the cleaners each day ',
                  field_code: '1',
                  field_description: `Have a record for environmental cleaning and updated, checked and signed being visible to auspicious areas. 
                `,
                },
                {
                  type: 'field',
                  field_name: 'Laundry facilities are available',
                  field_code: '1',
                  field_description: `If laundry services are outsourced, there must be a means to confirm that they follow standard IPC measures 
                `,
                },
              ],
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.6',
      section_name: 'Service Specific Readiness',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.6.1',
          section_name: 'Antenatal Care',
          section_content: [
            {
              type: 'parent',
              field_name: 'Are the following services available in this facility as part of Antenatal Care services?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name:
                    'Antenatal physical examination including Leopold’s maneuver and fundic height measurement',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Iron and Folic acid supplementation + Calcium Carbonate',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Basic Oral Health Care',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Intermittent Preventive Treatment for Malaria (for endemic area only)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Tetanus Toxoid vaccination / Tetanus-diphtheria (Td) vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Monitoring for Hypertensive Disorder of Pregnancy',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on danger signs of pregnancy and importance of 4 prenatal visits',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on having a birth plan and facility-based delivery',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Health education regarding Newborn Screening (Blood and Hearing)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on Family Planning',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling about Maternal Nutrition and Infant and Young Child Feeding',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling about sexually transmitted infections from mother to child, including HIV',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Mental Health Screening',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'What is the schedule for delivery of antenatal care services in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Everyday', 'Once a week', 'Once a month', 'Other'],
            },
            {
              type: 'parent',
              field_name:
                'Are the following national guidelines, job-aids, checklist, and charts on antenatal care available in the facility today?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name:
                    'Quality Assurance Package (QAP) Manual / Pregnancy, Childbirth, Postpartum and Newborn Care (PCPNC) Manual',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Mother-Baby Book',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Maternal Health Record',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Visual Inspection using Acetic Acid (VIA)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Do you conduct the following diagnostic examinations in this facility at any time as part of Antenatal Care, and how often are they conducted?',
              field_code: '1',
              columns: [
                {
                  name: 'Do you conduct?',
                  type: 'radio',
                  code: '1',
                  options: ['Yes', 'No'],
                  trigger: ['No'],
                },
                {
                  name: 'How often?',
                  type: 'numeric',
                  code: '2',
                  default: ['0'],
                },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Hemoglobin determination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Urine dipstick test',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Urinalysis',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Urine glucose',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Blood glucose',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Blood typing',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Malaria rapid diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Syphilis rapid diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Hepatitis B diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'HIV rapid diagnostic test',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Are individual client records (Maternal Health Record) for antenatal care maintained in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records kept'],
            },
            {
              type: 'field',
              field_name: 'Does this facility use any form of pregnancy tracking tool (e.g Community Tracking Tool)',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.2',
          section_name: 'Delivery Services',
          section_content: [
            {
              type: 'parent',
              field_name:
                'Do you conduct the following diagnostic examinations in this facility at any time as part of Antenatal Care?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Monitoring and Management of Labor using Partograph',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Thermal Protection, Immediate Drying and Skin-to-Skin Contact',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Delayed Cord Cutting',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Hygienic Cord Care',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Immediate and Exclusive Breastfeeding',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Normal Delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Assisted Vaginal Delivery, including imminent Breech Delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Administration of Uterotonic (e.g. Oxytocin) Drug',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Manual Removal of Placenta',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Removal of Retained Products after Delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Administration of Corticosteroids for Pre-Term Labor',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Administration of Intravenous Antibiotics',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Administration of Anticonvulsant',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Basic Emergency Obstetric Care',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Neonatal Resuscitation',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
              ],
            },
            {
              type: 'parent',
              field_name:
                'Are the following national guidelines, job-aids, checklist, charts for delivery services in the facility today?',
              field_code: '1',
              applicable: ['Safe Birthing Facility', 'Infirmary'],
              children: [
                {
                  type: 'field',
                  field_name: 'EINC Clinical Practical Pocket Guide',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
              ],
            },
            {
              type: 'parent',
              field_name: 'Does this facility have the following health personnel full time or on call 24/7?',
              field_code: '1',
              applicable: ['Safe Birthing Facility', 'Infirmary'],
              children: [
                {
                  type: 'field',
                  field_name: 'Physician trained in Basic Emergency Obstetric and Neonatal Care',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'PhilHealth Accredited Professional Provider (Midwife/Doctor)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Bachelor of Science in Midwifery (Midwife with Diploma)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Does this facility have maternal clinical charts with properly accomplished consent forms and ICD-10 coded medical diagnosis and procedures performed?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records'],
              applicable: ['Safe Birthing Facility', 'Infirmary'],
            },
            {
              type: 'field',
              field_name:
                'Does this facility have newborn patient charts with properly and completely filled out birth certificate forms?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records'],
              applicable: ['Safe Birthing Facility', 'Infirmary'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.3',
          section_name: 'Postnatal Care',
          section_content: [
            {
              type: 'parent',
              field_name:
                'Are the following routinely (always, for every client) carried out by providers in this facility as part of postnatal care?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Hemoglobin postnatal',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Iron supplementation',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Vitamin A supplementation',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup at 24 hours after delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup at 48-72 hours after delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup within 1 week of delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Postpartum checkup within 4-6 weeks of delivery',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Blood pressure monitoring postpartum',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on family planning',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Counseling on breastfeeding',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_name:
                'Are the following national guidelines, job-aids, checklist, and charts for postpartum care in the facility today?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Early Childhood Care and Development Card',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'MNIYCF Job Aid',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Do you have a Maternal Health Record for postpartum visits with schedule of visits?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records'],
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.4',
          section_name: 'Newborn Care',
          section_content: [
            {
              type: 'parent',
              field_name:
                'Are the following procedures routinely performed by providers of newborn care in this facility?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Vitamin K injection',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Eye prophylaxis',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Hepatitis B injection within 24 hours of life',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'BCG injection within 24 hours of life',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Weighing of the newborn and measurement of length (anthropometrics)',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Physical examination of the baby',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Antibiotics for Babies whose mothers had Premature Rupture of Membranes',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Antibiotics for Meconium-Stained Babies',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Parenteral Antibiotics for Neonatal Sepsis',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Newborn Screening / Expanded Newborn Screening',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Newborn Hearing Screening',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Apgar Scoring',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Ballard Scoring',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_name:
                'Are there any newborn care national guidelines, job-aids, charts, checklist, posters in this facility today?',
              field_code: '1',
              applicable: ['Safe Birthing Facility', 'Infirmary'],
              children: [
                {
                  type: 'field',
                  field_name: 'EINC Clinical Practical Pocket Guide or equivalent',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.5',
          section_name: 'Family Planning',
          section_content: [
            {
              type: 'parent',
              field_name: 'Are the following services available in the facility as part of Family Planning services?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Counselling on Family Planning',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Combined oral contraceptive pills (COC)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Progestin only contraceptive pills (POP)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Depot-Medroxyprogesterone Acetate (DMPA)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Male condom',
                  field_code: '1',

                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Interval IUD insertion ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Interval IUD removal ',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Postpartum IUD (PPIUD) insertion and removal',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Progesterone Subdermal Implant (PSI) insertion & removal, and reinsertion',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Provision of Natural Family Planning (NFP) services',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Is the FP Form 1 for family planning available in the facility today?',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Are individual records or cards maintained in this facility for family planning clients?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.6',
          section_name: 'Child Vaccination',
          section_content: [
            {
              type: 'parent',
              field_name:
                'Are the following child vaccination services offered in this facility as part of Child Health services?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'BCG Vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'DPT-Hib-HepB (Pentavalent) Vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Inactivated Polio Vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Oral Polio Vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Pneumococcal Conjugate Vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Rotavirus Vaccination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Measles-Rubella (MR) / Measles, Mumps, and Rubella (MMR) Vaccination',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'What is the schedule for vaccinations in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Everyday', 'Once a week', 'Once a month', 'Other'],
            },
            {
              type: 'field',
              field_name:
                'Is there a national guideline, job-aids, checklist, charts on Expanded Program on Immunization/National Immunization Program (e.g. Basic EPI Manual) in the facility today?',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name:
                'Are individual child vaccination cards or booklets (Child Health Record) maintained in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records kept'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.7',
          section_name: 'Child Growth Monitoring Services',
          section_content: [
            {
              type: 'parent',
              field_name: 'Are Child Growth Monitoring services offered in this facility?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Measurement of weight',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Measurement of height',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Measurement of mid-upper arm circumference (MUAC)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'What is the schedule for conducting child growth monitoring in this facility',
              field_code: '1',
              response_type: 'radio',
              options: ['Daily/Weekly', 'Monthly/Quarterly', 'Annual/Semi-annual', 'Other'],
            },
            {
              type: 'field',
              field_name:
                'Are any national guidelines, job-aids, checklist, and charts for growth monitoring (e.g. Child Growth Standards Manual) in the facility today?',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Are individual child records for growth monitoring maintained in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records kept'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.8',
          section_name: 'Child Preventive And Curative Services',
          section_content: [
            {
              type: 'parent',
              field_name:
                'Are the following carried out in this facility as part of child preventive and curative care services?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name:
                    'Diagnosis and/or treatment of Pneumonia, Diarrhea, Dengue, and Measles (e.g. Provision of ORS + Zinc) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis and/or treatment of Malaria',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name:
                    'Diagnosis and/or treatment of Malnutrition (Moderate Acute Malnutrition and Severe Acute Malnutrition) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Basic Oral Health Care',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Vitamin A supplementation to children',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Iron supplementation to low-birthweight infants',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Iron supplementation for children (6-11 months) with anemia',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Provide Zinc supplementation to sick children with diarrhea',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis and/or treatment of TB in children / Isoniazid Preventive Therapy',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Deworming',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Micronutrient (Vitamin A, Iron and Iodine) supplementation to children',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'What is the schedule for delivery of child preventive and curative care services in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Everyday', 'Once a week', 'Once a month', 'Other'],
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'parent',
              field_name: 'Are the following national guidelines available in the facility today?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Integrated Management of Child Illness Chart Booklet',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Micronutrient Supplementation Program Manual of Operations',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Infant and Young Child Feeding Manual',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Philippine Integrated Management of Acute Malnutrition (PIMAM) Guidelines',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name:
                    'Guidelines in the Implementation of Oral Health Program for Public Health Services in the Philippines',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'parent',
              field_name:
                'Do you conduct the following diagnostic examinations in this facility at any time as part of child preventive and curative care services? ',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Hemoglobin determination ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Test parasite in stool (general microscopy) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Malaria diagnostic capacity',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name:
                'Are individual child records (Child Health Record) for management of childhood illnesses maintained in this facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, observed', 'Reported, not observed', 'No records kept'],
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.9',
          section_name: 'Adolescent Health Services',
          section_content: [
            {
              type: 'parent',
              field_name:
                'Are the following services available in this facility as part of Adolescent Health Services?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name:
                    'Education and counselling on health effects of tobacco/smoking, diet, oral hygiene, and Adolescent Sexual and Reproductive Health (ASRH) (RHU/BHS/School) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Basic Oral Health Care Services',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'HIV and STI services',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Promotion of healthy diets, nutrition counselling and assessment of nutritional status',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },

            {
              type: 'parent',
              field_name:
                'Are the following national guidelines, job-aids, checklist, charts on adolescent health services in the facility today?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Adolescent Job Aid (AJA) Manual',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name:
                    'Adolescent Health Care for Primary Health Service Providers - Foundational Course Manual',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Is there an adolescent-friendly space designated in the facility?',
              field_code: '1',
              response_type: 'radio',
              options: ['Yes, Level 1', 'Yes, Level 2', 'Yes, Level 3', 'Processing', 'No'],
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name:
                'What is the reason for not having a designated adolescent-friendly space in the facility? Write "N/A" if there is one.',
              field_code: '1',
              response_type: 'text',
              options: ['Yes, Level 1', 'Yes, Level 2', 'Yes, Level 3', 'Processing', 'No'],
              applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name:
                'Are the health workers practicing minimum health standards like wearing of Face mask during provision of services for adolescents?',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.6.10',
          section_name: 'Referral',
          section_content: [
            {
              type: 'parent',
              field_name: 'Does this facility have referral forms and compile return referrals for:',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Antenatal care - Sexually transmitted infections',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Antenatal care - Laboratory',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Antenatal care - Ultrasound',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Postnatal care',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Newborn care',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Family planning',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Child and adolescent health services',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'parent',
              field_name: 'Does the facility refer high risk patients to higher facilities for delivery services?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Referral form',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Transport (accredited ambulance and driver)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Memorandum of Agreement/Understanding or policy',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '2.7',
      section_name: 'Equipment, Instruments, and Other Fixtures',
      section_body: [
        {
          type: 'sub-section',
          section_number: '2.7.1',
          section_name: 'Antenatal Care',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Tape measure',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Fetal Doppler',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Examination table with/without stirrups',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Digital thermometer',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Ultrasound Machine',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'For Basic Instruments for Oral Health, please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Mouth Mirror',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Explorer',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Cotton Pliers',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Excavator',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Filling Instruments',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Forceps',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'For Essential Supplies/Materials for Oral Health, please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Treatment Records Forms',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Cotton',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Prophy Brushes',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Gloves',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Burs',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Anesthesia',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Needles',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Permanent Filling Materials',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Temporary Filling Materials',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Medicines',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.7.2',
          section_name: 'Delivery Services',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Pulse Oximeter (Pedia/Adult)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Stethoscope, for Pediatric Use',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Delivery Table with pail',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Newborn Resuscitation Table or equivalent ',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Examination or Patient Bed w/ clean sheets/linen and footstoo',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name:
                    'Delivery Pack (Consists of 2 Hemostat Forceps, 1 Needle Holder, 1 Surgical Scissor, 1 Tissue Forceps)',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Bandage scissors',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Thumb forceps',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Umbilical cord scissors',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name:
                    'Disposable delivery kit (sterile cord clip or ties, plastic sheet to place under mother and sterile blade)',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Instrument Tray with Cover',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Kidney basin',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Instrument Cabinet',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Instrument Table or equivalent ',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Storage Containers with Cover for Dry Cotton Balls',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Jar with cover and without cover ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Vaginal speculum (medium or large)',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Sponge Forceps',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Suction Apparatus',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Suction catheter (adult and newborn sizes) ',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Rubber Suction Bulb / Penguin',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Ambu bag or self-inflating bag (adult and pediatric)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Oxygen Tank with Regulator and Humidifier ',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Cone Mask, may be improvised ',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Newborn Size Mask 0 and 1',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Nebulizer (portable) ',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Examination Light (Gooseneck Lamp or equivalent)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Room Thermometer',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'IV Stand or equivalent',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Thermometer, Non-Mercury',
                  field_code: '1',
                },

                {
                  type: 'field',
                  field_name: 'Tape Measure',
                  field_code: '1',
                },

                {
                  type: 'field',
                  field_name: 'Wall Clock with Seconds hand',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Slippers for use in Delivery Area',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Bench',
                  field_code: '1',
                },

                {
                  type: 'field',
                  field_name: 'Cabinet',
                  field_code: '1',
                },

                {
                  type: 'field',
                  field_name: 'Chair',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Desk',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Electric fan',
                  field_code: '1',
                },

                {
                  type: 'field',
                  field_name: 'Autoclave/Steam sterilizer or its equivalent',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Emergency light/ flashlight',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.7.3',
          section_name: 'Newborn Care',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Apgar and Ballard Scoring Chart',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Drying rack',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Newborn Screening (NBS) filter card',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.7.4',
          section_name: 'Family Planning',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'BP Apparatus',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Tenaculum Forceps',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Mayo Scissors',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Placental Forceps',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: '10” Ovum Forceps ',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: '10” Straight Forceps ',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: '10” Narrow or “Alligator” Forceps',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Uterine Sound',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Vaginal Speculum, Different Sizes',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Kelly Pad',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Gooseneck Lamp (or equivalent)',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Printed materials/ posters for patient education',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Scalpel Blade holder for no. 2',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Scalpel Blade no. 11',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Mosquito Forcep',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Progestin Subdermal Implant (PSI) Ancillary kit',
                  field_code: '1',
                  applicable: ['Safe Birthing Facility', 'Infirmary'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.7.5',
          section_name: 'Child Vaccination',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'EPI monitoring chart',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Vaccine carriers',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Ice packs',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Cold-Chain Temperature Monitoring Chart',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Vaccine refrigerator or freezer',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Temperature monitoring devices (thermometer)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Sharps container (“safety box”)',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.7.6',
          section_name: 'Child Monitoring Services',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Height or Length board',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '2.7.7',
          section_name: 'Child Preventive and Curative Care Services',
          section_content: [
            {
              type: 'table',
              field_name:
                'Please tell/show me if the following medical equipment and instruments are available in the facility today.',
              field_code: '1',
              table_type: 'simple-table',
              columns: [
                'Observed and Functioning',
                'Observed but NOT Functioning',
                'Reported but NOT Seen',
                'Not Available',
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Pediatric BP apparatus',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Other device (e.g. cellphone) that can measure seconds',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Dental Chair',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Air Compressor',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Ultrasonic Scaler',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Light Curing Machine',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Dental Instruments',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Calibrated ½ or 1-liter measuring jar for ORS',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Oxygen tank with regulator and humidifier',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Nebulizer',
                  field_code: '1',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
