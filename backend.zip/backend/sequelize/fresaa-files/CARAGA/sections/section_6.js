module.exports = {
  section_number: 6,
  section_name: 'Health Information System',
  section_description: `Sound and reliable information is the foundation of decision-making across all health system building blocks. It is essential for health system policy development and implementation, governance and regulation, health research, human resources development, health education and training, service delivery and financing`,
  section_body: [
    {
      type: 'sub-section',
      section_number: '6.1',
      section_name: 'Electronic Medical Records (EMR)',
      section_content: [
        {
          type: 'conditional-field',
          field_name: 'Are Electronic Medical Records (EMR) present in the facility?',
          field_code: '1',
          response_type: 'y/n',
          applicable: [
            'Infirmary',
            'Safe Birthing Facility',
            'Rural Health Unit',
            'Barangay Health Station',
            'City Health Office',
          ],
          children: [
            {
              type: 'field',
              field_name: 'Name of EMR',
              field_code: '1',
              response_type: 'text',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'field',
              field_name: 'Name of Health Information Technology Provider',
              field_code: '1',
              response_type: 'text',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'parent',
              field_name: 'Does the EMR have these functionalities?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Patients Consultation Recording',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Inventory of Logistics',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Environmental',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Financial for PhilHealth Claims',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
            {
              type: 'field',
              field_name: 'Does the facility submit reports to PhilHealth through EMR (utilizing eClaims functions)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'parent',
              field_name: 'IP Monitoring',
              field_code: '1',
              children: [
                {
                  type: 'conditional-field',
                  field_name: 'Does the facility utilize EMR for household profiling?',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'City Health Office'],
                  children: [
                    {
                      type: 'field',
                      field_name: 'Provide the Household Profiling template used',
                      field_code: '1',
                      response_type: 'text',
                    },
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Is this data submitted for regional level analysis?',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Yes', 'No', 'Not Applicable'],
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
              ],
            },
          ],
        },
        {
          type: 'table',
          field_name: 'Types of PhilHealth Claims',
          field_code: '1',
          columns: [
            {
              name: 'Is claiming of PhilHealth packages available within the facility?',
              type: 'y/n',
              code: '1',
              trigger: ['No'],
            },
            {
              name: 'Name of the system used',
              type: 'text',
              code: '2',
              default: ['N/A'],
            },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'E-Konsulta',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Maternal Care Package (MCP)',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'TB-DOTS',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Animal Bite Package',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'Family Planning Claims',
              field_code: '1',
            },
            {
              type: 'field',
              field_name: 'COVID Isolation Claims',
              field_code: '1',
            },
          ],
        },
        {
          type: 'parent',
          field_name: 'FHSIS Reporting',
          field_code: '1',
          children: [
            {
              type: 'field',
              field_name: 'Does the facility submit FHSIS reports to DOH through EMR?',
              field_code: '1',
              response_type: 'y/n',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'parent',
              field_name: 'Are there any other reporting tools present?',
              field_code: '1',
              children: [
                {
                  type: 'field',
                  field_name: 'Target Client List (TCL) ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Summary Table ',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: [
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Others 1 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Others 2 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Others 3 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Others 4 (Pls. specify) ',
                  field_code: '1',
                  response_type: 'text',
                },
              ],
            },
          ],
        },
        {
          type: 'parent',
          field_name: 'Presence of Telemedicine',
          field_code: '1',
          children: [
            {
              type: 'conditional-field',
              field_name: 'Is telemedicine available in the facility?',
              field_code: '1',
              response_type: 'y/n',
              children: [
                {
                  type: 'field',
                  field_name: 'Name of provider',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'parent',
                  field_name: 'Is this technology utilized in telemedicine',
                  field_code: '1',
                  children: [
                    {
                      type: 'field',
                      field_name: 'in-house web-application',
                      field_code: '1',
                      response_type: 'y/n',
                    },

                    {
                      type: 'field',
                      field_name: 'SMS/call',
                      field_code: '1',
                      response_type: 'y/n',
                    },

                    {
                      type: 'field',
                      field_name: 'Video Conferencing',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'social-media',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'web-application',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                  ],
                },
              ],
            },
          ],
        },
        {
          type: 'parent',
          field_name: 'Presence/Utilization of Other DOH Information Systems ',
          field_code: '1',
          children: [
            {
              type: 'field',
              field_name: 'Online Malaria Information System (OLMIS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Integrated Tuberculosis Information System (ITIS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'National Rabies Information System (NaRIS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Philippine Registry for Persons with Disability (PRPWD)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Health Emergency Allowance Processing System (HEAPS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Electronic Logistic Management Information System (eLMIS)',
              field_code: '1',
              response_type: 'y/n',
            },
            {
              type: 'field',
              field_name: 'Online National Electronic Injury Surveillance System (ONEISS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Philippine Integrated Disease Surveillance and Response (PIDSR)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'National BHW Registry System (NBHWRS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'LGU Health Scorecard Information System (LGUHSC IS)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Health Facility Profile - DOH Data Collect Hub (HFPDDC)',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Rural Health Unit', 'City Health Office'],
            },
          ],
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '6.2',
      section_name: 'Human Resources for ICT',
      section_content: [
        {
          type: 'table',
          field_name: 'Human Resources for ICT',
          field_code: '1',
          columns: [
            {
              name: 'Total Personnel',
              type: 'numeric',
              code: '1',
              trigger: [0],
            },
            {
              name: '# Regular Personnel',
              type: 'numeric',
              code: '2',
              default: ['0'],
            },
            {
              name: '# Contractual/Job Order Personnel ',
              type: 'numeric',
              code: '3',
              default: ['0'],
            },
            {
              name: 'Source of Fund',
              type: 'parent',
              children: [
                { name: 'LGU', type: 'y/n', code: '4', default: ['No'] },
                { name: 'DOH', type: 'y/n', code: '5', default: ['No'] },
                { name: 'Province', type: 'y/n', code: '6', default: ['No'] },
                { name: 'NGO', type: 'y/n', code: '7', default: ['No'] },
              ],
            },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Presence of dedicated ICT personnel primarily functioning on EMR.',
              field_code: '1',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'field',
              field_name: 'Presence of designated personnel primarily functioning as Data Privacy Officer',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
          ],
        },
      ],
    },

    {
      type: 'sub-section',
      section_number: '6.3',
      section_name: 'ICT Equipment and Infrastructure',
      section_content: [
        {
          type: 'sub-section',
          section_number: '6.3.1',
          section_name: 'ICT Equipment',
          section_content: [
            {
              type: 'table',
              field_name: 'Are the following items available in the facility?',
              field_code: '1',
              columns: [
                {
                  name: 'Count',
                  type: 'numeric',
                  code: '1',
                  trigger: [0],
                },
                {
                  name: 'Source of Fund',
                  type: 'parent',
                  code: '2',
                  children: [
                    { name: 'LGU', type: 'y/n', code: '2', default: ['No'] },
                    { name: 'DOH', type: 'y/n', code: '3', default: ['No'] },
                    { name: 'Province', type: 'y/n', code: '4', default: ['No'] },
                    { name: 'NGO', type: 'y/n', code: '5', default: ['No'] },
                  ],
                },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Desktop',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Laptop',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Scanner',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Printer',
                  field_code: '1',
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '6.3.2',
          section_name: 'Presence of Internet Service Provider',
          section_content: [
            {
              type: 'conditional-field',
              field_name: 'Is the internet available in the facility?',
              field_code: '1',
              response_type: 'y/n',
              children: [
                {
                  type: 'field',
                  field_name: 'Name of Internet Service Provider',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'field',
                  field_name: 'Internet Speed',
                  field_code: '1',
                  response_type: 'text',
                },
                {
                  type: 'parent',
                  field_name: 'Source of Fund',
                  field_code: '1',
                  children: [
                    {
                      type: 'field',
                      field_name: 'LGU',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'DOH',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'Province',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                    {
                      type: 'field',
                      field_name: 'NGO',
                      field_code: '1',
                      response_type: 'y/n',
                    },
                  ],
                },
              ],
            },
            {
              type: 'field',
              field_name: ' Is there a presence of a Local Area Network (LAN), and what is the type of topology?',
              field_code: '1',
              response_type: 'radio',
              options: ['WiFi', 'LAN-cabling', 'LAN and WiFi', 'Not available'],
            },
          ],
        },
      ],
    },
  ],
};
