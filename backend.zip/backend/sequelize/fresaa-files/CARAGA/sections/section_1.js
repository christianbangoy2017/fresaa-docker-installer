module.exports = {
  section_number: 1,
  section_name: 'Leadership, Governance and Policy',
  section_body: [
    {
      type: 'sub-section',
      section_number: '1.1',
      section_name: 'DOH Policies, Certification, Ordinances, Executive Orders, and Resolutions',
      section_content: [
        {
          type: 'parent',
          field_name:
            'Please tell me if the Municipality/City/barangay has ordinances, executive orders, or resolutions pertaining to the following:',

          children: [
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Maternal Care & Oral Health',
              children: [
                {
                  type: 'field',
                  field_name: 'BEMONC certified only',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'License to Operate as birthing facility',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Mother-Baby Friendly Facility (for hospital and birthing facility)',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Maternal, Neonatal, Child Health and Nutrition (MNCHN) Policy',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Safe Motherhood and/or Facility-based Deliveries',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Contraceptive Self-Reliance Policy',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: ' Breastfeeding and/or Milk Code',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'PhilHealth enrollment of women about to give birth',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'COVID-19 Policies on Maternal Health',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'FP Clinical Standards Manual (2014 Edition)',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Copy of National Policy on Oral Health Care',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Copy of OHP Implementing Guidelines and Procedures',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Are there any local ordinances enacted/passed for oral health',
                  field_code: '1',
                  response_type: 'y/n',
                },
              ],
            },
            {
              type: 'parent',
              field_code: '1',
              field_name: 'Newborn, Child, and Adolescent Health',
              children: [
                {
                  type: 'field',
                  field_name: 'Newborn Screening',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Infirmary', 'Safe Birthing Facility'],
                },
                {
                  type: 'field',
                  field_name: 'Is there an available micro plan and session plan for routine immunization',
                  field_code: '1',
                  response_type: 'y/n',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name:
                    'Are there national guidelines, memos, advisories, monitoring tools, Manual of Operation on National Immunization Program in the facility?',
                  field_code: '1',
                  response_type: 'y/n',
                },
                {
                  type: 'field',
                  field_name: 'Is the facility certified as Adolescent-Friendly?',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Level 1', 'Level 2', 'Level 3', 'Processing', 'No'],
                },
                {
                  type: 'field',
                  field_name: 'Is there an existing AHDP Policy in the LGU?',
                  field_code: '1',
                  response_type: 'radio',
                  options: ['Ordinance with IRR', 'Ordinance only', 'MOP', 'Processing', 'No'],
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '1.2',
      section_name: 'PhilHealth accreditation',
      section_content: [
        {
          type: 'parent',
          field_name: 'PhilHealth accreditation',
          field_code: '1',
          children: [
            {
              type: 'field',
              field_name: 'Konsulta Package Provider',
              field_code: '1',
              response_type: 'y/n',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'field',
              field_name: 'Maternity Care Package',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Newborn Care Package',
              field_code: '1',
              response_type: 'y/n',
              applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Family Planning Package',
              field_code: '1',
              response_type: 'y/n',
            },
          ],
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '1.3',
      section_name: 'Maternal Neonatal and Infant Death Review and Reporting Systems',
      section_content: [
        {
          type: 'field',
          field_name: 'Does the facility implement the Maternal Death Review and Reporting System (MDRRS)?',
          field_code: '1',
          response_type: 'y/n',
        },
        {
          type: 'field',
          field_name: 'Does the facility use the Maternal, Neonatal and Infant Death Reporting System (MNIDRS)?',
          field_code: '1',
          response_type: 'y/n',
        },
      ],
    },
  ],
};
