module.exports = {
  section_number: 7,
  section_name: 'Outcome Indicators',
  section_body: [
    {
      type: 'sub-section',
      section_number: '7.1',
      section_name: 'MNCHN-related Impact/Outcome Indicators',
      section_content: [
        {
          type: 'field',
          field_name: 'How many maternal deaths were registered in the past completed year?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
        },

        {
          type: 'field',
          field_name: 'Of those who were registered, how many deaths were reviewed?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'How many neonatal deaths aged 0-28 days were registered in the past completed year?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'Of those who were registered, how many deaths were reviewed?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'How many infant deaths (< 1 year of age) were registered in the past completed year?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'Of those who were registered, how many deaths were reviewed?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'How many child deaths aged 12-59 months were registered in the past completed year?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
        },
        {
          type: 'field',
          field_name:
            ' How many children 0-59 months who have manifested low weight for height (wasting) were recorded in the current year?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
        },

        {
          type: 'field',
          field_name:
            ' How many children 0-59 months who have severe acute malnutrition (SAM) were recorded in the current year? ',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
        },
        {
          type: 'field',
          field_name:
            ' How many children 0-59 months who have manifested low height for age (stunting) were recorded in the current year?',
          field_code: '1',
          response_type: 'numeric',
          applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'Availability of Emergency Transport 24/7',
          field_code: '1',
          response_type: 'y/n',
          applicable: [
            'Infirmary',
            'Safe Birthing Facility',
            'Rural Health Unit',
            'Barangay Health Station',
            'City Health Office',
          ],
        },
      ],
    },
  ],
};
