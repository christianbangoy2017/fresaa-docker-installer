module.exports = {
  section_number: 8,
  section_name: 'Health Regulation',
  section_body: [
    {
      type: 'sub-section',
      section_number: '8.1',
      section_name: 'DOH Licensing',
      section_content: [
        {
          type: 'field',
          field_name: 'Safe Birthing Facility',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility'],
        },
        {
          type: 'field',
          field_name: 'NBS',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
        },
        {
          type: 'field',
          field_name: 'FP',
          field_code: '1',
          response_type: 'y/n',
          applicable: [
            'Infirmary',
            'Safe Birthing Facility',
            'Rural Health Unit',
            'Barangay Health Station',
            'City Health Office',
          ],
        },
        {
          type: 'field',
          field_name: 'Konsulta Package',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
        },
      ],
    },
    {
      type: 'sub-section',
      section_number: '8.2 ',
      section_name: 'PHIC Accreditation',
      section_content: [
        {
          type: 'field',
          field_name: 'Safe Birthing Facility',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility'],
        },
        {
          type: 'field',
          field_name: 'NBS',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Safe Birthing Facility'],
        },
        {
          type: 'field',
          field_name: 'FP',
          field_code: '1',
          response_type: 'y/n',
          applicable: [
            'Infirmary',
            'Safe Birthing Facility',
            'Rural Health Unit',
            'Barangay Health Station',
            'City Health Office',
          ],
        },
        {
          type: 'field',
          field_name: 'Konsulta Package',
          field_code: '1',
          response_type: 'y/n',
          applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
        },
      ],
    },
  ],
};
