module.exports = {
  section_number: 3,
  section_name: 'Health Workforce',
  section_description: `The health workforce can be defined as “all people engaged in actions whose primary intent is to enhance health” (WHO, 2010). These human resources include clinical staff, such as physicians, nurses, pharmacists and dentists, as well as management and support staff, i.e. those who do not deliver services directly but are essential to the performance of health systems, such as managers, ambulance drivers and accountants.`,
  has_subsection: true,
  section_body: [
    {
      type: 'section',
      section_number: '3.1',
      section_name: 'Health Care Personnel',
      section_body: [
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, on the basis of the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            {
              name: 'Full Time',
              type: 'parent',
              children: [
                { name: 'Plantilla', type: 'numeric', code: '1' },
                { name: 'Job Order / Casual', type: 'numeric', code: '2' },
                { name: 'Deployed by DOH', type: 'numeric', code: '3' },
              ],
            },
            { name: 'Part time', type: 'numeric', code: '4' },
            { name: 'Volunteer', type: 'numeric', code: '5' },
            {
              name: '# of hours in a facility per month',
              type: 'numeric',
              code: '6',
            },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Generalist Medical Doctors (Non-Specialist)',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office', 'Safe Birthing Facility'],
            },
            {
              type: 'field',
              field_name: 'Registered Midwife',
              field_code: '1',
              applicable: [
                'Infirmary',
                'Safe Birthing Facility',
                'Rural Health Unit',
                'Barangay Health Station',
                'City Health Office',
              ],
            },
            {
              type: 'field',
              field_name: 'Medical Technologist',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
          ],
        },
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, on the basis of the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            {
              name: 'Full Time',
              type: 'parent',
              children: [
                { name: 'Plantilla', type: 'numeric', code: '1' },
                { name: 'Job Order / Casual', type: 'numeric', code: '2' },
                { name: 'Deployed by DOH', type: 'numeric', code: '3' },
              ],
            },
            { name: 'Part time', type: 'numeric', code: '4' },
            {
              name: '# of hours in a facility per month',
              type: 'numeric',
              code: '6',
            },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Registered Nurse',
              field_code: '1',
              applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Registered Pharmacist',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Dentist',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
          ],
        },
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, on the basis of the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            { name: 'Plantilla', type: 'numeric', code: '1' },
            { name: 'Job Order / Casual', type: 'numeric', code: '2' },
            { name: 'Deployed by DOH', type: 'numeric', code: '3' },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Dental Aide',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Ambulance Driver / Emergency Transport Driver',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Nutritionist / Dietician',
              field_code: '1',
              applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
            },
          ],
        },
        {
          type: 'table',
          field_name:
            'I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, on the basis of the highest technical or professional qualification.',
          field_code: '1',
          columns: [
            { name: 'Volunteer', type: 'numeric', code: '5' },
            {
              name: '# of hours in a facility per month',
              type: 'numeric',
              code: '6',
            },
          ],
          rows: [
            {
              type: 'field',
              field_name: 'Active Barangay Health Worker (BHW)',
              field_code: '1',
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Barangay Nutrition Scholar (BNS)',
              field_code: '1',
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
            {
              type: 'field',
              field_name: 'Community Health Volunteers (Who Are Not BHW)',
              field_code: '1',
              applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
            },
          ],
        },
        {
          type: 'field',
          field_name:
            'Is there a health service provider present at all times, or officially on call for the facility at all times (24hrs a day including weekends) for emergencies and/or deliveries?',
          field_code: '1',
          response_type: 'radio',
          options: [
            'Yes, schedule is posted publicly',
            'Yes, but no schedule/list is posted',
            'No 24 hrs staff',
            'Don’t know',
          ],
          applicable: [
            'Infirmary',
            'Safe Birthing Facility',
            'Rural Health Unit',
            'Barangay Health Station',
            'City Health Office',
          ],
        },
        {
          type: 'field',
          field_name: 'On average, how many hours is this facility open?',
          field_code: '1',
          response_type: 'radio',
          options: [
            '24 hrs, 7 days a week',
            '24 hrs, 5 days a week (close weekends)',
            '8 hrs/day, 5 days a week (40 hrs) ',
            '2-4 days per week (<40hrs)',
            '2-4 days per month',
            'Once a month',
          ],
        },
      ],
    },
    {
      type: 'section',
      section_number: '3.2',
      section_name: 'Health Care Personnel Trainings',
      section_body: [
        {
          type: 'sub-section',
          section_number: '3.2.1',
          section_name: 'Antenatal Care',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Others', type: 'numeric', code: '5' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Interpersonal Communication Skills (ICS)',
                  field_code: '1',
                },
                {
                  type: 'field',
                  field_name: 'Community Tracking Tool',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Supportive Supervision',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis and Treatment of Malaria in Pregnancy',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Diagnosis and/or Treatment of STI, excluding HIV',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'HIV Counseling',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '3.2.2',
          section_name: 'Delivery Services',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Others', type: 'numeric', code: '5' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Basic Life Support (BLS)',
                  field_code: '1',
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Basic Emergency Obstetric and Neonatal Care (BEmONC)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Essential Intrapartum and Newborn Care (EINC)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Lactation Management Training (LMT)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Expanded Newborn Screening Training',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Maternal Death Review and Reporting System (MDRRS)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Maternal, Neonatal and Infant Death Reporting System (MNIDRS)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '3.2.3',
          section_name: 'Postnatal Care',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Others', type: 'numeric', code: '5' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name:
                    'Infant and Young Child Feeding / Lactation Management Training / Management of Breastfeeding Difficulties (any one)',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Kangaroo Mother Care for Premature / Very Small Babies',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Modern Methods of Family Planning',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Postpartum Intrauterine Device Insertion',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '3.2.4',
          section_name: 'Newborn Care',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Expanded Program on Immunization / National Immunization Program',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '3.2.5',
          section_name: 'Family Planning',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Basic Family Planning or Family Planning Competency-Based Training (FPBCT) Level 1',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'FPCBT Level 2: Interval IUD insertion and Removal',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'FPCBT Level 2: Post-Partum IUD Insertion and Removal',
                  field_code: '1',
                  applicable: ['Infirmary', 'Safe Birthing Facility', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'FPCBT Level 2: Progestin-only Subdermal Implant Insertion and Removal',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [{ name: 'Doctors', type: 'numeric', code: '1' }],
              rows: [
                {
                  type: 'field',
                  field_name: 'No-Scalpel Vasectomy (Training for Physicians)',
                  field_code: '1',
                  applicable: ['Infirmary'],
                },
                {
                  type: 'field',
                  field_name: 'Bilateral Tubal Ligation-Mini-Laparotomy (for Hospitals)',
                  field_code: '1',
                  applicable: ['Infirmary'],
                },
              ],
            },
          ],
        },

        {
          type: 'sub-section',
          section_number: '3.2.6',
          section_name: 'Child Vaccination',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'BHWs', type: 'numeric', code: '4' },
                { name: 'Others', type: 'numeric', code: '5' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name:
                    'Philippine Integrated Management of Acute Malnutrition (PIMAM)/ Training on Community-Based Management of Acute Malnutrition',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Others', type: 'numeric', code: '5' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Growth Monitoring or Training Course on Child Growth Standards',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'City Health Office'],
                },
              ],
            },
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Integrated Management of Child Illness',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Management of TB in Children',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },

                {
                  type: 'field',
                  field_name: 'Maternal Nutrition and Infant Young Child Feeding (MNIYCF)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name:
                    'Capacity Enhancement Course - Universal Health Care, Prevention and Detection of Early Childhood Caries (ECC)',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Expanded Program on Immunization/National Immunization Program',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Cold Chain Management Training',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
              ],
            },
          ],
        },

        {
          type: 'sub-section',
          section_number: '3.2.7',
          section_name: 'Adolescent Health Services',
          section_content: [
            {
              type: 'table',
              field_name:
                'Have you or any health worker assigned in this facility been trained in the following within the past 5 years?',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Midwives', type: 'numeric', code: '3' },
                { name: 'Total', type: 'total', code: '6' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'Adolescent Job Aid (AJA)',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Healthy Young Ones',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Adolescent Health Care for Primary Health Service Providers - Foundational Course',
                  field_code: '1',
                  applicable: [
                    'Infirmary',
                    'Safe Birthing Facility',
                    'Rural Health Unit',
                    'Barangay Health Station',
                    'City Health Office',
                  ],
                },
                {
                  type: 'field',
                  field_name: 'Comprehensive Management on Adolescent Health?',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'Adolescent Health, Education and Practical Training (ADEPT)',
                  field_code: '1',
                  applicable: ['Rural Health Unit', 'Barangay Health Station', 'City Health Office'],
                },
              ],
            },
          ],
        },
        {
          type: 'sub-section',
          section_number: '3.2.8',
          section_name: 'Other Trainings',
          section_content: [
            {
              type: 'table',
              field_name: 'FHSIS Training',
              field_code: '1',
              columns: [
                { name: 'Doctors', type: 'numeric', code: '1' },
                { name: 'Nurses', type: 'numeric', code: '2' },
                { name: 'Total', type: 'total', code: '3' },
              ],
              rows: [
                {
                  type: 'field',
                  field_name: 'SMART Verbal Autopsy (VA) Training',
                  field_code: '1',
                  applicable: ['Infirmary', 'Rural Health Unit', 'City Health Office'],
                },
                {
                  type: 'field',
                  field_name: 'International Classification of Diseases (ICD)',
                  field_code: '1',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
