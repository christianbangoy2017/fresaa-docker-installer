'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('location_provinces', [
      {
        province_code: '1600200000',
        province_name: 'Agusan del Norte',
        region_code: '1600000000',
      },
      {
        province_code: '1600300000',
        province_name: 'Agusan del Sur',
        region_code: '1600000000',
      },
      {
        province_code: '1606700000',
        province_name: 'Surigao del Norte',
        region_code: '1600000000',
      },
      {
        province_code: '1606800000',
        province_name: 'Surigao del Sur',
        region_code: '1600000000',
      },
      {
        province_code: '1608500000',
        province_name: 'Dinagat Islands',
        region_code: '1600000000',
      },
      {
        province_code: '1630400000',
        province_name: 'Butuan City',
        region_code: '1600000000',
      },
      {
        province_code: '0600400000',
        province_name: 'Aklan',
        region_code: '0600000000',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('location_provinces', null, {});
  },
};
