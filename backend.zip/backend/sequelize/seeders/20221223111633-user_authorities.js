'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_authorities', [
      {
        id: 1,
        authority: 'MANAGE_ALL_ACCOUNTS',
        description: 'Create/Update/Delete All Accounts',
      },
      {
        id: 2,
        authority: 'MANAGE_NATIONAL_REGIONAL_ACCOUNT',
        description: 'Create/Update/Delete National and Regional Accounts',
      },
      {
        id: 3,
        authority: 'MANAGE_CITY_PROVINCIAL_ACCOUNT',
        description:
          'Create/Update/Delete City/Provincial and Municipal Accounts',
      },
      {
        id: 4,
        authority: 'MANAGE_FACILITIES',
        description: 'Create/Update/Delete Facilities',
      },
      {
        id: 5,
        authority: 'MANAGE_FRESAA_BATCHES',
        description: 'Create/Update/Delete Assessment Batches',
      },
      {
        id: 6,
        authority: 'VIEW_FRESAA_BATCHES',
        description: 'View Assessment Batches',
      },
      {
        id: 7,
        authority: 'CREATE_DELETE_REGIONAL_FRESAA_QUESTIONNAIRE',
        description: 'Create FRESAA Questionnaire - Regional Access',
      },
      {
        id: 8,
        authority: 'MANAGE_PROVINCIAL_FACILITIES',
        description: 'Create/Update/Delete Facilities - Provincial Access',
      },
      {
        id: 9,
        authority: 'ANSWER_FRESAA_QUESTIONNAIRE',
        description: 'Answer FRESAA Questionnaire',
      },
      {
        id: 10,
        authority: 'REVIEW_FRESAA_QUESTIONNAIRE',
        description: 'Review FRESAA Questionnaire',
      },
      {
        id: 11,
        authority: 'MANAGE_FRESAA_QUESTIONNAIRE',
        description: 'Assign and Submit FRESAA Questionnaire',
      },
      {
        id: 12,
        authority: 'MONITOR_REGIONAL_FRESAA_QUESTIONNAIRE',
        description: 'Monitor Regional Assessments',
      },
      {
        id: 13,
        authority: 'MONITOR_PROVINCIAL_FRESAA_QUESTIONNAIRE',
        description: 'Monitor Provincial Assessments',
      },
      {
        id: 14,
        authority: 'VIEW_REGIONAL_DASHBOARD',
        description: 'View Regional Dashboard',
      },
      {
        id: 15,
        authority: 'VIEW_PROVINCIAL_DASHBOARD',
        description: 'View Provincial Dashboard',
      },
      {
        id: 16,
        authority: 'VIEW_NATIONAL_DASHBOARD',
        description: 'View National Dashboard',
      },
      {
        id: 17,
        authority: 'VIEW_MUNICIPAL_DASHBOARD',
        description: 'View Municipal Dashboard',
      },
      {
        id: 18,
        authority: 'MANAGE_FACILITY_GROUP',
        description: 'Create/Update/Delete Facility Group',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('user_authorities', null, {});
  },
};
