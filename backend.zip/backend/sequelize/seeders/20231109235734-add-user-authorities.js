'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_authorities', [
      {
        id: 21,
        authority: 'MANAGE_FACILITY',
        description: 'Manage Dashboard',
     },
     {
        id: 22,
        authority: 'MANAGE_REPORTS',
        description: 'Manage Reporting Tool',
     }
    ]);
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
