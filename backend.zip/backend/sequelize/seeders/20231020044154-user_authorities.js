'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_authorities',[
      {
        id: 20,
        authority: 'MANAGE_DASHBOARD',
        description: 'Manage Dashboard',
      }
    ]);
  },

  async down (queryInterface, Sequelize) {
    // return await queryInterface.bulkDelete('user_authorities', null, {});
  }
};
