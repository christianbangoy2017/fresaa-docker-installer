'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_group_authorities', [
      {
        user_group_id: 1,
        user_authority_id: 19,
      },
      {
        user_group_id: 2,
        user_authority_id: 19,
      },
      {
        user_group_id: 3,
        user_authority_id: 19,
      },
      {
        user_group_id: 4,
        user_authority_id: 19,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
