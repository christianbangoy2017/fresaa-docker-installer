'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
     */
    return await queryInterface.bulkInsert('report_templates', [
      {
        id: 1,
        template_name: 'Comprehensive HEADSSS',
        template_code: 'T0000000001',
        region_code: '0800000000',
      },
      {
        id: 2,
        template_name: 'Rapid HEEADSSS',
        template_code: 'T0000000002',
        region_code: '0800000000',
      },
      {
        id: 3,
        template_name: 'Comprehensive HEADSSS - Samar',
        template_code: 'T0000000003',
        region_code: '0800000000',
      },
      {
        id: 4,
        template_name: 'Rapid HEADSSS - Samar HEEADSSS',
        template_code: 'T0000000004',
        region_code: '0800000000',
      },
      {
        id: 5,
        template_name: 'A1 - Form',
        template_code: 'T0000000005',
        region_code: '0800000000',
      },
      {
        id: 6,
        template_name: 'M2 Morbidity',
        template_code: 'T0000000006',
        region_code: '0800000000',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
