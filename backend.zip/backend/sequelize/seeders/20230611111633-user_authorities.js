'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_authorities', [
      {
        id: 19,
        authority: 'VIEW_ACTIVITY_LOG',
        description: 'View Activity Logs',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('user_authorities', null, {});
  },
};
