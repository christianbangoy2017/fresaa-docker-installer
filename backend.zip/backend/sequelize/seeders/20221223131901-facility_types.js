'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('facility_types', [
      {
        id: 1,
        type: 'Infirmary',
      },
      {
        id: 2,
        type: 'Safe Birthing Facility',
      },
      {
        id: 3,
        type: 'Rural Health Unit',
      },
      {
        id: 4,
        type: 'Barangay Health Station',
      },
      // {
      //   id: 5,
      //   type: 'Nutrition or Health Outpost',
      // },
      // {
      //   id: 6,
      //   type: 'Auxiliary Facility',
      // },
      {
        id: 7,
        type: 'City Health Office',
      },
      {
        id: 8,
        type: 'Hospital',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('facility_types', null, {});
  },
};
