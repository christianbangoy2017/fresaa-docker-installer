'use strict';

const caraga_indicators = require('../fresaa-files/CARAGA/main');
const western_visayas_indicators = require('../fresaa-files/Aklan/main');
// import { sections as western_visayas_indicators } from '../../src/fresaa-files/Western Visayas/main';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('assessment_indicators', [
      {
        id: 1,
        name: 'CARAGA WHO FRESAA Indicators v3',
        region_code: '1600000000',
        indicators: JSON.stringify(caraga_indicators),
        created_at: new Date(),
        updated_at: new Date(),
        deleted_at: null,
      },
      {
        id: 2,
        name: 'Aklan FRESAA Indicator',
        region_code: '0600000000',
        indicators: JSON.stringify(western_visayas_indicators),
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
