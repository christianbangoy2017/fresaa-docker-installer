'use strict';
const bcrypt = require('bcrypt');
const saltRounds = 10;
const password = 'fresaa';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    const now = new Date();
    const hashed = await bcrypt.hash(password, saltRounds);
    return await queryInterface.bulkInsert('users', [
      {
        username: 'cphi_sa',
        password: hashed,
        first_name: 'CPHI',
        last_name: 'CPHI',
        user_group_id: 9,
        mobile_number: '09123456789',
        email: 'admin@cphealthinnovations.com',
        created_at: now,
        updated_at: now,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('users', null, {});
  },
};
