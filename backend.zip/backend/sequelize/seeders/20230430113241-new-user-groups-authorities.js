'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_group_authorities', [
      // Provincial
      {
        user_group_id: 10,
        user_authority_id: 15,
      },

      // MHO/PHN
      {
        user_group_id: 11,
        user_authority_id: 10,
      },
      {
        user_group_id: 11,
        user_authority_id: 17,
      },

      // PHO
      {
        user_group_id: 12,
        user_authority_id: 6,
      },
      {
        user_group_id: 12,
        user_authority_id: 10,
      },
      {
        user_group_id: 12,
        user_authority_id: 15,
      },

      //CHD
      {
        user_group_id: 7,
        user_authority_id: 10,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
