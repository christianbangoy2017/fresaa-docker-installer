'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_groups', [
      {
        id: 1,
        group_name: 'RMTL',
        description: 'Regional Monitoring Team Leader',
        level: 'Regional',
      },
      {
        id: 2,
        group_name: 'RMTM',
        description: 'Regional Monitoring Team Member',
        level: 'Regional',
      },
      {
        id: 3,
        group_name: 'CPAL',
        description: 'City/Provincial Assessment Team Leader',
        level: 'Provincial',
      },
      {
        id: 4,
        group_name: 'CPAM',
        description: 'City/Provincial Assessment Team Member',
        level: 'Provincial',
      },
      {
        id: 5,
        group_name: 'FA',
        description: 'Field Assessor',
        level: 'Provincial',
      },
      {
        id: 6,
        group_name: 'Municipal',
        description: 'Municipal Account (Dashboard View only)',
        level: 'Municipal',
      },
      {
        id: 7,
        group_name: 'CHD',
        description: 'Center for Health Development',
        level: 'Regional',
      },
      {
        id: 8,
        group_name: 'National',
        description: 'National Account (Dashboard View only)',
        level: 'National',
      },
      {
        id: 9,
        group_name: 'SA',
        description: 'Super Admin',
        level: '0.0.0',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('user_groups', null, {});
  },
};
