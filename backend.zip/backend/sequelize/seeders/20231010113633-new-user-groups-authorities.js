'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_group_authorities', [
      {
        user_group_id: 13,
        user_authority_id: 10,
      },
      {
        user_group_id: 13,
        user_authority_id: 14,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('user_authorities', null, {});
  },
};
