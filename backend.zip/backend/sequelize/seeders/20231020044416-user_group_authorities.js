'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_group_authorities', [
      {
        user_group_id: 1,  // RMTL
        user_authority_id: 20,
      },
      {
        user_group_id: 2,  // RMTM
        user_authority_id: 20,
      },
    ]);
  },

  async down (queryInterface, Sequelize) {
    // return await queryInterface.bulkDelete('user_authorities', null, {});
  }
};
