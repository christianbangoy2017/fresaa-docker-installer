'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_groups', [
      {
        id: 10,
        group_name: 'Provincial',
        description: 'Provincial Account (Dashboard View only)',
        level: 'Provincial',
      },
      {
        id: 11,
        group_name: 'MHO/PHN',
        description: 'MHO/PHN',
        level: 'Municipal',
        validator: true,
      },
      {
        id: 12,
        group_name: 'PHO',
        description: 'Provincial Health Officer',
        level: 'Provincial',
        validator: true,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
