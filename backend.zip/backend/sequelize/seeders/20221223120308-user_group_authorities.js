'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_group_authorities', [
      // RMTL
      {
        user_group_id: 1,
        user_authority_id: 2,
      },
      {
        user_group_id: 1,
        user_authority_id: 3,
      },
      {
        user_group_id: 1,
        user_authority_id: 4,
      },
      {
        user_group_id: 1,
        user_authority_id: 5,
      },
      {
        user_group_id: 1,
        user_authority_id: 6,
      },
      {
        user_group_id: 1,
        user_authority_id: 7,
      },
      {
        user_group_id: 1,
        user_authority_id: 11,
      },
      {
        user_group_id: 1,
        user_authority_id: 12,
      },
      {
        user_group_id: 1,
        user_authority_id: 14,
      },
      {
        user_group_id: 1,
        user_authority_id: 18,
      },

      // RMTM
      {
        user_group_id: 2,
        user_authority_id: 2,
      },
      {
        user_group_id: 2,
        user_authority_id: 3,
      },
      {
        user_group_id: 2,
        user_authority_id: 4,
      },
      {
        user_group_id: 2,
        user_authority_id: 6,
      },
      {
        user_group_id: 2,
        user_authority_id: 7,
      },
      {
        user_group_id: 2,
        user_authority_id: 11,
      },
      {
        user_group_id: 2,
        user_authority_id: 12,
      },
      {
        user_group_id: 2,
        user_authority_id: 14,
      },
      {
        user_group_id: 2,
        user_authority_id: 18,
      },

      // CPAL
      {
        user_group_id: 3,
        user_authority_id: 3,
      },
      {
        user_group_id: 3,
        user_authority_id: 6,
      },
      {
        user_group_id: 3,
        user_authority_id: 8,
      },
      {
        user_group_id: 3,
        user_authority_id: 11,
      },
      {
        user_group_id: 3,
        user_authority_id: 13,
      },
      {
        user_group_id: 3,
        user_authority_id: 15,
      },
      {
        user_group_id: 3,
        user_authority_id: 18,
      },

      // CPAM
      {
        user_group_id: 4,
        user_authority_id: 6,
      },
      {
        user_group_id: 4,
        user_authority_id: 8,
      },
      {
        user_group_id: 4,
        user_authority_id: 11,
      },
      {
        user_group_id: 4,
        user_authority_id: 13,
      },
      {
        user_group_id: 4,
        user_authority_id: 15,
      },
      {
        user_group_id: 4,
        user_authority_id: 18,
      },

      // FA
      {
        user_group_id: 5,
        user_authority_id: 9,
      },

      // Municipal
      {
        user_group_id: 6,
        user_authority_id: 17,
      },

      // CHD
      {
        user_group_id: 7,
        user_authority_id: 10,
      },
      {
        user_group_id: 7,
        user_authority_id: 14,
      },

      // National
      {
        user_group_id: 8,
        user_authority_id: 16,
      },

      // Super Admin
      {
        user_group_id: 9,
        user_authority_id: 1,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('user_group_authorities', null, {});
  },
};
