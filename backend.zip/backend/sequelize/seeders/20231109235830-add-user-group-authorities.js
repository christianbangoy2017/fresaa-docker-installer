'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('user_group_authorities', [
      {
        user_group_id: 14,  // FHS
        user_authority_id: 21,
     },
     {
        user_group_id: 1,  // RMTL
        user_authority_id: 22,
     },
     {
        user_group_id: 2,  // RMTM
        user_authority_id: 22,
     }
    ]);
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
