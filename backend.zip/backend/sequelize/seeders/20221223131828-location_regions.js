'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return await queryInterface.bulkInsert('location_regions', [
      {
        region_code: '1600000000',
        region_name: 'Region XIII (Caraga)',
        region_short_name: 'Caraga',
      },
      {
        region_code: '0600000000',
        region_name: 'Region VI (Western Visayas)',
        region_short_name: 'Western Visayas',
      },
      {
        region_code: '0800000000',
        region_name: 'Region VIII (Eastern Visayas)',
        region_short_name: 'Eastern Visayas',
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    return await queryInterface.bulkDelete('location_regions', null, {});
  },
};
