require('dotenv').config();

config = {
  dialect: process.env.DB_DRIVER,
  storage: process.env.DB_STORAGE,
  database: process.env.DB_NAME,
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  timezone: process.env.DB_TIMEZONE,
};
module.exports = config;
