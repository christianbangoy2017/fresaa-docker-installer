-- MySQL dump 10.13  Distrib 8.0.34, for macos13 (arm64)
--
-- Host: localhost    Database: fresaa_davao
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `activity` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `model_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3572 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_batch_facilities`
--

DROP TABLE IF EXISTS `assessment_batch_facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_batch_facilities` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `facility_id` int unsigned NOT NULL,
  `batch_id` int unsigned NOT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `facility_id` (`facility_id`),
  KEY `batch_id` (`batch_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `assessment_batch_facilities_ibfk_13` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`),
  CONSTRAINT `assessment_batch_facilities_ibfk_14` FOREIGN KEY (`batch_id`) REFERENCES `assessment_batches` (`id`),
  CONSTRAINT `assessment_batch_facilities_ibfk_15` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12517 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_batch_facilities`
--

LOCK TABLES `assessment_batch_facilities` WRITE;
/*!40000 ALTER TABLE `assessment_batch_facilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_batch_facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_batch_forms`
--

DROP TABLE IF EXISTS `assessment_batch_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_batch_forms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` int unsigned NOT NULL,
  `indicator_id` int unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `assessment_batch_forms_ibfk_13` FOREIGN KEY (`batch_id`) REFERENCES `assessment_batches` (`id`),
  CONSTRAINT `assessment_batch_forms_ibfk_14` FOREIGN KEY (`indicator_id`) REFERENCES `assessment_indicators` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_batch_forms`
--

LOCK TABLES `assessment_batch_forms` WRITE;
/*!40000 ALTER TABLE `assessment_batch_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_batch_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_batches`
--

DROP TABLE IF EXISTS `assessment_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_batches` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('open','active','closed') COLLATE utf8mb4_general_ci DEFAULT 'open',
  `year` int unsigned DEFAULT NULL,
  `indicator_id` int unsigned DEFAULT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `updated_by` int unsigned DEFAULT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `dashboard_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_code` (`region_code`),
  KEY `indicator_id` (`indicator_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`),
  CONSTRAINT `assessment_batches_ibfk_76` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `assessment_batches_ibfk_77` FOREIGN KEY (`indicator_id`) REFERENCES `assessment_indicators` (`id`),
  CONSTRAINT `assessment_batches_ibfk_78` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `assessment_batches_ibfk_79` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `assessment_batches_ibfk_80` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_batches`
--

LOCK TABLES `assessment_batches` WRITE;
/*!40000 ALTER TABLE `assessment_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_comments`
--

DROP TABLE IF EXISTS `assessment_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_comments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `assessment_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `status` enum('open','resolved') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'open',
  `field_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `field_name` text COLLATE utf8mb4_general_ci,
  `comment` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `assessment_comments_ibfk_17` FOREIGN KEY (`assessment_id`) REFERENCES `facility_assessments` (`id`),
  CONSTRAINT `assessment_comments_ibfk_18` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=321 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_comments`
--

LOCK TABLES `assessment_comments` WRITE;
/*!40000 ALTER TABLE `assessment_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_indicators`
--

DROP TABLE IF EXISTS `assessment_indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_indicators` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `indicators` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `validation_workflow_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_code` (`region_code`),
  KEY `validation_workflow_id` (`validation_workflow_id`),
  CONSTRAINT `assessment_indicators_ibfk_11` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `assessment_indicators_ibfk_12` FOREIGN KEY (`validation_workflow_id`) REFERENCES `form_validation_workflow` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_indicators`
--

LOCK TABLES `assessment_indicators` WRITE;
/*!40000 ALTER TABLE `assessment_indicators` DISABLE KEYS */;
INSERT INTO `assessment_indicators` VALUES (21,'Davao WHO FRESAA Indicators v3','[{\"section_number\":0,\"section_name\":\"Facility Identification\",\"section_body\":[{\"type\":\"field\",\"field_name\":\"Name of Facility\",\"field_code\":\"1\",\"response_type\":\"text\",\"disabled\":true},{\"type\":\"field\",\"field_name\":\"Facility Code\",\"field_code\":\"1\",\"response_type\":\"text\",\"disabled\":true},{\"type\":\"field\",\"field_name\":\"GIS Code\",\"field_code\":\"1\",\"response_type\":\"text\",\"disabled\":true},{\"type\":\"field\",\"field_name\":\"Location of Facility (Barangay / Municipality)\",\"field_code\":\"1\",\"response_type\":\"text\",\"disabled\":true},{\"type\":\"field\",\"field_name\":\"Province and Region\",\"field_code\":\"1\",\"response_type\":\"text\",\"disabled\":true},{\"type\":\"parent\",\"field_name\":\"Population coverage of facility\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Projected population\",\"field_code\":\"1\",\"response_type\":\"numeric\"},{\"type\":\"field\",\"field_name\":\"Actual population\",\"field_code\":\"1\",\"response_type\":\"numeric\"}]},{\"type\":\"field\",\"field_name\":\"Income Class\",\"field_code\":\"1\",\"response_type\":\"radio\",\"disabled\":true,\"options\":[\"1st\",\"2nd\",\"3rd\",\"4th\",\"5th\",\"6th\"],\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Type of Facility\",\"field_code\":\"1\",\"response_type\":\"radio\",\"disabled\":true,\"options\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\",\"Barangay Health Station\",\"Nutrition or Health Outpost\",\"Auxiliary Facility\",\"Rural Health Unit with Birthing\",\"Barangay Health Station with Birthing\"]},{\"type\":\"field\",\"field_name\":\"Managing Authority\",\"field_code\":\"1\",\"response_type\":\"radio\",\"disabled\":true,\"options\":[\"Department of Health\",\"Provincial Government\",\"Municipal Government\",\"Other\"]},{\"type\":\"field\",\"field_name\":\"Head of the Facility\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Medical Doctor\",\"Registered Nurse\",\"Registered Midwife\",\"Other\"]},{\"type\":\"field\",\"field_name\":\"Name of Head of the Facility\",\"field_code\":\"1\",\"response_type\":\"text\"}]},{\"section_number\":1,\"section_name\":\"Leadership, Governance and Policy\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"1.1\",\"section_name\":\"DOH Policies, Certification, Ordinances, Executive Orders, and Resolutions\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Please tell me if the Municipality/City/barangay has ordinances, executive orders, or resolutions pertaining to the following:\",\"children\":[{\"type\":\"parent\",\"field_code\":\"1\",\"field_name\":\"Maternal Care & Oral Health\",\"children\":[{\"type\":\"field\",\"field_name\":\"BEMONC certified only\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"License to Operate as birthing facility\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Mother-Baby Friendly Facility (for hospital and birthing facility)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Maternal, Neonatal, Child Health and Nutrition (MNCHN) Policy\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Safe Motherhood and/or Facility-based Deliveries\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Contraceptive Self-Reliance Policy\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\" Breastfeeding and/or Milk Code\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"PhilHealth enrollment of women about to give birth\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"COVID-19 Policies on Maternal Health\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"FP Clinical Standards Manual (2014 Edition)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Copy of National Policy on Oral Health Care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Copy of OHP Implementing Guidelines and Procedures\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Are there any local ordinances enacted/passed for oral health\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"parent\",\"field_code\":\"1\",\"field_name\":\"Newborn, Child, and Adolescent Health\",\"children\":[{\"type\":\"field\",\"field_name\":\"Newborn Screening\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Is there an available micro plan and session plan for routine immunization\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Are there national guidelines, memos, advisories, monitoring tools, Manual of Operation on National Immunization Program in the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is the facility certified as Adolescent-Friendly?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Level 1\",\"Level 2\",\"Level 3\",\"Processing\",\"No\"]},{\"type\":\"field\",\"field_name\":\"Is there an existing AHDP Policy in the LGU?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Ordinance with IRR\",\"Ordinance only\",\"MOP\",\"Processing\",\"No\"],\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]}]},{\"type\":\"sub-section\",\"section_number\":\"1.2\",\"section_name\":\"PhilHealth accreditation\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"PhilHealth accreditation\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Konsulta Package Provider\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Maternity Care Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Newborn Care Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Family Planning Package\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"1.3\",\"section_name\":\"Maternal Neonatal and Infant Death Review and Reporting Systems\",\"section_content\":[{\"type\":\"field\",\"field_name\":\"Does the facility implement the Maternal Death Review and Reporting System (MDRRS)?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Does the facility use the Maternal, Neonatal and Infant Death Reporting System (MNIDRS)?\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]},{\"section_number\":2,\"section_name\":\"Service Delivery (including equipment for service delivery)\",\"section_description\":\"Strengthening service delivery is crucial to the achievement of the health-related Sustainable Development Goals (SDGs) and the National Objectives for Health (NOH) for the Philippines, which include the delivery of  interventions to reduce child and maternal mortality. Service provision or delivery is an immediate output of the inputs into the health system, such as the health workforce, procurement and supplies, and financing. Increased inputs should lead to improved service delivery and enhanced access to services. Ensuring availability of health services that meet a minimum quality standard and securing access to them are key functions of a health system.\",\"has_subsection\":true,\"section_body\":[{\"type\":\"section\",\"section_number\":\"2.1\",\"section_name\":\"General Maternal, Newborn, Child Health & Nutrition (MNCHN) Services\",\"section_body\":[{\"type\":\"parent\",\"field_name\":\"Does this facility offer any of the following client services? Is there any location in this facility where clients can receive any of the following services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Health Education\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Natural method of family planning\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Artificial method of family planning\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Ante-natal care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Normal delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Assisted delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Post-natal care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Breastfeeding education\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Newborn care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Newborn screening - Blood\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Newborn Hearing Screening\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Child Vaccinations\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Child Growth Monitoring\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Integrated Management of Child Illnesses\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Therapeutic food supplementation for children with acute malnutrition\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Micronutrient Supplementation\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Management of TB in children\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Basic Oral Health Care\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Education and counselling on health effects of tobacco/smoking, diet, and oral hygiene to adolescents\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Adolescent Sexual and Reproductive Health (ASRH)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Laboratory diagnostic services\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Point-of-care/ Point of service enrollment to PhilHealth\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]}]},{\"type\":\"field\",\"field_name\":\"Are TCL updated and completed showing defaulters?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Barangay Health Station\"]},{\"type\":\"field\",\"field_name\":\"Is there enough cold chain equipment in the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"section\",\"section_number\":\"2.2\",\"section_name\":\"Demand Generation\",\"section_description\":\"Information, Education and Communication materials for demand generation\",\"section_body\":[{\"type\":\"parent\",\"field_name\":\"Does your facility use IEC materials for the following programmes?\",\"children\":[{\"type\":\"parent\",\"field_code\":\"1\",\"field_name\":\"Maternal Care\",\"children\":[{\"type\":\"field\",\"field_name\":\"Leaflets/pamphlets\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Posters\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Flip Charts\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Models\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Videos\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Photographs\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"parent\",\"field_code\":\"1\",\"field_name\":\"Oral Health\",\"children\":[{\"type\":\"field\",\"field_name\":\"Leaflets/pamphlets\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Posters\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Flip Charts\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Models\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Videos\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Photographs\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"parent\",\"field_code\":\"1\",\"field_name\":\"Family Planning\",\"children\":[{\"type\":\"field\",\"field_name\":\"WHO Medical Eligibility Criteria (MEC) Wheel 5th Edition\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Flip chart in the facility\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"FP Posters in the facility\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"FP flyers in the facility\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"GATHER appproach Cue Card\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"parent\",\"field_code\":\"1\",\"field_name\":\"Newborn, child, and adolescent health\",\"children\":[{\"type\":\"field\",\"field_name\":\"Healthy Young Ones Flipchart\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there advocacy materials on the National Immunization Program in the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]}]},{\"type\":\"section\",\"section_number\":\"2.3\",\"section_name\":\"Physical Structure of Facility\",\"section_body\":[{\"type\":\"field\",\"field_name\":\"Is there a clear sign bearing the name of the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a sign indicating it is a PhilHealth provider?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a sign enumerating the services available?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a generally clean environment inside the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Are there visible signs prohibiting smoking?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there sufficient seating for clients in a well-ventilated area?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there adequate lighting or naturally well-lighted?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there adequate clean water supply from a reliable source?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a consultation/examination room/cubicle with auditory and visual privacy available?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a Delivery Room with area for cleaning/resuscitation of newborn?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Is there an area for cleaning instruments?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Is there any room/s for patients awaiting delivery or while recovering?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Are there adequate signages (entrance, exits, laboratory, etc.)?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a functional toilet for in-patient use only (1 toilet: 6 beds)\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Flush (or Pour Flush Toilet) to Piped Sewer System\",\"Flush to Septic Tank\",\"Flush to Pit Latrine\",\"Flush to Somewhere Else\",\"Flush, Don’t Know Where\",\"Ventilated Improved Pit Latrine\",\"Pit Latrine with Slab\",\"Open Pit\",\"Composting Toilet\",\"Bucket Toilet\",\"Hanging Toilet\",\"No Functioning Facility/Bush/Field\"]},{\"type\":\"field\",\"field_name\":\"Is there a functional toilet for general out-patient use only?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Flush (or Pour Flush Toilet) to Piped Sewer System\",\"Flush to Septic Tank\",\"Flush to Pit Latrine\",\"Flush to Somewhere Else\",\"Flush, Don’t Know Where\",\"Ventilated Improved Pit Latrine\",\"Pit Latrine with Slab\",\"Open Pit\",\"Composting Toilet\",\"Bucket Toilet\",\"Hanging Toilet\",\"No Functioning Facility/Bush/Field\"]},{\"type\":\"field\",\"field_name\":\"Are there separate toilets for males and females?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a ramp entrance?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Are there emergency escape plans posted in conspicuous places?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a reception area?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there a waiting area?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there an IEC area?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there an access to comfort room/lavatory?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is there an area for record keeping?\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"section\",\"section_number\":\"2.4\",\"section_name\":\"Basic Supplies and Equipment\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"I would like to know if the following items are available today in the main service area and are functioning.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Adult Weighing Scale\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Child Weighing Scale (250 Gram Gradation)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Infant Weighing Scale (100 Gram Gradation)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Stadiometer (or Height Rod) For Measuring Height\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Thermometer\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Stethoscope\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Sphygmomanometer (Non-Mercury)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Light Source for examination (or equivalent)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Stretcher or Examining Table\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Wheelchair\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Mid-upper arm circumference tape (Adult)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Mid-upper arm circumference tape (Child)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Emergency/Alternative Light Source\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Wall Clock with Second Hand\",\"field_code\":\"1\"}]}]},{\"type\":\"section\",\"section_number\":\"2.5\",\"section_name\":\"Water, Sanitation and Hygiene (WASH) and Standard Precautions and Waste Management\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"2.5.1\",\"section_name\":\"Water\",\"section_content\":[{\"type\":\"table\",\"table_type\":\"simple-table\",\"field_name\":\"Does the facility comply with the following WASH elements?\",\"field_code\":\"1\",\"columns\":[\"Observed\",\"Reported, not seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Improved DRINKING WATER supply piped into facility or on premises.\",\"field_code\":\"1\",\"field_description\":\"Improved drinking water sources are as follows: Piped water into health facility or yard/ plot; Public tap or standpipe; Tube Well or borehole or protected well; improved spring; Rainwater from a cistern or tank; Packaged water – bottled water; Water from water refilling stations.\\n              Unimproved drinking water sources are unprotected well/ spring and surface water, water provided through tanker trucks.\"},{\"type\":\"field\",\"field_name\":\"Improved water supply piped into the facility or on premises, with no leaks.\",\"field_code\":\"1\",\"field_description\":\"This refers to the water supply for general purposes, including washing and cleaning. Improved water sources are as follows: Piped water into health facility or yard/ plot; Public tap or standpipe; Tube Well or borehole; or protected well; improved spring; Rainwater from a cistern or tank; Packaged water – bottled water; Water from water refilling stations Unimproved water sources are unprotected well/ spring and surface water, water provided through tanker truck\"},{\"type\":\"field\",\"field_name\":\"Shower and bathing areas are accessible and functioning\",\"field_code\":\"1\",\"field_description\":\"For BHS or RHU or UHC, with birthing facilities, at least 1 bathroom inside the labor room or ward. \"},{\"type\":\"field\",\"field_name\":\"Water services available at all times and of sufficient quantity.\",\"field_code\":\"1\",\"field_description\":\"To calculate the facility’s water requirements, add up the following applicable national standards: \\n                + Outpatients: 5 L/consultation \\n                + Inpatients: 40–60 L/patient/day \\n                + Operating theater or maternity unit: 100 L/intervention \\n                \\n                \"},{\"type\":\"field\",\"field_name\":\"Reliable drinking water station available \",\"field_code\":\"1\",\"field_description\":\"This refers to a water station or water dispenser or water containers available at all times and accessible to all.\"},{\"type\":\"field\",\"field_name\":\"Drinking water safe storage and has no E. Coli\",\"field_code\":\"1\",\"field_description\":\"This refers to a water dispenser or water containers with cover and tap.\"},{\"type\":\"field\",\"field_name\":\"Water storage is sufficient.\",\"field_code\":\"1\",\"field_description\":\"To calculate the facility’s water requirement for a day, add up the following applicable national standards: \\n                + Outpatients: 5 L/consultation \\n                + Inpatients: 40–60 L/patient/day\\n                + Operating theatre or maternity unit: 100 L/intervention  \\n                \\n                \"},{\"type\":\"field\",\"field_name\":\"Water supply has chlorine residual \",\"field_code\":\"1\",\"field_description\":\"During an emergency period, a free residual chlorine (FRC) of 0.5mg/L min is required, as a general preventive measure for patient’s safety.\\n                In normal settings, bulk water supply shall maintain a free residual chlorine (FRC) level of 0.3 mg/L to a maximum of 1.5 mg/L at the point of delivery. (DOH PNSDW 2017) \\n                \"},{\"type\":\"field\",\"field_name\":\"Sufficient energy for water\",\"field_code\":\"1\",\"field_description\":\"On-site renewable energy generation or backup electricity generation that can power the facility’s emergency power needs.\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.5.2\",\"section_name\":\"Sanitation\",\"section_content\":[{\"type\":\"table\",\"table_type\":\"simple-table\",\"field_name\":\"Does the facility comply with the following WASH elements?\",\"field_code\":\"1\",\"columns\":[\"Observed\",\"Reported, not seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Sufficient number of functional toilets or latrines available.\",\"field_code\":\"1\",\"field_description\":\"A toilet is defined as having a flush toilet following the standard septic tank design under the Code on Sanitation of the Philippines and DOH AO 2019-0047 (National Standard on the Design, Construction, Operation and Maintenance of Septic Tank System). It is also recommended that toilets be provided with a bidet. A latrine refers to pour flush systems that follow standard septic tank design. A functioning or usable toilet or latrine should have water available at all times. Use the guide below to assess if you are meeting the required minimum number of toilets regardless of PWD-accessibility and sex segregation. \"},{\"type\":\"field\",\"field_name\":\"Toilets or latrines separated for staff, patients, and visitors.\",\"field_code\":\"1\",\"field_description\":\"For primary care facilities, separate toilets for staff and patients are required for Rural Health Units or Urban Health Centers, with or without birthing facilities or TB-DOTS. No separate toilets for staff, patients and visitors are required in Barangay Health Stations, except in BHS with birthing facilities.\"},{\"type\":\"field\",\"field_name\":\"Toilets or latrines separated for male and female.\",\"field_code\":\"1\",\"field_description\":\"For Rural Health Units or Urban Health Centers, with or without birthing facility or TB-DOTS, there should be at least 1 set of separate public toilets for males and females. In Barangay Health Stations, no separate public toilets for males and females are required.\"},{\"type\":\"field\",\"field_name\":\"Menstrual hygiene management\",\"field_code\":\"1\",\"field_description\":\"Toilets should have a bin for disposal of waste and an area for washing, with water available.\"},{\"type\":\"field\",\"field_name\":\"Toilet meeting the needs of people with reduced mobility.\",\"field_code\":\"1\",\"field_description\":\"For primary care facilities, at least one PWD toilet is required for BHS (with or without birthing facility), and RHU / UHC (with or without birthing facility or TB-DOTS). \"},{\"type\":\"field\",\"field_name\":\"Functioning hand hygiene stations at latrines or toilets.\",\"field_code\":\"1\",\"field_description\":\"A functional hand hygiene station should have a sink or bucket with tap and water with soap. In settings where this is not possible, water “flowing” from a pre-filled container with a tap is preferable to still-standing water in a basin. Alcohol-based handrub is not suitable for use at latrines or toilets.\"},{\"type\":\"field\",\"field_name\":\"Wastewater is safely managed.\",\"field_code\":\"1\",\"field_description\":\"Wastewater is safely managed through use of an on-site treatment facility that has been provided with a discharge permit by DENR;or, through use of a septic tank followed by a drainage pit or sent to a functioning sewer system. \"},{\"type\":\"field\",\"field_name\":\"Greywater drainage system is safely managed.\",\"field_code\":\"1\",\"field_description\":\"Grey water (i.e. rainwater or wash water) drainage system is in place that diverts water away from the facility (i.e. no standing water) and also protects nearby households\"},{\"type\":\"field\",\"field_name\":\"Toilets and latrines are adequately lit.\",\"field_code\":\"1\",\"field_description\":\"Toilet and latrines shall have an efficient and functional lightning at all times\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.5.3\",\"section_name\":\"Hygiene\",\"section_content\":[{\"type\":\"table\",\"table_type\":\"simple-table\",\"field_name\":\"Does the facility comply with the following WASH elements?\",\"field_code\":\"1\",\"columns\":[\"Observed\",\"Reported, not seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Functioning hand hygiene stations are available at all points of care.\",\"field_code\":\"1\",\"field_description\":\"Point of care is where three elements come together: the patient; the health care workers; and care or treatment involving contact with the patient or their surroundings. This may include consultation rooms, operating rooms, delivery rooms and laboratories. Hand hygiene stations should have a sink or bucket with tap, water and soap; or 70% alcohol-based handrub. In settings where tap water is not possible, water “flowing” from a pre-filled container with a tap is preferable to still-standing water in a basin. \"},{\"type\":\"field\",\"field_name\":\"Hand hygiene promotion materials.\",\"field_code\":\"1\",\"field_description\":\"Key places include at points of care areas, the waiting room, at the facility’s entrance and within 5 meters of latrines or toilets.\"},{\"type\":\"field\",\"field_name\":\"Functioning hand hygiene stations available in service areas.\",\"field_code\":\"1\",\"field_description\":\"Sink or bucket with tap, water and soap or 70% alcohol-based hand rub should be available 24/7. \"},{\"type\":\"field\",\"field_name\":\"Functioning hand hygiene stations available in the waste disposal area.\",\"field_code\":\"1\",\"field_description\":\"Sink or bucket with tap and water with soap\"},{\"type\":\"field\",\"field_name\":\"Hand hygiene compliance undertaken regularly.\",\"field_code\":\"1\",\"field_description\":\"Hand hygiene compliance refers to the practice of hand hygiene during five critical moments, as shown below, including during donning and removal of PPEs: \\n                1- before touching a patient \\n                2- before doing a clean / aseptic procedure \\n                3- after touching body fluid / exposure risk \\n                4- after touching a patient \\n                5- after touching patient surroundings\"},{\"type\":\"field\",\"field_name\":\"Staff can demonstrate correct procedures for hand washing.\",\"field_code\":\"1\",\"field_description\":\"Training to staff and protocol on hand hygiene technique being followed.\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.5.4\",\"section_name\":\"Health Care Waste Management\",\"section_content\":[{\"type\":\"table\",\"table_type\":\"simple-table\",\"field_name\":\"Please tell me if the following resources/ supplies are available in this facility today.\",\"field_code\":\"1\",\"columns\":[\"Observed\",\"Reported, not seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Clean Running Water (Piped, Bucket with Tap or Pour Pitcher)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Hand-Washing Soap (May Be Liquid Soap)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"70% Isopropyl Alcohol\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Disposable Latex Gloves\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Waste Receptacle (Pedal Bin) With Lid and Plastic Liner\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Segregated, Properly Labelled Garbage Containers\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Sharps Container\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Infectious Wastes Container\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Environmental Disinfectant (Alcohol, Chlorine) and Facility Cleaning Materials\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Auto-Disable Syringes\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Soaking Solution for Medical Instruments\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Autoclave or Sterilization Equipment\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Guidelines for Standard Precautions Posted\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Eye Protection (Goggles)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Medical Mask \",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Sterile Drapes \",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Surgical Cap\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Gown\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Trained person responsible for health care waste. \",\"field_code\":\"1\",\"field_description\":\"Ensure training conducted to HCWM committee and other healthcare workers involved with HCWM\"},{\"type\":\"field\",\"field_name\":\"Functional collection containers for each type of health care waste.  \",\"field_code\":\"1\",\"field_description\":\"Pedal-operated waste collection bins with liners should be available at all waste generation points. In absence of pedal-operated waste bins, bins with swinging lids can be opted as the alternative. Otherwise, open waste containers are better than those which require touching the lid of the garbage container. \"},{\"type\":\"field\",\"field_name\":\"Waste correctly segregated at all generation points \",\"field_code\":\"1\",\"field_description\":\"Garbage container and plastic liners should follow the color-coded for various healthcare waste based on the latest HCWM Manual\"},{\"type\":\"field\",\"field_name\":\"Hazardous and non-hazardous waste are stored separately  \",\"field_code\":\"1\",\"field_description\":\"For primary care facilities, there should be a waste holding area located outside the building but within the site or premises.\"},{\"type\":\"field\",\"field_name\":\"Infectious waste stored in protected area and treated within safe time period \",\"field_code\":\"1\",\"field_description\":\"Unless a refrigerated storage room (at 3 to 8 degree Celsius) is available, storage times for infectious waste (e.g. the time between generation and treatment) should not exceed the following periods: \\n                • 48 hours during the cold season \\n                • 24 hours during the hot season\"},{\"type\":\"field\",\"field_name\":\"Disposal of anatomical-pathological waste\",\"field_code\":\"1\",\"field_description\":\"In primary care facilities, placenta pit should be provided if birthing services are being offered in the facility. \\n                Placenta pits: lined or unlined depending on the geology, with slab, with ventilation pipe; and should be more than 30m from water source. \\n                SKIP THIS FOR Primary Care Facilities without inpatient beds\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Disposal of ash or residue from facilities using a thermal process or other alternative treatment methods   \",\"field_code\":\"1\",\"field_description\":\"Ash pits: lined or unlined depending on the geology but must prevent leaching to the environment, with slab, bottom of pit at least 1.5 m away from groundwater table. If water gets into the ash pit, it can leach pollutants into the soil. \",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Protocol or Standard Operating Procedure in place for health care waste \",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Appropriate protective equipment for waste treatment and disposal  \",\"field_code\":\"1\",\"field_description\":\"Protective equipment for people handling waste includes: gloves, apron, mask, heavy duty rubber boots. \\n                \"}]},{\"type\":\"field\",\"field_name\":\"How does this facility process its medical equipment for re-use?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"need_user_input\":[\"Process elsewhere\"],\"options\":[\"Wash with soap and water Only\",\"Soak in chemical solution then wash with soap and water\",\"Sterilizer\",\"Autoclave\",\"Process elsewhere\",\"Don’t know\"]},{\"type\":\"field\",\"field_name\":\"How does the facility finally dispose of its used sharps?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Incineration\",\"Open burning in protected area\",\"Dump without burning in protected area\",\"Remove offsite with protected storage\",\"Remove offsite and dump in general landfill\",\"Don’t know\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.5.5\",\"section_name\":\"Environmental Cleaning\",\"section_content\":[{\"type\":\"table\",\"table_type\":\"simple-table\",\"field_name\":\"Please tell me if the following resources/ supplies are available in this facility today.\",\"field_code\":\"1\",\"columns\":[\"Observed\",\"Reported, not seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"A clear and detailed facility (or ward) cleaning policy or protocol is clearly displayed, which is implemented and monitored.\",\"field_code\":\"1\",\"field_description\":\"Environmental surfaces or objects contaminated with blood, other body fluids, secretions or excretions are cleaned and disinfected as soon as possible using standard hospital disinfectants. Floors shall be made of materials that are non-slip, easy to clean, and resistant to chipping. A clean surface is noted by absence of waste, visible dirt, excreta, body fluid spills and insects.\"},{\"type\":\"field\",\"field_name\":\"Appropriate and well-maintained materials for cleaning available\",\"field_code\":\"1\",\"field_description\":\"There should be a designated physical space for storage, preparation, and care of cleaning supplies and equipment. Cleaning materials include: 1. Detergent or soap 2. Disinfectants, liquid bleach or chlorine granules or powder 3. Portable containers (e.g., bottles, pump dispenser, small buckets) 4. Surface cleaning cloths 5. Mops or floor cloths, with buckets/wringers 6. Pedal-operated (or swing lid) trash bins\"},{\"type\":\"field\",\"field_name\":\"Personal protective equipment available to all cleaning staff  \",\"field_code\":\"1\",\"field_description\":\"Protective equipment for people cleaning the facility or handling waste includes gloves, mask, heavy duty rubber boots, goggles (if there is risk for splash); and, water-proof apron or cover-all. \\n                \"},{\"type\":\"field\",\"field_name\":\"Staff have received training on environmental cleaning. \",\"field_code\":\"1\",\"field_description\":\"Demonstrate proper procedure in cleaning and disinfection of toilets, patients’ rooms and high-touch surfaces.\"},{\"type\":\"field\",\"field_name\":\"Mechanism exists to track supply of IPC-related materials   \",\"field_code\":\"1\",\"field_description\":\"IPC-related materials include PPEs, materials and supplies used for cleaning and disinfection and for hand hygiene. \\n                \"},{\"type\":\"field\",\"field_name\":\"Record of cleaning visible and signed by the cleaners each day \",\"field_code\":\"1\",\"field_description\":\"Have a record for environmental cleaning and updated, checked and signed being visible to auspicious areas. \\n                \"},{\"type\":\"field\",\"field_name\":\"Laundry facilities are available\",\"field_code\":\"1\",\"field_description\":\"If laundry services are outsourced, there must be a means to confirm that they follow standard IPC measures \\n                \"}]}]}]},{\"type\":\"section\",\"section_number\":\"2.6\",\"section_name\":\"Service Specific Readiness\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"2.6.1\",\"section_name\":\"Antenatal Care\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following services available in this facility as part of Antenatal Care services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Antenatal physical examination including Leopold’s maneuver and fundic height measurement\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Iron and Folic acid supplementation + Calcium Carbonate\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Basic Oral Health Care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Intermittent Preventive Treatment for Malaria (for endemic area only)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Tetanus Toxoid vaccination / Tetanus-diphtheria (Td) vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Monitoring for Hypertensive Disorder of Pregnancy\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling on danger signs of pregnancy and importance of 4 prenatal visits\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling on having a birth plan and facility-based delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Health education regarding Newborn Screening (Blood and Hearing)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling on Family Planning\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling about Maternal Nutrition and Infant and Young Child Feeding\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling about sexually transmitted infections from mother to child, including HIV\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Mental Health Screening\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"What is the schedule for delivery of antenatal care services in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Everyday\",\"Once a week\",\"Once a month\",\"Other\"]},{\"type\":\"parent\",\"field_name\":\"Are the following national guidelines, job-aids, checklist, and charts on antenatal care available in the facility today?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Quality Assurance Package (QAP) Manual / Pregnancy, Childbirth, Postpartum and Newborn Care (PCPNC) Manual\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Mother-Baby Book\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Maternal Health Record\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Visual Inspection using Acetic Acid (VIA)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"parent\",\"field_name\":\"Do you conduct the following diagnostic examinations in this facility at any time as part of Antenatal Care?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Hemoglobin determination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Urine dipstick test\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Urinalysis\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Urine glucose\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Blood glucose\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Blood typing\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Malaria rapid diagnostic test\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Syphilis rapid diagnostic test\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Hepatitis B diagnostic test\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"HIV rapid diagnostic test\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"Are individual client records (Maternal Health Record) for antenatal care maintained in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records kept\"]},{\"type\":\"field\",\"field_name\":\"Does this facility use any form of pregnancy tracking tool (e.g Community Tracking Tool)\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.2\",\"section_name\":\"Delivery Services\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Do you conduct the following diagnostic examinations in this facility at any time as part of Antenatal Care?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Monitoring and Management of Labor using Partograph\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Thermal Protection, Immediate Drying and Skin-to-Skin Contact\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Delayed Cord Cutting\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Hygienic Cord Care\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Immediate and Exclusive Breastfeeding\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Normal Delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Assisted Vaginal Delivery, including imminent Breech Delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Parenteral Administration of Uterotonic (e.g. Oxytocin) Drug\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Manual Removal of Placenta\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Removal of Retained Products after Delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Administration of Corticosteroids for Pre-Term Labor\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Parenteral Administration of Intravenous Antibiotics\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Parenteral Administration of Anticonvulsant\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Basic Emergency Obstetric Care\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Neonatal Resuscitation\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]}]},{\"type\":\"parent\",\"field_name\":\"Are the following national guidelines, job-aids, checklist, charts for delivery services in the facility today?\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"children\":[{\"type\":\"field\",\"field_name\":\"EINC Clinical Practical Pocket Guide\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]}]},{\"type\":\"parent\",\"field_name\":\"Does this facility have the following health personnel full time or on call 24/7?\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"children\":[{\"type\":\"field\",\"field_name\":\"Physician trained in Basic Emergency Obstetric and Neonatal Care\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"PhilHealth Accredited Professional Provider (Midwife/Doctor)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Bachelor of Science in Midwifery (Midwife with Diploma)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]}]},{\"type\":\"field\",\"field_name\":\"Does this facility have maternal clinical charts with properly accomplished consent forms and ICD-10 coded medical diagnosis and procedures performed?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records\"],\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Does this facility have newborn patient charts with properly and completely filled out birth certificate forms?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records\"],\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.3\",\"section_name\":\"Postnatal Care\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following routinely (always, for every client) carried out by providers in this facility as part of postnatal care?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Hemoglobin postnatal\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Iron supplementation\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Vitamin A supplementation\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Postpartum checkup at 24 hours after delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Postpartum checkup at 48-72 hours after delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Postpartum checkup within 1 week of delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Postpartum checkup within 4-6 weeks of delivery\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Blood pressure monitoring postpartum\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling on family planning\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Counseling on breastfeeding\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"parent\",\"field_name\":\"Are the following national guidelines, job-aids, checklist, and charts for postpartum care in the facility today?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Early Childhood Care and Development Card\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"MNIYCF Job Aid\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"Do you have a Maternal Health Record for postpartum visits with schedule of visits?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records\"],\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.4\",\"section_name\":\"Newborn Care\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following procedures routinely performed by providers of newborn care in this facility?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Vitamin K injection\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Eye prophylaxis\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Hepatitis B injection within 24 hours of life\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"BCG injection within 24 hours of life\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Weighing of the newborn and measurement of length (anthropometrics)\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Physical examination of the baby\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Parenteral Antibiotics for Babies whose mothers had Premature Rupture of Membranes\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Parenteral Antibiotics for Meconium-Stained Babies\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Parenteral Antibiotics for Neonatal Sepsis\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Newborn Screening / Expanded Newborn Screening\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Newborn Hearing Screening\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Apgar Scoring\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Ballard Scoring\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"response_type\":\"y/n\"}]},{\"type\":\"parent\",\"field_name\":\"Are there any newborn care national guidelines, job-aids, charts, checklist, posters in this facility today?\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"],\"children\":[{\"type\":\"field\",\"field_name\":\"EINC Clinical Practical Pocket Guide or equivalent\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.5\",\"section_name\":\"Family Planning\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following services available in the facility as part of Family Planning services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Counselling on Family Planning\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Combined oral contraceptive pills (COC)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Progestin only contraceptive pills (POP)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Depot-Medroxyprogesterone Acetate (DMPA)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Male condom\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Interval IUD insertion \",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Interval IUD removal \",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Postpartum IUD (PPIUD) insertion and removal\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Progesterone Subdermal Implant (PSI) insertion & removal, and reinsertion\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Provision of Natural Family Planning (NFP) services\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Is the FP Form 1 for family planning available in the facility today?\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"field\",\"field_name\":\"Are individual records or cards maintained in this facility for family planning clients?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.6\",\"section_name\":\"Child Vaccination\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following child vaccination services offered in this facility as part of Child Health services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"BCG Vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"DPT-Hib-HepB (Pentavalent) Vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Inactivated Polio Vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Oral Polio Vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Pneumococcal Conjugate Vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Rotavirus Vaccination \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Measles-Rubella (MR) / Measles, Mumps, and Rubella (MMR) Vaccination\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"What is the schedule for vaccinations in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Everyday\",\"Once a week\",\"Once a month\",\"Other\"]},{\"type\":\"field\",\"field_name\":\"Is there a national guideline, job-aids, checklist, charts on Expanded Program on Immunization/National Immunization Program (e.g. Basic EPI Manual) in the facility today?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Are individual child vaccination cards or booklets (Child Health Record) maintained in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records kept\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.7\",\"section_name\":\"Child Growth Monitoring Services\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are Child Growth Monitoring services offered in this facility?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Measurement of weight\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Measurement of height\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Measurement of mid-upper arm circumference (MUAC)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"What is the schedule for conducting child growth monitoring in this facility\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Daily/Weekly\",\"Monthly/Quarterly\",\"Annual/Semi-annual\",\"Other\"]},{\"type\":\"field\",\"field_name\":\"Are any national guidelines, job-aids, checklist, and charts for growth monitoring (e.g. Child Growth Standards Manual) in the facility today?\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Are individual child records for growth monitoring maintained in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records kept\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.8\",\"section_name\":\"Child Preventive And Curative Services\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following carried out in this facility as part of child preventive and curative care services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Diagnosis and/or treatment of Pneumonia, Diarrhea, Dengue, and Measles (e.g. Provision of ORS + Zinc) \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Diagnosis and/or treatment of Malaria\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Diagnosis and/or treatment of Malnutrition (Moderate Acute Malnutrition and Severe Acute Malnutrition) \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Basic Oral Health Care\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Provide Vitamin A supplementation to children\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Provide Iron supplementation to low-birthweight infants\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Provide Iron supplementation for children (6-11 months) with anemia\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Provide Zinc supplementation to sick children with diarrhea\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Diagnosis and/or treatment of TB in children / Isoniazid Preventive Therapy\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Deworming\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Vitamin A supplementation to children\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Iron supplementation to children\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Iodine supplementation to children\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"What is the schedule for delivery of child preventive and curative care services in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Everyday\",\"Once a week\",\"Once a month\",\"Other\"],\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"parent\",\"field_name\":\"Are the following national guidelines available in the facility today?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Integrated Management of Child Illness Chart Booklet\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Micronutrient Supplementation Program Manual of Operations\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Infant and Young Child Feeding Manual\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Philippine Integrated Management of Acute Malnutrition (PIMAM) Guidelines\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Guidelines in the Implementation of Oral Health Program for Public Health Services in the Philippines\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"parent\",\"field_name\":\"Do you conduct the following diagnostic examinations in this facility at any time as part of child preventive and curative care services? \",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Hemoglobin determination \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Test parasite in stool (general microscopy) \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Malaria diagnostic capacity\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"Are individual child records (Child Health Record) for management of childhood illnesses maintained in this facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, observed\",\"Reported, not observed\",\"No records kept\"],\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.9\",\"section_name\":\"Adolescent Health Services\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Are the following services available in this facility as part of Adolescent Health Services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Education and counselling on health effects of tobacco/smoking, diet, oral hygiene, and Adolescent Sexual and Reproductive Health (ASRH) (RHU/BHS/School) \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Basic Oral Health Care Services\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"HIV and STI services\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Promotion of healthy diets, nutrition counselling and assessment of nutritional status\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"parent\",\"field_name\":\"Are the following national guidelines, job-aids, checklist, charts on adolescent health services in the facility today?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Adolescent Job Aid (AJA) Manual\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Adolescent Health Care for Primary Health Service Providers – Foundational Course Manual\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"Is there an adolescent-friendly space designated in the facility?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, Level 1\",\"Yes, Level 2\",\"Yes, Level 3\",\"Processing\",\"No\"],\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Are the health workers practicing minimum health standards like wearing of Face mask during provision of services for adolescents?\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]},{\"type\":\"sub-section\",\"section_number\":\"2.6.10\",\"section_name\":\"Referral\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Does this facility have referral forms and compile return referrals for:\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Antenatal care - Sexually transmitted infections\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Antenatal care - Laboratory\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Antenatal care - Ultrasound\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Postnatal care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Newborn care\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Family planning\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Child and adolescent health services\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"parent\",\"field_name\":\"Does the facility refer high risk patients to higher facilities for delivery services?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Referral form\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Transport (accredited ambulance and driver)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Memorandum of Agreement/Understanding or policy\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]}]},{\"type\":\"section\",\"section_number\":\"2.7\",\"section_name\":\"Equipment, Instruments, and Other Fixtures\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"2.7.1\",\"section_name\":\"Antenatal Care\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Tape measure\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Fetal Doppler\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Examination table with/without stirrups\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Digital thermometer\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Ultrasound Machine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"table\",\"field_name\":\"For Basic Instruments for Oral Health, please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Mouth Mirror\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Explorer\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Cotton Pliers\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Excavator\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Filling Instruments\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Forceps\",\"field_code\":\"1\"}]},{\"type\":\"table\",\"field_name\":\"For Essential Supplies/Materials for Oral Health, please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Treatment Records Forms Cotton\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Cotton\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Prophy Brushes\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Gloves\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Burs F. Anesthesia\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Needles\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Permanent Filling Materials\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Temporary J. Medicines\",\"field_code\":\"1\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.7.2\",\"section_name\":\"Delivery Services\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Pulse Oximeter (Pedia/Adult)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Stethoscope, for Pediatric Use\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Delivery Table with pail\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Newborn Resuscitation Table or equivalent \",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Examination or Patient Bed w/ clean sheets/linen and footstoo\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Delivery Pack (Consists of 2 Hemostat Forceps, 1 Needle Holder, 1 Surgical Scissor, 1 Tissue Forceps)\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Bandage scissors\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Thumb forceps\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Umbilical cord scissors\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Disposable delivery kit (sterile cord clip or ties, plastic sheet to place under mother and sterile blade)\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Instrument Tray with Cover\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Kidney basin\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Instrument Cabinet\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Instrument Table or equivalent \",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Storage Containers with Cover for Dry Cotton Balls\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Jar with cover and without cover \",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Vaginal speculum (medium or large)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Sponge Forceps\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Suction Apparatus\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Suction catheter (adult and newborn sizes) \",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Rubber Suction Bulb / Penguin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Ambu bag or self-inflating bag (adult and pediatric)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Oxygen Tank with Regulator and Humidifier \",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Cone Mask, may be improvised \",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Newborn Size Mask 0 and 1\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Nebulizer (portable) \",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Examination Light (Gooseneck Lamp or equivalent)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Room Thermometer\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"IV Stand or equivalent\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Thermometer, Non-Mercury\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Tape Measure\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Wall Clock with Seconds hand\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Slippers for use in Delivery Area\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Bench\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Cabinet\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Chair\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Desk\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Electric fan\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Autoclave/Steam sterilizer or its equivalent\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Emergency light/ flashlight\",\"field_code\":\"1\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.7.3\",\"section_name\":\"Newborn Care\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Apgar and Ballard Scoring Chart\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Drying rack\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Newborn Screening (NBS) filter card\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.7.4\",\"section_name\":\"Family Planning\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"BP Apparatus\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Tenaculum Forceps\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Mayo Scissors\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Placental Forceps\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"10” Ovum Forceps \",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"10” Straight Forceps \",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"10” Narrow or “Alligator” Forceps\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Uterine Sound\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Vaginal Speculum, Different Sizes\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Kelly Pad\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Gooseneck Lamp (or equivalent)\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Printed materials/ posters for patient education\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Scalpel Blade holder for no. 2\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Scalpel Blade no. 11\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Mosquito Forcep\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Progestin Subdermal Implant (PSI) Ancillary kit\",\"field_code\":\"1\",\"applicable\":[\"Safe Birthing Facility\",\"Infirmary\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.7.5\",\"section_name\":\"Child Vaccination\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"EPI monitoring chart\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Vaccine carriers\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Ice packs\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Cold-Chain Temperature Monitoring Chart\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Vaccine refrigerator or freezer\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Temperature monitoring devices (thermometer)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Sharps container (“safety box”)\",\"field_code\":\"1\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.7.6\",\"section_name\":\"Child Monitoring Services\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Height or Length board\",\"field_code\":\"1\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"2.7.7\",\"section_name\":\"Child Preventive and Curative Care Services\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Please tell/show me if the following medical equipment and instruments are available in the facility today.\",\"field_code\":\"1\",\"table_type\":\"simple-table\",\"columns\":[\"Observed and Functioning\",\"Observed but NOT Functioning\",\"Reported but NOT Seen\",\"Not Available\"],\"rows\":[{\"type\":\"field\",\"field_name\":\"Pediatric BP apparatus\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Other device (e.g. cellphone) that can measure seconds\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Dental Chair\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Air Compressor\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Ultrasonic Scaler\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Light Curing Machine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Dental Instruments\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Calibrated ½ or 1-liter measuring jar for ORS\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Oxygen tank with regulator and humidifier\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Nebulizer\",\"field_code\":\"1\"}]}]}]}]},{\"section_number\":3,\"section_name\":\"Health Workforce\",\"section_description\":\"The health workforce can be defined as “all people engaged in actions whose primary intent is to enhance health” (WHO, 2010). These human resources include clinical staff, such as physicians, nurses, pharmacists and dentists, as well as management and support staff, i.e. those who do not deliver services directly but are essential to the performance of health systems, such as managers, ambulance drivers and accountants.\",\"has_subsection\":true,\"section_body\":[{\"type\":\"section\",\"section_number\":\"3.1\",\"section_name\":\"Health Care Personnel\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, on the basis of the highest technical or professional qualification.\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Full Time\",\"type\":\"parent\",\"children\":[{\"name\":\"Plantilla\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Job Order / Casual\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Deployed by DOH\",\"type\":\"numeric\",\"code\":\"3\"}]},{\"name\":\"Part time\",\"type\":\"numeric\",\"code\":\"4\"},{\"name\":\"Volunteer\",\"type\":\"numeric\",\"code\":\"5\"},{\"name\":\"# of hours in a facility per month\",\"type\":\"numeric\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Generalist Medical Doctors (Non-Specialist)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Registered Nurse\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Registered Midwife\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Registered Pharmacist\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Medical Technologist\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Dentist\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Dental Aide\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Ambulance Driver / Emergency Transport Driver\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Nutritionist / Dietician\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"table\",\"field_name\":\"I have a few questions on staffing for this facility. Please tell me how many staff with each of the following qualifications is currently assigned to, employed by, or seconded to this facility, whether full time or part time. Please count each staff member only once, on the basis of the highest technical or professional qualification.\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Volunteer\",\"type\":\"numeric\",\"code\":\"5\"},{\"name\":\"# of hours in a facility per month\",\"type\":\"numeric\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Active Barangay Health Worker (BHW)\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Barangay Nutrition Scholar (BNS)\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Community Health Volunteers (Who Are Not BHW)\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"Is there a health service provider present at all times, or officially on call for the facility at all times (24hrs a day including weekends) for emergencies and/or deliveries?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes, schedule is posted publicly\",\"Yes, but no schedule/list is posted\",\"No 24 hrs staff\",\"Don’t know\"],\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"On average, how many hours is this facility open?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"24 hrs, 7 days a week\",\"24 hrs, 5 days a week (close weekends)\",\"8 hrs/day, 5 days a week (40 hrs) \",\"2-4 days per week (<40hrs)\",\"2-4 days per month\",\"Once a month\"]}]},{\"type\":\"section\",\"section_number\":\"3.2\",\"section_name\":\"Health Care Personnel Trainings\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"3.2.1\",\"section_name\":\"Antenatal Care\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"BHWs\",\"type\":\"numeric\",\"code\":\"4\"},{\"name\":\"Others\",\"type\":\"numeric\",\"code\":\"5\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Interpersonal Communication Skills (ICS)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Community Tracking Tool\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Supportive Supervision\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Diagnosis and Treatment of Malaria in Pregnancy\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Diagnosis and/or Treatment of STI, excluding HIV\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"HIV Counseling\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.2\",\"section_name\":\"Delivery Services\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"BHWs\",\"type\":\"numeric\",\"code\":\"4\"},{\"name\":\"Others\",\"type\":\"numeric\",\"code\":\"5\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Basic Life Support (BLS)\",\"field_code\":\"1\"}]},{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Basic Emergency Obstetric and Neonatal Care (BEmONC)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Essential Intrapartum and Newborn Care (EINC)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Lactation Management Training (LMT)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Expanded Newborn Screening Training\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Maternal Death Review and Reporting System (MDRRS)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Maternal, Neonatal and Infant Death Reporting System (MNIDRS)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.3\",\"section_name\":\"Postnatal Care\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"BHWs\",\"type\":\"numeric\",\"code\":\"4\"},{\"name\":\"Others\",\"type\":\"numeric\",\"code\":\"5\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Infant and Young Child Feeding / Lactation Management Training / Management of Breastfeeding Difficulties (any one)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Kangaroo Mother Care for Premature / Very Small Babies\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Modern Methods of Family Planning\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Postpartum Intrauterine Device Insertion\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.4\",\"section_name\":\"Newborn Care\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Expanded Program on Immunization / National Immunization Program\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.5\",\"section_name\":\"Family Planning\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"BHWs\",\"type\":\"numeric\",\"code\":\"4\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Basic Family Planning or Family Planning Competency-Based Training (FPBCT) Level 1\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"FPCBT Level 2: Interval IUD insertion and Removal\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"FPCBT Level 2: Post-Partum IUD Insertion and Removal\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"FPCBT Level 2: Progestin-only Subdermal Implant Insertion and Removal\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"No-Scalpel Vasectomy (Training for Physicians)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Bilateral Tubal Ligation-Mini-Laparotomy (for Hospitals)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.6\",\"section_name\":\"Child Vaccination\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"BHWs\",\"type\":\"numeric\",\"code\":\"4\"},{\"name\":\"Others\",\"type\":\"numeric\",\"code\":\"5\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Philippine Integrated Management of Acute Malnutrition (PIMAM)/ Training on Community-Based Management of Acute Malnutrition\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]},{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Growth Monitoring or Training Course on Child Growth Standards\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Integrated Management of Child Illness\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Management of TB in Children\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Maternal Nutrition and Infant Young Child Feeding (MNIYCF)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Capacity Enhancement Course – Universal Health Care, Prevention and Detection of Early Childhood Caries (ECC)\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Expanded Program on Immunization/National Immunization Program\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Cold Chain Management Training\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.7\",\"section_name\":\"Adolescent Health Services\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Have you or any health worker assigned in this facility been trained in the following within the past 5 years?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Midwives\",\"type\":\"numeric\",\"code\":\"3\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"6\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Adolescent Job Aid (AJA)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Healthy Young Ones\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Adolescent Health Care for Primary Health Service Providers – Foundational Course\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Comprehensive Management on Adolescent Health?\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Adolescent Health, Education and Practical Training (ADEPT)\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"3.2.8\",\"section_name\":\"Other Trainings\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"FHSIS Training\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Doctors\",\"type\":\"numeric\",\"code\":\"1\"},{\"name\":\"Nurses\",\"type\":\"numeric\",\"code\":\"2\"},{\"name\":\"Total\",\"type\":\"total\",\"code\":\"3\"}],\"rows\":[{\"type\":\"field\",\"field_name\":\"SMART Verbal Autopsy (VA) Training\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"International Classification of Diseases (ICD)\",\"field_code\":\"1\"}]}]}]}]},{\"section_number\":4,\"section_name\":\"Financing\",\"section_description\":\"Accreditations that allow facilities to apply for reimbursements. Health financing refers to the “function of a health system concerned with the mobilization, accumulation and allocation of money to cover the health needs of the people, individually and collectively, in the health system… the purpose of health financing is to make funding available, as well as to set the right financial incentives to providers, to ensure that all individuals have access to effective public health and personal health care” (WHO, 2010).\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"4.1\",\"section_name\":\"Philippine Health Insurance Corporation (PhilHealth)\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"Does this facility have licensing and certification from PhilHealth?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Konsulta Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\" MCP (Maternity Care Package)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"TB-DOTS Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Newborn Screening\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Animal Bite Treatment Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Out-Patient Malaria Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"COVID-19 Community Isolation Benefit Package (CCIBP)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"4.2\",\"section_name\":\"Budget allocation for health\",\"section_content\":[{\"type\":\"parent\",\"field_name\":\"What is the budget allocation for the following programs?\",\"field_code\":\"1\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"],\"children\":[{\"type\":\"field\",\"field_name\":\"Safe Motherhood\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Family Planning\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Child Health (including National Immunization Programme)\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Nutrition\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Adolescent Health Development\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Oral Health\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Information, Communication and Technology (ICT)/ Electronic Medical Records (EMR)\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"others\":true,\"field_name\":\"Other programme\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]}]}]}]},{\"section_number\":5,\"section_name\":\"Access to Essential Medicines and Services (including supplies for readiness)\",\"section_description\":\"According to the WHO framework for health systems, a well-functioning health system ensures equitable access to essential medical products, vaccines and technologies of assured quality, safety, efficacy and cost effectiveness, and their scientifically sound and cost-effective use. Monitoring access to essential medicines is closely intertwined with at least two other building blocks: service delivery and governance.\",\"has_subsection\":true,\"section_body\":[{\"type\":\"section\",\"section_number\":\"5.1\",\"section_name\":\"Antenatal Care\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Iron + Folic Acid Tablet (1 box)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Tetanus Toxoid vaccine/ Tetanus-diphtheria (Td)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Calcium Carbonate (1 box)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Methyldopa Tablet\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Amoxicillin Capsule\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Antibiotics Appropriate for Bacterial STI (e.g Ceftriaxone, Azithromycin)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Anti-Malarials For Pregnant Women (for endemic areas only)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Anti-Retrovirals\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Medical examination gloves\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Lubricant (water-based)\",\"field_code\":\"1\"}]}]},{\"type\":\"section\",\"section_number\":\"5.2\",\"section_name\":\"Delivery Services\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Emergency kit or cart/ Portable kit or trolley\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Injectable Uterotonic (e.g. Oxytocin, ergometrine) at least 10 ampules\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Injectable Broad-Spectrum Antibiotic (Pen. G, Gentamicin, Amikacin, Metronidazole, etc.- may include ceftriaxone and benzathine penicillin)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Injectable Magnesium Sulfate (at least 5 ampules 500 mg/2 mL ampule)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"At least one of the following oral antibiotics (preferably amoxicillin): amoxicillin, ampicillin, cephalosporin, cloxacillin, erythromycin, azithromycin, trimethoprim + sulfamethoxazole, tetracycline or doxycycline (RPR + partner), metronidazole\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Methyldopa\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"At least one of the following tetracycline eye ointment: eye antimicrobial (1% silver nitrate or 2.5% povidone iodine) or erythromycin ophthalmic ointment 5% *\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"At least mebendazole or all of the following if area is malaria infested: artemether or quinine, chloroquine tablet, sulphadoxine-pyremethane and mebendazole\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"IV Infusion Set\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"IV Cannula, Gauge 18 and 19\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Injectable Calcium Gluconate 10 mg/ampule\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Injectable Hydralazine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Nifedipine tablet\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Diphenhydramine 50 mg/ampule\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"At least one of the following corticosteroids: dexamethasone vial or ampule or betamethasone vial or ampule\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Paracetamol Tablet 500 mg (at least 1 box of 100’s) or Injectable\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Epinephrine/adrenaline\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Atropine 1 mg/ml ampule\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Lignocaine/Lidocaine/Xylocaine (1 multidose vial at 50 mL) or 5 pcs. poly amp at 5 mL each\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Cord Clamp\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Gloves (1 box)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Disposable Syringes with Needles\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Plaster\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"IV Fluids: glucose 50% solution (1 polyamp 50 mL), normal saline 0.9% (at least 3 bottles), Ringer Lactate (at least 5 bottles D5LR) and plain LR (at least 3 bottles)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Absorbable Suture\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Cutting Needle\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Round Needle\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Cotton Balls (1 pack)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Cotton pledgets (1 pack)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Gauze (1 pack)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Nasal Cannula, Adult\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Inhaled Bronchodilators\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Partograph\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Surgical Cap (1 box)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Surgical mask (1 box)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Patient Gown\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Scrub suit\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile drape\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Plastic Apron\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Kelly pad\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Urinary catheter w/ bag or container for urine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Cloth for Drying and Warming the newborn\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Clean towels\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sanitary pads\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Baby feeding cup\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Soap\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Antiseptic solution (iodophors or chlorhexidine/cetrinide)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Bleach powder/tablet-Jik (chlorine base compound)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Lubricant (water-base)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]}]}]},{\"type\":\"section\",\"section_number\":\"5.3\",\"section_name\":\"Postnatal Care\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Vitamin A 200,000 IU Capsules (at least 2 bottles)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Iron + Folic Acid Tablet\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Oral Antibiotics\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Oral Anti-Hypertensive Medications for Postpartum\",\"field_code\":\"1\"}]}]},{\"type\":\"section\",\"section_number\":\"5.4\",\"section_name\":\"Newborn Care\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Vitamin K Ampules (at least 2 ampules)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Hepatitis B Vaccine (stored inside ref at temp. between 2-8 degree Celsius)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"BCG Vaccine\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Erythromycin Eye Ointment 0.5%\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Injectable Ampicillin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Gentamicin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Amikacin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Gentian Violet\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile water\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Clean gloves\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Dry cotton balls/swabs%\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Newborn Screening Card/Kit\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Newborn screening filter\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Sterile Lancets 3mm\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Warm moist towel\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]}]}]},{\"type\":\"section\",\"section_number\":\"5.5\",\"section_name\":\"Family Planning\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Combined oral contraceptive pills\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Progestin only contraceptive pills\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Progestin-only injectable contraceptives\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Male condom\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Intrauterine device\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Implant\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Cycle beads for standard days method\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Anesthesia\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Bleach for Preparing 0.5% Decontaminating Solution\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Mops and Rags\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Cottons\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Gauze\",\"field_code\":\"1\"}]}]},{\"type\":\"section\",\"section_number\":\"5.6\",\"section_name\":\"Child Vaccination\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"BCG Vaccine and diluent\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"DPT-Hib+HepB (Pentavalent)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Oral Polio Vaccine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Inactivated Polio Vaccine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Pneumococcal Conjugate Vaccine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Rotavirus Vaccine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"MR/MMR Vaccine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"ECCD/Mother-Baby Book\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Blank/unused individual child vaccination cards or booklets\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Index cards (summary forms)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Single-use standard disposable syringes with needles or auto-disable syringes with needles\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Disposable Latex Gloves\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Cotton Balls\",\"field_code\":\"1\"}]}]},{\"type\":\"section\",\"section_number\":\"5.7\",\"section_name\":\"Child Preventive and Curative Care Services\",\"section_body\":[{\"type\":\"table\",\"field_name\":\"Are the following medicines, supplies and commodities available in this facility today? (*At least one complete dose available today)\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Available*\",\"type\":\"radio\",\"code\":\"1\",\"options\":[\"Valid, not expired\",\"Valid, but expired\",\"No stock (Prescribe or Refer)\"],\"trigger\":[\"No stock (Prescribe or Refer)\"]},{\"name\":\"Has there been STOCK OUT in the past 3 months?\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"Yes\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Fuji 9 GIC for atraumatic restorative treatment\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Fluoride varnish\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Pit and Fissure sealant\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Tooth brush\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Poly Paste Toothpaste\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Amoxicillin suspension drops and syrup\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Cefalexin syrup\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Cotrimoxazole suspension\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Flucloxacillin syrup\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Injectable Benzathine Benzylpenicillin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Injectable Ceftriaxone\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Injectable Erythromycin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Injectable Azithromycin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Streptomycin injectable\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Epinephrine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Paracetamol syrup\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Mefenamic Acid\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Tranexamic Acid\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Injectable Adrenaline\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\"]},{\"type\":\"field\",\"field_name\":\"Injectable Diazepam\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"Lidocaine 1%\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Prednisone Tablet\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Salbutamol nebulizer solution\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Metered-dose inhaler (MDI)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Vitamin A 100,000 I.U capsules (at least 1 bottle)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Zinc Supplements (drops, syrup, tablet)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Reformulated ORS with Zinc\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"FeSO4 drops (15 mg elemental iron/mL)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"FeSO4 syrup (30 mg elemental Iron/5 ml)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"FeSO4 tablet containing 60 mg elemental Iron with 400 mcg folic acid (coated)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Iodized oil capsule with 200 mg. Iodine\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"10% Glucose\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"10% glucose infusion (Neonatalyte)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Formula 75 (F75\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Ready-to-Use Therapeutic Food (RUTF)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Albendazole (400 mg) tablet\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Mebendazole (500 mg) tablet\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Nystatin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Chloramphenicol ointment\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Povidone Iodine cream (5%) or ointment (10%)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Chlorhexidine 0.2% or salt water\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Calamine lotion\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Hydrocortisone acetate 1% cream\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Imidazole cream (e.g. clotrimazole 2%)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Acyclovir cream/ointment\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Podophyllum Resin 20% and Salicylic Acid 25% ointment\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Petroleum Jelly\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Selenium Sulfide 2% suspension\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Sulfur ointment\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Ethambutol\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Isoniazid\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Pyrazinamide\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Rifampicin\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Isoniazid + Rifampicin (2FDC)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Isoniazid + Ethambutol (EH) (2FDC)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Isoniazid + Rifampicin + Pyrazinamide (RHZ) (3FDC)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Isoniazid + Rifampicin + Ethambutol (RHE) (4FDC)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Cup and spoon\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Nasal cannula/nasal prongs\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"FG-8 Nasogastric tube\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Blood glucose testing strips\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Pure protein derivative (PPD)\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]}]},{\"section_number\":6,\"section_name\":\"Health Information System\",\"section_description\":\"Sound and reliable information is the foundation of decision-making across all health system building blocks. It is essential for health system policy development and implementation, governance and regulation, health research, human resources development, health education and training, service delivery and financing\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"6.1\",\"section_name\":\"Electronic Medical Records (EMR)\",\"section_content\":[{\"type\":\"conditional-field\",\"field_name\":\"Are Electronic Medical Records (EMR) present in the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"],\"children\":[{\"type\":\"field\",\"field_name\":\"Name of EMR\",\"field_code\":\"1\",\"response_type\":\"text\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Name of Health Information Technology Provider\",\"field_code\":\"1\",\"response_type\":\"text\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"parent\",\"field_name\":\"Does the EMR have these functionalities?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Patients Consultation Recording\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Inventory of Logistics\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Environmental\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Financial for PhilHealth Claims\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"field\",\"field_name\":\"Does the facility submit reports to PhilHealth through EMR (utilizing eClaims functions)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"parent\",\"field_name\":\"IP Monitoring\",\"field_code\":\"1\",\"children\":[{\"type\":\"conditional-field\",\"field_name\":\"Does the facility utilize EMR for household profiling?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"],\"children\":[{\"type\":\"field\",\"field_name\":\"Provide the Household Profiling template used\",\"field_code\":\"1\",\"response_type\":\"text\"}]},{\"type\":\"field\",\"field_name\":\"Is this data submitted for regional level analysis?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"Yes\",\"No\",\"Not Applicable\"],\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]},{\"type\":\"table\",\"field_name\":\"Types of PhilHealth Claims\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Is claiming of PhilHealth packages available within the facility?\",\"type\":\"y/n\",\"code\":\"1\",\"trigger\":[\"No\"]},{\"name\":\"Name of the system used\",\"type\":\"text\",\"code\":\"2\",\"default\":[\"N/A\"]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"E-Konsulta\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Maternal Care Package (MCP)\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"TB-DOTS\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Animal Bite Package\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Family Planning Claims\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"COVID Isolation Claims\",\"field_code\":\"1\"}]},{\"type\":\"parent\",\"field_name\":\"FHSIS Reporting\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Does the facility submit FHSIS reports to DOH through EMR?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"parent\",\"field_name\":\"Are there any other reporting tools present?\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Target Client List (TCL) \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Summary Table \",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Others 1 (Pls. specify) \",\"field_code\":\"1\",\"response_type\":\"text\"},{\"type\":\"field\",\"field_name\":\"Others 2 (Pls. specify) \",\"field_code\":\"1\",\"response_type\":\"text\"},{\"type\":\"field\",\"field_name\":\"Others 3 (Pls. specify) \",\"field_code\":\"1\",\"response_type\":\"text\"},{\"type\":\"field\",\"field_name\":\"Others 4 (Pls. specify) \",\"field_code\":\"1\",\"response_type\":\"text\"}]}]},{\"type\":\"parent\",\"field_name\":\"Presence of Telemedicine\",\"field_code\":\"1\",\"children\":[{\"type\":\"conditional-field\",\"field_name\":\"Is telemedicine available in the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"children\":[{\"type\":\"field\",\"field_name\":\"Name of provider\",\"field_code\":\"1\",\"response_type\":\"text\"},{\"type\":\"parent\",\"field_name\":\"Is this technology utilized in telemedicine\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"in-house web-application\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"SMS/call\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Video Conferencing\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"social-media\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"web-application\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]}]},{\"type\":\"parent\",\"field_name\":\"Presence/Utilization of Other DOH Information Systems \",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"Online Malaria Information System (OLMIS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Integrated Tuberculosis Information System (ITIS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"National Rabies Information System (NaRIS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Philippine Registry for Persons with Disability (PRPWD)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Health Emergency Allowance Processing System (HEAPS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Electronic Logistic Management Information System (eLMIS)\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Online National Electronic Injury Surveillance System (ONEISS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Philippine Integrated Disease Surveillance and Response (PIDSR)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"National BHW Registry System (NBHWRS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"LGU Health Scorecard Information System (LGUHSC IS)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Health Facility Profile - DOH Data Collect Hub (HFPDDC)\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Rural Health Unit\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"6.2\",\"section_name\":\"Human Resources for ICT\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Human Resources for ICT\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Total Personnel\",\"type\":\"numeric\",\"code\":\"1\",\"trigger\":[0]},{\"name\":\"# Regular Personnel\",\"type\":\"numeric\",\"code\":\"2\",\"default\":[\"0\"]},{\"name\":\"# Contractual/Job Order Personnel \",\"type\":\"numeric\",\"code\":\"3\",\"default\":[\"0\"]},{\"name\":\"Source of Fund\",\"type\":\"parent\",\"children\":[{\"name\":\"LGU\",\"type\":\"y/n\",\"code\":\"4\",\"default\":[\"No\"]},{\"name\":\"DOH\",\"type\":\"y/n\",\"code\":\"5\",\"default\":[\"No\"]},{\"name\":\"Province\",\"type\":\"y/n\",\"code\":\"6\",\"default\":[\"No\"]},{\"name\":\"NGO\",\"type\":\"y/n\",\"code\":\"7\",\"default\":[\"No\"]}]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Presence of dedicated ICT personnel primarily functioning on EMR.\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Presence of designated personnel primarily functioning as Data Privacy Officer\",\"field_code\":\"1\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]}]},{\"type\":\"sub-section\",\"section_number\":\"6.3\",\"section_name\":\"ICT Equipment and Infrastructure\",\"section_content\":[{\"type\":\"sub-section\",\"section_number\":\"6.3.1\",\"section_name\":\"ICT Equipment\",\"section_content\":[{\"type\":\"table\",\"field_name\":\"Are the following items available in the facility?\",\"field_code\":\"1\",\"columns\":[{\"name\":\"Count\",\"type\":\"numeric\",\"code\":\"1\",\"trigger\":[0]},{\"name\":\"Source of Fund\",\"type\":\"parent\",\"code\":\"2\",\"children\":[{\"name\":\"LGU\",\"type\":\"y/n\",\"code\":\"2\",\"default\":[\"No\"]},{\"name\":\"DOH\",\"type\":\"y/n\",\"code\":\"3\",\"default\":[\"No\"]},{\"name\":\"Province\",\"type\":\"y/n\",\"code\":\"4\",\"default\":[\"No\"]},{\"name\":\"NGO\",\"type\":\"y/n\",\"code\":\"5\",\"default\":[\"No\"]}]}],\"rows\":[{\"type\":\"field\",\"field_name\":\"Desktop\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Laptop\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Scanner\",\"field_code\":\"1\"},{\"type\":\"field\",\"field_name\":\"Printer\",\"field_code\":\"1\"}]}]},{\"type\":\"sub-section\",\"section_number\":\"6.3.2\",\"section_name\":\"Presence of Internet Service Provider\",\"section_content\":[{\"type\":\"conditional-field\",\"field_name\":\"Is the internet available in the facility?\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"children\":[{\"type\":\"field\",\"field_name\":\"Name of Internet Service Provider\",\"field_code\":\"1\",\"response_type\":\"text\"},{\"type\":\"field\",\"field_name\":\"Internet Speed\",\"field_code\":\"1\",\"response_type\":\"text\"},{\"type\":\"parent\",\"field_name\":\"Source of Fund\",\"field_code\":\"1\",\"children\":[{\"type\":\"field\",\"field_name\":\"LGU\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"DOH\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"Province\",\"field_code\":\"1\",\"response_type\":\"y/n\"},{\"type\":\"field\",\"field_name\":\"NGO\",\"field_code\":\"1\",\"response_type\":\"y/n\"}]}]},{\"type\":\"field\",\"field_name\":\" Is there a presence of a Local Area Network (LAN), and what is the type of topology?\",\"field_code\":\"1\",\"response_type\":\"radio\",\"options\":[\"WiFi\",\"LAN-cabling\",\"LAN and WiFi\",\"Not available\"]}]}]}]},{\"section_number\":7,\"section_name\":\"Outcome Indicators\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"7.1\",\"section_name\":\"MNCHN-related Impact/Outcome Indicators\",\"section_content\":[{\"type\":\"field\",\"field_name\":\"How many maternal deaths were registered in the past completed year?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Of those who were registered, how many deaths were reviewed?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"How many neonatal deaths aged 0-28 days were registered in the past completed year?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Of those who were registered, how many deaths were reviewed?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"How many infant deaths (< 1 year of age) were registered in the past completed year?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Of those who were registered, how many deaths were reviewed?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"How many child deaths aged 12-59 months were registered in the past completed year?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\" How many children 0-59 months who have manifested low weight for height (wasting) were recorded in the current year?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\" How many children 0-59 months who have severe acute malnutrition (SAM) were recorded in the current year? \",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\" How many children 0-59 months who have manifested low height for age (stunting) were recorded in the current year?\",\"field_code\":\"1\",\"response_type\":\"numeric\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Availability of Emergency Transport 24/7\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]}]}]},{\"section_number\":8,\"section_name\":\"Health Regulation\",\"section_body\":[{\"type\":\"sub-section\",\"section_number\":\"8.1\",\"section_name\":\"DOH Licensing\",\"section_content\":[{\"type\":\"field\",\"field_name\":\"Safe Birthing Facility\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"NBS\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"FP\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Konsulta Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]},{\"type\":\"sub-section\",\"section_number\":\"8.2 \",\"section_name\":\"PHIC Accreditation\",\"section_content\":[{\"type\":\"field\",\"field_name\":\"Safe Birthing Facility\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"NBS\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\"]},{\"type\":\"field\",\"field_name\":\"FP\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Safe Birthing Facility\",\"Rural Health Unit\",\"Barangay Health Station\",\"City Health Office\"]},{\"type\":\"field\",\"field_name\":\"Konsulta Package\",\"field_code\":\"1\",\"response_type\":\"y/n\",\"applicable\":[\"Infirmary\",\"Rural Health Unit\",\"City Health Office\"]}]}]}]','1100000000','2023-10-29 13:11:30','2023-10-29 13:11:30',NULL,NULL);
/*!40000 ALTER TABLE `assessment_indicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_responses`
--

DROP TABLE IF EXISTS `assessment_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_responses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `facility_id` int unsigned NOT NULL,
  `assessment_id` int unsigned NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `province_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `municipality_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `batch_id` int unsigned NOT NULL,
  `parent_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `item_name` text COLLATE utf8mb4_general_ci NOT NULL,
  `item_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `item_response` text COLLATE utf8mb4_general_ci,
  `item_notes` text COLLATE utf8mb4_general_ci,
  `item_notes_resolve` tinyint(1) DEFAULT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `updated_by` int unsigned DEFAULT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `facility_id` (`facility_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `region_code` (`region_code`),
  KEY `province_code` (`province_code`),
  KEY `municipality_code` (`municipality_code`),
  KEY `batch_id` (`batch_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`),
  CONSTRAINT `assessment_responses_ibfk_73` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`),
  CONSTRAINT `assessment_responses_ibfk_74` FOREIGN KEY (`assessment_id`) REFERENCES `facility_assessments` (`id`),
  CONSTRAINT `assessment_responses_ibfk_75` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `assessment_responses_ibfk_76` FOREIGN KEY (`province_code`) REFERENCES `location_provinces` (`province_code`),
  CONSTRAINT `assessment_responses_ibfk_77` FOREIGN KEY (`municipality_code`) REFERENCES `location_municipalities` (`municipality_code`),
  CONSTRAINT `assessment_responses_ibfk_78` FOREIGN KEY (`batch_id`) REFERENCES `assessment_batches` (`id`),
  CONSTRAINT `assessment_responses_ibfk_79` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `assessment_responses_ibfk_80` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `assessment_responses_ibfk_81` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=195078 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_responses`
--

LOCK TABLES `assessment_responses` WRITE;
/*!40000 ALTER TABLE `assessment_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facilities`
--

DROP TABLE IF EXISTS `facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facilities` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `facility_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `facility_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `gis_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `province_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `municipality_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `barangay_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `barangay_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `street_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `building_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zip_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `facility_type_id` int unsigned NOT NULL,
  `facility_head` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `facility_head_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `managing_authority` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `with_sbf` tinyint(1) DEFAULT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `updated_by` int unsigned DEFAULT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `facility_code` (`facility_code`),
  UNIQUE KEY `facility_code_2` (`facility_code`),
  UNIQUE KEY `facility_code_3` (`facility_code`),
  UNIQUE KEY `facility_code_4` (`facility_code`),
  UNIQUE KEY `facility_code_5` (`facility_code`),
  UNIQUE KEY `facility_code_6` (`facility_code`),
  UNIQUE KEY `facility_code_7` (`facility_code`),
  UNIQUE KEY `facility_code_8` (`facility_code`),
  UNIQUE KEY `facility_code_9` (`facility_code`),
  UNIQUE KEY `facility_code_10` (`facility_code`),
  KEY `region_code` (`region_code`),
  KEY `province_code` (`province_code`),
  KEY `municipality_code` (`municipality_code`),
  KEY `facility_type_id` (`facility_type_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`),
  CONSTRAINT `facilities_ibfk_64` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `facilities_ibfk_65` FOREIGN KEY (`province_code`) REFERENCES `location_provinces` (`province_code`),
  CONSTRAINT `facilities_ibfk_66` FOREIGN KEY (`municipality_code`) REFERENCES `location_municipalities` (`municipality_code`),
  CONSTRAINT `facilities_ibfk_67` FOREIGN KEY (`facility_type_id`) REFERENCES `facility_types` (`id`),
  CONSTRAINT `facilities_ibfk_68` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facilities_ibfk_69` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facilities_ibfk_70` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2396 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facilities`
--

LOCK TABLES `facilities` WRITE;
/*!40000 ALTER TABLE `facilities` DISABLE KEYS */;
INSERT INTO `facilities` VALUES (1034,'BRAULIO E. DUJALI MUNICIPAL HEALTH CENTER','DOH000000000000127',NULL,'1100000000','1102300000','1102323000','DUJALI','1102323002',NULL,NULL,'8100',3,NULL,NULL,NULL,NULL,'Local Government Unit',NULL,NULL,NULL,NULL,'2023-10-29 05:45:14','2023-10-29 05:45:14',NULL),(1035,'CABAY-ANGAN BARANGAY HEALTH STATION','DOH000000000003904',NULL,'1100000000','1102300000','1102323000','CABAYANGAN','1102323001',NULL,NULL,'8100',4,NULL,NULL,NULL,NULL,'Local Government Unit',NULL,NULL,NULL,NULL,'2023-10-29 05:45:14','2023-10-29 05:45:14',NULL),(1036,'TANGLAW BARANGAY HEALTH STATION','DOH000000000005348',NULL,'1100000000','1102300000','1102323000','TANGLAW','1102323005',NULL,NULL,'8100',4,NULL,NULL,NULL,NULL,'Local Government Unit',NULL,NULL,NULL,NULL,'2023-10-29 05:45:15','2023-10-29 05:45:15',NULL),(1037,'NEW CASAY BARANGAY HEALTH STATION','DOH000000000006276',NULL,'1100000000','1102300000','1102323000','NEW CASAY','1102323004',NULL,NULL,'8100',4,NULL,NULL,NULL,NULL,'Local Government Unit',NULL,NULL,NULL,NULL,'2023-10-29 05:45:15','2023-10-29 05:45:15',NULL),(1038,'DUJALI BARANGAY HEALTH STATION','DOH000000000013007',NULL,'1100000000','1102300000','1102323000','DUJALI','1102323002',NULL,NULL,'8100',4,NULL,NULL,NULL,NULL,'Local Government Unit',NULL,NULL,NULL,NULL,'2023-10-29 05:45:15','2023-10-29 05:45:15',NULL),(1039,'MAGUPISING BARANGAY HEALTH STATION','DOH000000000013046',NULL,'1100000000','1102300000','1102323000','MAGUPISING','1102323003',NULL,NULL,'8100',4,NULL,NULL,NULL,NULL,'Local Government Unit',NULL,NULL,NULL,NULL,'2023-10-29 05:45:15','2023-10-29 05:45:15',NULL);
/*!40000 ALTER TABLE `facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_assessments`
--

DROP TABLE IF EXISTS `facility_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_assessments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `facility_id` int unsigned NOT NULL,
  `batch_id` int unsigned NOT NULL,
  `assessor_id` int unsigned DEFAULT NULL,
  `reviewer_id` int unsigned DEFAULT NULL,
  `approver_id` int unsigned DEFAULT NULL,
  `dmo_approver_id` int unsigned DEFAULT NULL,
  `status` enum('open','assigned','started','reviewed','submitted','pho-approved','completed','ongoing-approval') COLLATE utf8mb4_general_ci DEFAULT 'open',
  `validator_signature` longtext COLLATE utf8mb4_general_ci,
  `mho_notes` longtext COLLATE utf8mb4_general_ci,
  `pho_notes` longtext COLLATE utf8mb4_general_ci,
  `dmo_notes` longtext COLLATE utf8mb4_general_ci,
  `respondents` longtext COLLATE utf8mb4_general_ci,
  `responses` longtext COLLATE utf8mb4_general_ci,
  `started_at` datetime DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `updated_by` int unsigned DEFAULT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `draft_responses` longtext COLLATE utf8mb4_general_ci,
  `indicator_id` int unsigned DEFAULT NULL,
  `current_step` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facility_id` (`facility_id`),
  KEY `batch_id` (`batch_id`),
  KEY `assessor_id` (`assessor_id`),
  KEY `reviewer_id` (`reviewer_id`),
  KEY `approver_id` (`approver_id`),
  KEY `dmo_approver_id` (`dmo_approver_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `facility_assessments_ibfk_127` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`),
  CONSTRAINT `facility_assessments_ibfk_128` FOREIGN KEY (`batch_id`) REFERENCES `assessment_batches` (`id`),
  CONSTRAINT `facility_assessments_ibfk_129` FOREIGN KEY (`assessor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_130` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_131` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_132` FOREIGN KEY (`dmo_approver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_133` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_134` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_135` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_assessments_ibfk_136` FOREIGN KEY (`indicator_id`) REFERENCES `assessment_indicators` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_assessments`
--

LOCK TABLES `facility_assessments` WRITE;
/*!40000 ALTER TABLE `facility_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `facility_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_group_assignment`
--

DROP TABLE IF EXISTS `facility_group_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_group_assignment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int unsigned NOT NULL,
  `facility_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `facility_id` (`facility_id`),
  CONSTRAINT `facility_group_assignment_ibfk_19` FOREIGN KEY (`group_id`) REFERENCES `facility_groups` (`id`),
  CONSTRAINT `facility_group_assignment_ibfk_20` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=374 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_group_assignment`
--

LOCK TABLES `facility_group_assignment` WRITE;
/*!40000 ALTER TABLE `facility_group_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `facility_group_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_group_indicator_assessors`
--

DROP TABLE IF EXISTS `facility_group_indicator_assessors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_group_indicator_assessors` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `group_id` int unsigned DEFAULT NULL,
  `indicator_id` int unsigned DEFAULT NULL,
  `assessor_id` int unsigned DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `indicator_id` (`indicator_id`),
  KEY `assessor_id` (`assessor_id`),
  CONSTRAINT `facility_group_indicator_assessors_ibfk_16` FOREIGN KEY (`group_id`) REFERENCES `facility_groups` (`id`),
  CONSTRAINT `facility_group_indicator_assessors_ibfk_17` FOREIGN KEY (`indicator_id`) REFERENCES `assessment_indicators` (`id`),
  CONSTRAINT `facility_group_indicator_assessors_ibfk_18` FOREIGN KEY (`assessor_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_group_indicator_assessors`
--

LOCK TABLES `facility_group_indicator_assessors` WRITE;
/*!40000 ALTER TABLE `facility_group_indicator_assessors` DISABLE KEYS */;
/*!40000 ALTER TABLE `facility_group_indicator_assessors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_groups`
--

DROP TABLE IF EXISTS `facility_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `province_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `assessor_id` int unsigned DEFAULT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `updated_by` int unsigned DEFAULT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_code` (`region_code`),
  KEY `province_code` (`province_code`),
  KEY `assessor_id` (`assessor_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`),
  CONSTRAINT `facility_groups_ibfk_55` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `facility_groups_ibfk_56` FOREIGN KEY (`province_code`) REFERENCES `location_provinces` (`province_code`),
  CONSTRAINT `facility_groups_ibfk_57` FOREIGN KEY (`assessor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_groups_ibfk_58` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_groups_ibfk_59` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_groups_ibfk_60` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_groups`
--

LOCK TABLES `facility_groups` WRITE;
/*!40000 ALTER TABLE `facility_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `facility_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_report_entries`
--

DROP TABLE IF EXISTS `facility_report_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_report_entries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int unsigned NOT NULL,
  `report_entry_id` int unsigned NOT NULL,
  `facility_id` int unsigned NOT NULL,
  `responses` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('open','started','submitted','approved','ongoing-approval','completed') COLLATE utf8mb4_general_ci DEFAULT 'open',
  `started_at` datetime DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `assessor_id` int unsigned DEFAULT NULL,
  `approver_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `current_step` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  KEY `report_entry_id` (`report_entry_id`),
  KEY `facility_id` (`facility_id`),
  KEY `assessor_id` (`assessor_id`),
  KEY `approver_id` (`approver_id`),
  CONSTRAINT `facility_report_entries_ibfk_41` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`),
  CONSTRAINT `facility_report_entries_ibfk_42` FOREIGN KEY (`report_entry_id`) REFERENCES `report_entries` (`id`),
  CONSTRAINT `facility_report_entries_ibfk_43` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`),
  CONSTRAINT `facility_report_entries_ibfk_44` FOREIGN KEY (`assessor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_report_entries_ibfk_45` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5538 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_report_entries`
--

LOCK TABLES `facility_report_entries` WRITE;
/*!40000 ALTER TABLE `facility_report_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `facility_report_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_report_entry_comments`
--

DROP TABLE IF EXISTS `facility_report_entry_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_report_entry_comments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `facility_report_entry_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `status` enum('open','resolved') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'open',
  `field_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `field_name` text COLLATE utf8mb4_general_ci,
  `comment` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facility_report_entry_id` (`facility_report_entry_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `facility_report_entry_comments_ibfk_10` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `facility_report_entry_comments_ibfk_9` FOREIGN KEY (`facility_report_entry_id`) REFERENCES `facility_report_entries` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_report_entry_comments`
--

LOCK TABLES `facility_report_entry_comments` WRITE;
/*!40000 ALTER TABLE `facility_report_entry_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `facility_report_entry_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facility_types`
--

DROP TABLE IF EXISTS `facility_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility_types`
--

LOCK TABLES `facility_types` WRITE;
/*!40000 ALTER TABLE `facility_types` DISABLE KEYS */;
INSERT INTO `facility_types` VALUES (1,'Infirmary'),(2,'Safe Birthing Facility'),(3,'Rural Health Unit'),(4,'Barangay Health Station'),(7,'City Health Office'),(8,'Hospital');
/*!40000 ALTER TABLE `facility_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_validation_workflow`
--

DROP TABLE IF EXISTS `form_validation_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_validation_workflow` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `process` longtext COLLATE utf8mb4_general_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `steps` longtext COLLATE utf8mb4_general_ci,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_code` (`region_code`),
  CONSTRAINT `form_validation_workflow_ibfk_1` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_validation_workflow`
--

LOCK TABLES `form_validation_workflow` WRITE;
/*!40000 ALTER TABLE `form_validation_workflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_validation_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_municipalities`
--

DROP TABLE IF EXISTS `location_municipalities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_municipalities` (
  `municipality_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `municipality_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `province_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`municipality_code`),
  KEY `region_code` (`region_code`),
  KEY `province_code` (`province_code`),
  CONSTRAINT `location_municipalities_ibfk_19` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `location_municipalities_ibfk_20` FOREIGN KEY (`province_code`) REFERENCES `location_provinces` (`province_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_municipalities`
--

LOCK TABLES `location_municipalities` WRITE;
/*!40000 ALTER TABLE `location_municipalities` DISABLE KEYS */;
INSERT INTO `location_municipalities` VALUES ('1102301000','Asuncion','1100000000','1102300000'),('1102303000','Carmen','1100000000','1102300000'),('1102305000','Kapalong','1100000000','1102300000'),('1102314000','New Corella','1100000000','1102300000'),('1102315000','City of Panabo','1100000000','1102300000'),('1102317000','Island Garden City of Samal','1100000000','1102300000'),('1102318000','Santo Tomas','1100000000','1102300000'),('1102319000','City of Tagum','1100000000','1102300000'),('1102322000','Talaingod','1100000000','1102300000'),('1102323000','Braulio E. Dujali','1100000000','1102300000'),('1102324000','San Isidro','1100000000','1102300000'),('1102401000','Bansalan','1100000000','1102400000'),('1102403000','City of Digos','1100000000','1102400000'),('1102404000','Hagonoy','1100000000','1102400000'),('1102406000','Kiblawan','1100000000','1102400000'),('1102407000','Magsaysay','1100000000','1102400000'),('1102408000','Malalag','1100000000','1102400000'),('1102410000','Matanao','1100000000','1102400000'),('1102411000','Padada','1100000000','1102400000'),('1102412000','Santa Cruz','1100000000','1102400000'),('1102414000','Sulop','1100000000','1102400000'),('1102501000','Baganga','1100000000','1102500000'),('1102502000','Banaybanay','1100000000','1102500000'),('1102503000','Boston','1100000000','1102500000'),('1102504000','Caraga','1100000000','1102500000'),('1102505000','Cateel','1100000000','1102500000'),('1102506000','Governor Generoso','1100000000','1102500000'),('1102507000','Lupon','1100000000','1102500000'),('1102508000','Manay','1100000000','1102500000'),('1102509000','City of Mati','1100000000','1102500000'),('1102510000','San Isidro','1100000000','1102500000'),('1102511000','Tarragona','1100000000','1102500000'),('1108201000','Compostela','1100000000','1108200000'),('1108202000','Laak','1100000000','1108200000'),('1108203000','Mabini','1100000000','1108200000'),('1108204000','Maco','1100000000','1108200000'),('1108205000','Maragusan','1100000000','1108200000'),('1108206000','Mawab','1100000000','1108200000'),('1108207000','Monkayo','1100000000','1108200000'),('1108208000','Montevista','1100000000','1108200000'),('1108209000','Nabunturan','1100000000','1108200000'),('1108210000','New Bataan','1100000000','1108200000'),('1108211000','Pantukan','1100000000','1108200000'),('1108601000','Don Marcelino','1100000000','1108600000'),('1108602000','Jose Abad Santos','1100000000','1108600000'),('1108603000','Malita','1100000000','1108600000'),('1108604000','Santa Maria','1100000000','1108600000'),('1108605000','Sarangani','1100000000','1108600000'),('1130700000','Davao City','1100000000','1130700000');
/*!40000 ALTER TABLE `location_municipalities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_provinces`
--

DROP TABLE IF EXISTS `location_provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_provinces` (
  `province_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `province_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`province_code`),
  KEY `region_code` (`region_code`),
  CONSTRAINT `location_provinces_ibfk_1` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_provinces`
--

LOCK TABLES `location_provinces` WRITE;
/*!40000 ALTER TABLE `location_provinces` DISABLE KEYS */;
INSERT INTO `location_provinces` VALUES ('1102300000','Davao del Norte','1100000000'),('1102400000','Davao del Sur','1100000000'),('1102500000','Davao Oriental','1100000000'),('1108200000','Davao de Oro','1100000000'),('1108600000','Davao Occidental','1100000000'),('1130700000','Davao City','1100000000');
/*!40000 ALTER TABLE `location_provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_regions`
--

DROP TABLE IF EXISTS `location_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_regions` (
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_short_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `region_logo` longblob,
  `region_logo_dark` longblob,
  PRIMARY KEY (`region_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_regions`
--

LOCK TABLES `location_regions` WRITE;
/*!40000 ALTER TABLE `location_regions` DISABLE KEYS */;
INSERT INTO `location_regions` VALUES ('1100000000','Region XI (Davao Region)','Davao Region',NULL,NULL);
/*!40000 ALTER TABLE `location_regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_link`
--

DROP TABLE IF EXISTS `mobile_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_link` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `link` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `active` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_code` (`region_code`),
  CONSTRAINT `mobile_link_ibfk_1` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_link`
--

LOCK TABLES `mobile_link` WRITE;
/*!40000 ALTER TABLE `mobile_link` DISABLE KEYS */;
INSERT INTO `mobile_link` VALUES (4,'https://expo.dev/artifacts/eas/nRoYNzWoyhVkwaRg4siwj3.apk','1','2024-01-29 15:40:28','2024-01-29 15:40:28',NULL,'1100000000');
/*!40000 ALTER TABLE `mobile_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_tokens`
--

DROP TABLE IF EXISTS `refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `expiry_date` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `refresh_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2410 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_tokens`
--

LOCK TABLES `refresh_tokens` WRITE;
/*!40000 ALTER TABLE `refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_entries`
--

DROP TABLE IF EXISTS `report_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_entries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int unsigned NOT NULL,
  `month` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `status` enum('open','active','closed') COLLATE utf8mb4_general_ci DEFAULT 'open',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  CONSTRAINT `report_entries_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_entries`
--

LOCK TABLES `report_entries` WRITE;
/*!40000 ALTER TABLE `report_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `frequency` enum('monthly','quarterly','yearly') COLLATE utf8mb4_general_ci NOT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `indicator_id` int unsigned DEFAULT NULL,
  `dashboard_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_code` (`region_code`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `reports_ibfk_23` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `reports_ibfk_24` FOREIGN KEY (`indicator_id`) REFERENCES `assessment_indicators` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authorities`
--

DROP TABLE IF EXISTS `user_authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_authorities` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `authority` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authorities`
--

LOCK TABLES `user_authorities` WRITE;
/*!40000 ALTER TABLE `user_authorities` DISABLE KEYS */;
INSERT INTO `user_authorities` VALUES (1,'MANAGE_ALL_ACCOUNTS','Create/Update/Delete All Accounts'),(2,'MANAGE_NATIONAL_REGIONAL_ACCOUNT','Create/Update/Delete National and Regional Accounts'),(3,'MANAGE_CITY_PROVINCIAL_ACCOUNT','Create/Update/Delete City/Provincial and Municipal Accounts'),(4,'MANAGE_FACILITIES','Create/Update/Delete Facilities'),(5,'MANAGE_FRESAA_BATCHES','Create/Update/Delete Assessment Batches'),(6,'VIEW_FRESAA_BATCHES','View Assessment Batches'),(7,'CREATE_DELETE_REGIONAL_FRESAA_QUESTIONNAIRE','Create FRESAA Questionnaire - Regional Access'),(8,'MANAGE_PROVINCIAL_FACILITIES','Create/Update/Delete Facilities - Provincial Access'),(9,'ANSWER_FRESAA_QUESTIONNAIRE','Answer FRESAA Questionnaire'),(10,'REVIEW_FRESAA_QUESTIONNAIRE','Review FRESAA Questionnaire'),(11,'MANAGE_FRESAA_QUESTIONNAIRE','Assign and Submit FRESAA Questionnaire'),(12,'MONITOR_REGIONAL_FRESAA_QUESTIONNAIRE','Monitor Regional Assessments'),(13,'MONITOR_PROVINCIAL_FRESAA_QUESTIONNAIRE','Monitor Provincial Assessments'),(14,'VIEW_REGIONAL_DASHBOARD','View Regional Dashboard'),(15,'VIEW_PROVINCIAL_DASHBOARD','View Provincial Dashboard'),(16,'VIEW_NATIONAL_DASHBOARD','View National Dashboard'),(17,'VIEW_MUNICIPAL_DASHBOARD','View Municipal Dashboard'),(18,'MANAGE_FACILITY_GROUP','Create/Update/Delete Facility Group'),(19,'VIEW_ACTIVITY_LOG','View Activity Logs'),(20,'MANAGE_DASHBOARD','Manage Dashboard'),(21,'MANAGE_FACILITY','Manage Dashboard'),(22,'MANAGE_REPORTS','Manage Reporting Tool');
/*!40000 ALTER TABLE `user_authorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_authorities`
--

DROP TABLE IF EXISTS `user_group_authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_authorities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_group_id` int unsigned NOT NULL,
  `user_authority_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_group_id` (`user_group_id`),
  KEY `user_authority_id` (`user_authority_id`),
  CONSTRAINT `user_group_authorities_ibfk_19` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`),
  CONSTRAINT `user_group_authorities_ibfk_20` FOREIGN KEY (`user_authority_id`) REFERENCES `user_authorities` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_authorities`
--

LOCK TABLES `user_group_authorities` WRITE;
/*!40000 ALTER TABLE `user_group_authorities` DISABLE KEYS */;
INSERT INTO `user_group_authorities` VALUES (1,1,2),(2,1,3),(3,1,4),(4,1,5),(5,1,6),(6,1,7),(7,1,11),(8,1,12),(9,1,14),(10,1,18),(11,2,2),(12,2,3),(13,2,4),(14,2,6),(15,2,7),(16,2,11),(17,2,12),(18,2,14),(19,2,18),(20,3,3),(21,3,6),(22,3,8),(23,3,11),(24,3,13),(25,3,15),(26,3,18),(27,4,6),(28,4,8),(29,4,11),(30,4,13),(31,4,15),(32,4,18),(33,5,9),(34,6,17),(35,7,14),(36,8,16),(37,9,1),(38,10,15),(39,11,10),(40,11,17),(41,12,10),(42,12,15),(43,1,19),(44,2,19),(45,3,19),(46,4,19),(47,13,10),(48,13,14),(49,1,20),(50,2,20),(51,14,21),(52,1,22),(53,2,22),(59,12,6),(61,7,10);
/*!40000 ALTER TABLE `user_group_authorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `validator` tinyint(1) DEFAULT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_name` (`group_name`),
  UNIQUE KEY `group_name_2` (`group_name`),
  UNIQUE KEY `group_name_3` (`group_name`),
  UNIQUE KEY `group_name_4` (`group_name`),
  UNIQUE KEY `group_name_5` (`group_name`),
  UNIQUE KEY `group_name_6` (`group_name`),
  UNIQUE KEY `group_name_7` (`group_name`),
  UNIQUE KEY `group_name_8` (`group_name`),
  KEY `region_code` (`region_code`),
  CONSTRAINT `user_groups_ibfk_1` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (1,'RMTL','Regional Monitoring Team Leader','Regional',NULL,NULL),(2,'RMTM','Regional Monitoring Team Member','Regional',NULL,NULL),(3,'CPAL','City/Provincial Assessment Team Leader','Provincial',NULL,NULL),(4,'CPAM','City/Provincial Assessment Team Member','Provincial',NULL,NULL),(5,'FA','Field Assessor','Provincial',NULL,NULL),(6,'Municipal','Municipal Account (Dashboard View only)','Municipal',NULL,NULL),(7,'CHD','Center for Health Development','Regional',1,NULL),(8,'National','National Account (Dashboard View only)','National',NULL,NULL),(9,'SA','Super Admin','0.0.0',NULL,NULL),(10,'Provincial','Provincial Account (Dashboard View only)','Provincial',NULL,NULL),(11,'MHO/PHN','MHO/PHN','Municipal',1,NULL),(12,'PHO','Provincial Health Officer','Provincial',1,NULL),(13,'DMO','Development Management Officer','Regional',1,NULL),(14,'FHS','Facility Head/Staff','Facility',NULL,NULL);
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_group_id` int unsigned NOT NULL,
  `mobile_number` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `region_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `province_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `municipality_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `manager` int unsigned DEFAULT NULL,
  `created_by` int unsigned DEFAULT NULL,
  `updated_by` int unsigned DEFAULT NULL,
  `deleted_by` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `facility_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_group_id` (`user_group_id`),
  KEY `region_code` (`region_code`),
  KEY `province_code` (`province_code`),
  KEY `municipality_code` (`municipality_code`),
  KEY `manager` (`manager`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `deleted_by` (`deleted_by`),
  CONSTRAINT `users_ibfk_100` FOREIGN KEY (`municipality_code`) REFERENCES `location_municipalities` (`municipality_code`),
  CONSTRAINT `users_ibfk_101` FOREIGN KEY (`manager`) REFERENCES `users` (`id`),
  CONSTRAINT `users_ibfk_102` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `users_ibfk_103` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `users_ibfk_104` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `users_ibfk_97` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`),
  CONSTRAINT `users_ibfk_98` FOREIGN KEY (`region_code`) REFERENCES `location_regions` (`region_code`),
  CONSTRAINT `users_ibfk_99` FOREIGN KEY (`province_code`) REFERENCES `location_provinces` (`province_code`)
) ENGINE=InnoDB AUTO_INCREMENT=635 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'cphi_sa','$2b$10$kd13GhYAjdRjvF2e2RPWcuWRzuNhvepX0vYfSpQ3UW20weKG9mZWS','CPHI','','CPHI','',9,'09123456789','admin@cphealthinnovations.com','1100000000',NULL,NULL,NULL,NULL,NULL,NULL,'2023-10-29 13:06:13','2024-03-15 21:58:24',NULL,NULL),(85,'rmtl_davao','$2b$10$P26YBhAEgoF1eskvDEAIH.Ktp7C.HaVajk9cmwMR163WuUCSzKNui','RMTL',NULL,'Davao',NULL,1,NULL,NULL,'1100000000',NULL,NULL,NULL,NULL,NULL,NULL,'2023-09-19 11:47:04','2023-09-19 11:47:04',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_groups`
--

DROP TABLE IF EXISTS `widget_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widget_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `column_type` enum('3-3-3-3','4-4-4','6-6','8-4','4-8') COLLATE utf8mb4_general_ci NOT NULL,
  `order` int unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `indicator_id` int unsigned NOT NULL,
  `layout` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  KEY `indicator_id` (`indicator_id`),
  CONSTRAINT `widget_groups_ibfk_1` FOREIGN KEY (`indicator_id`) REFERENCES `assessment_indicators` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_groups`
--

LOCK TABLES `widget_groups` WRITE;
/*!40000 ALTER TABLE `widget_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `widget_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int unsigned NOT NULL,
  `type` enum('line','pie','bar','scorecard') COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `configuration` longtext COLLATE utf8mb4_general_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `widgets_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `widget_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'fresaa_davao'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-02 12:13:14
